README for the OEM Test Kit

This is not an official Google product.

Android MIDI test programs and examples. This is a suite of MIDI Apps 
that run on Android M or later.

They are intended for use by OEMs for testing MIDI on new devices. 
But they may also be of use to other developers.

The source code is available under the Apache Source License V2on GitHub.
https://github.com/philburk/android-midisuite
