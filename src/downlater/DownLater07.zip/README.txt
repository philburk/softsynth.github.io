README for DownLater

Copyright (c) 1999 SoftSynth.com
Author: Phil Burk

DownLater is a demo-ware program. You have 30 days to evaluate
DownLater for free. After 30 days, if you want to continue using
DownLater, you must register at:

    http://www.softsynth.com/downlater
    
You will then be sent a license via e-mail which you can install on
your computer.

There are several good reasons to register your copy of DownLater.

  1) Registration enables the full set of features. After 30 days, unregistered
  	 copies will not download files over 3 megabytes and will only allow
  	 5 files per download.
  	 
  2) Registration will eliminate the annoying shareware messages.
  
  3) Registration will entitle you to on-line technical support.
  
  4) You will be supporting the development of improved versions of DownLater
     which will be available free to registered users.
