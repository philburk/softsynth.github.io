README for DownLater

DownLater may be freely distributed as long as the archive is kept intact.
Copyright (c) 1999 SoftSynth.com
Author: Phil Burk
Contact: philburk@softsynth.com
WebSite: http://www.softsynth.com

DownLater simplifies downloading multiple MP3 or other large files.
Drag-and-drop file links from your browser onto DownLater to be
downloaded later. Works with Netscape and InternetExplorer.
Selected files can be downloaded at the end of your web session
or can be scheduled to download while you sleep.
Users can now quickly select dozens of MP3 songs for later
downloading without tieing up their modem while browsing.

Installation -----------

Unzip the archive.
WinZip may automatically launch the InstallShield installer.
If not, double click on the file "setup.exe" and follow the
instructions for installing the program.

Usage ------------------

Simply drag and drop links to downloadable files from your browser to DownLater.
WHen you are done collecting links, hit "DownLoad Now" to download the files.
More extensive documentation is available in the docs directory.

Registration -----------

DownLater is a shareware program. You have 30 days to evaluate
DownLater for free. After 30 days, if you want to continue using
DownLater, you must register at:

    http://www.softsynth.com/downlater
    
You will then be sent a license via e-mail which you can install on
your computer.

There are several good reasons to register your copy of DownLater.

  1) Registration enables the full set of features. After 30 days, unregistered
  	 copies will not download files over 3 megabytes and will only allow
  	 5 files per download.
  	 
  2) Registration will eliminate the annoying shareware messages.
  
  3) Registration will entitle you to on-line technical support.
  
  4) You will be supporting the development of improved versions of DownLater
     which will be available free to registered users.
