README for DownLater

Copyright (c) 1999 SoftSynth.com
Author: Phil Burk

DownLater is a shareware program. You have 30 days to evaluate
DownLater for free. After 30 days, if you want to continue using
DownLater, you must register at:

    http://www.softsynth.com/downlater
    
You will then be sent a license via e-mail which you can install on
your computer.

There are several good reasons to register your copy of DownLater:

  1) you will be supporting the development of improved versions of DownLater,
  
  2) the license will prevent the annoying shareware messages from appearing,
  
  3) registration will entitle you to technical support,
  
  4) you will avoid burning in hell for eternity for illegally using a 
     shareware product past the 30 day limit.
