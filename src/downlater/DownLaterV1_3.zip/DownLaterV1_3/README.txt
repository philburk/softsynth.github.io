README for DownLater

DownLater may be freely distributed as long as the archive is kept intact.
Copyright (c) 1999, 2009 Mobileer Inc
Author: Phil Burk
WebSite: http://www.softsynth.com/downlater

DownLater simplifies downloading multiple MP3 or other large files.
Drag-and-drop file links from your browser onto DownLater to be
downloaded later. Works with Netscape and InternetExplorer.
Selected files can be downloaded at the end of your web session
or can be scheduled to download while you sleep.
Users can now quickly select dozens of MP3 songs for later
downloading without tieing up their modem while browsing.

Installation -----------

Unzip the archive.
Double click on "DownLater.exe".
You may wish to create an alias for your Desktop.

Usage ------------------

Simply drag and drop links to downloadable files from your browser to DownLater.
WHen you are done collecting links, hit "DownLoad Now" to download the files.
More extensive documentation is available in the docs directory.

License -----------

DownLater is free software. You are hereby granted a license to use DownLater freely for personal use.
