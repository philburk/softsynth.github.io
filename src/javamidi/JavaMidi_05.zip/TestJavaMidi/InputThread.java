//
//
// InputThread
// Author: Robert Marsanyi
// Copyright CagEnt Technologies, Inc
// All Rights Reserved
//
//
import jmidi.*;

class InputThread extends Thread
{
	MidiPort midiport;

	public InputThread( MidiPort aPort )
	{
		this.midiport = aPort;
	}

	public void run()
	{
		int nBytes;
		boolean done = false;
		// TEST: use new MidiPortBuffer
		// byte[] buffer = Main.buffer;
		byte[] buffer;
		MidiPortMessage msg;
		
		try
		{
			// TEST: use new MidiPortBuffer
			msg = new MidiPortMessage(Main.BUFSIZE);
			buffer = msg.messageData;
			System.out.println( "Message buffer is " + buffer.length + " bytes.");
			
			System.out.println( "Opening port" );
			midiport.open();

			while( !done )
			{
				System.out.println( "Starting message poll" );
				try
				{
					while( midiport.messagesWaiting() == 0 )
					{
						yield();
					}

					System.out.println( "Reading message" );
					// nBytes = midiport.readMessage( buffer, buffer.length );
					nBytes = midiport.readMessage( msg );

					System.out.println("Buffer (" + nBytes + " long) @ " + msg.timeStamp + ":");
					for( int i = 0; i < nBytes; i ++ )
					{
						System.out.print( buffer[i] + " " );
					}
					System.out.println();

					if( nBytes >= 3 )
					{
						String msgString = new String( buffer, 0x00, 2, nBytes - 3 );
    					if( msgString.equalsIgnoreCase("Done") ) done = true;
					}

					if( (buffer[0] & 0xF0) == 0xC0 ) done = true; // program change
    			}

				catch( MidiPortException e )
    			{
					System.out.println( "MidiPort Exception (probably overran buffer) - resetting." );
					midiport.resetInput();
				}
			}

			System.out.println( "Checking message queue (should be 0 left) = " + midiport.messagesWaiting() );
			System.out.println( "Closing port" );
			midiport.close();
			System.out.println( "Done!" );
		}
		catch (Exception e)
		{
			System.err.println( "WHOOPS! error! " + e.getMessage() );
		}
	}
}	