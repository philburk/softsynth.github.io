//
//
// Main
// Author: Robert Marsanyi
// Copyright CagEnt Technologies, Inc
// All Rights Reserved
//
//
import java.util.Vector;
import jmidi.*;

class Main 
{
	static final int BUFSIZE = 256;
	static byte[] buffer = new byte[BUFSIZE];
	static int ptr = 0;
	static MidiPort midiport;
	
	public static void main(String[] args)
	{
		int inDevice = 0;
		int outDevice = 0;
		int i = 0, j;
        String arg;
        char flag;
        boolean simpleFlag = true;

        while (i < args.length && args[i].startsWith("-"))
		{
            arg = args[i++];

			if (arg.equals("-simple"))
			{
			System.out.println( "Simple JavaMidi Test: plays note 60 on channel 1 at velocity 80 for 1 second" );
                simpleTest( inDevice, outDevice );
            }
			else if (arg.equals("-complex"))
			{
				System.out.println("Complex JavaMidi Test: sends a string as a sysex");
				complexTest( inDevice, outDevice );
			}
			else if (arg.equals("-input"))
			{
				System.out.println("Input JavaMidi Test: displays messages");
				inputTest( inDevice, outDevice );
			}
			else if (arg.equals("-device"))
			{
				if (i < args.length)
				{
					try
					{
						dumpDevices( MidiPort.MIDIPORT_INPUT );
						dumpDevices( MidiPort.MIDIPORT_OUTPUT );
						Integer inDeviceInt = new Integer(args[i++]);
						Integer outDeviceInt = new Integer(args[i++]);
						inDevice = inDeviceInt.intValue();
						outDevice = outDeviceInt.intValue();
						simpleTest( inDevice, outDevice );
					}
					catch( NumberFormatException e )
					{
					   System.err.println("-device requires a valid device number");
					}
				}
                else
                    System.err.println("-device requires a valid device number");
            }
		}

		// run the simple test if there's no args
		if( args.length == 0 ) simpleTest( inDevice, outDevice );
	}

	public static void dumpDevices( int type )
	{
		try
		{
			Vector devNames = MidiPort.enumerateDevices( type );
			
			// print a heading
			String heading = (type == MidiPort.MIDIPORT_INPUT) ? "Input " : "Output ";
			System.out.println(heading + "Devices:");

			// dump the list
			for( int i = 0; i < devNames.size(); i++ )
			{
				System.out.println( "  "+devNames.elementAt(i) );
			}
		}
		catch( MidiPortException e )
		{
			System.err.println("dumpDevices fails with " + e.getMessage());
		}
	}

	public static void simpleTest( int inDevice, int outDevice )
	{
		int channel = 0;

		try
		{
			System.out.println( "Declaring ports for device numbers " + inDevice
			  +	", " + outDevice );
			midiport = new MidiPort( inDevice, outDevice );

			System.out.println( "Opening port" );
			midiport.open();
			System.out.println( "Sending noteon" );
			midiport.writeShortMessage( (byte)0x90, (byte)60, (byte)80 );
			System.out.println( "Waiting for 1 second" );
			Thread.sleep( 1000 );
			System.out.println( "Sending noteoff" );
			midiport.writeShortMessage( (byte)0x80, (byte)60, (byte)0 );
			System.out.println( "Closing port" );
			midiport.close();
			System.out.println( "Done!" );
		}
		catch (Exception e)
		{
			System.err.println( "WHOOPS! error! " + e.getMessage() );
		}
	}

	public static void complexTest( int inDevice, int outDevice )
	{
		try
		{
			System.out.println( "Declaring ports for device numbers " + inDevice
			  +	", " + outDevice );
			midiport = new MidiPort( inDevice, outDevice );

			System.out.println( "Opening port" );
			midiport.open();

			String testString = new String( "Test String" );
			byte[] nextChar = new byte[testString.length()];
			ptr = 0;

			for( int i = 0; i < 9; i ++ )
			{
				System.out.println( "Sending sysex string" );

				checkAppend( (byte)0xF0 );
				checkAppend( (byte)0x7D );
				testString.getBytes( 0, testString.length(), nextChar, 0 );
				for( int j = 0; j < testString.length(); j++ )
				{
					checkAppend( nextChar[j] );
				}
				checkAppend( (byte)0x20 );  // ascii space
				checkAppend( (byte)(i + 0x30) ); // ascii index
				checkAppend( (byte)0xF7 );
			}
			
			checkAppend( (byte)0xC0 );
			checkAppend( (byte)0x0 );
			
			flush();

			System.out.println( "Sleeping for 5s" );
			Thread.sleep( 5 * 1000 );

			System.out.println( "Closing port" );
			midiport.close();
			System.out.println( "Done!" );
		}
		catch (Exception e)
		{
			System.err.println( "WHOOPS! error! " + e.getMessage() );
		}
	}

	public static void checkAppend( byte b ) throws MidiPortException
	{
		if( ptr == BUFSIZE ) flush();
		buffer[ptr++] = b;
	}

	public static void flush() throws MidiPortException
	{
		System.out.println( "Queueing buffer" );
		midiport.writeLongMessage( buffer, ptr, 10000 );
		ptr = 0;
	}

	public static void inputTest( int inDevice, int outDevice )
	{
		int nBytes;
		boolean done = false;
		InputThread inputThread;

		try
		{
			System.out.println( "Declaring ports for device numbers " + inDevice
			  +	", " + outDevice );
			midiport = new MidiPort( inDevice, outDevice );

			/*
			Start an input thread.  Input is done in a separate thread so that
			main() returns to Java's VM
			*/
			inputThread = new InputThread( midiport );
			inputThread.start();
		}
		catch (Exception e)
		{
			System.err.println( "WHOOPS! error! " + e.getMessage() );
		}
	}
}