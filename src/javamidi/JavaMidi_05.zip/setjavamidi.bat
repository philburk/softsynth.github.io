REM Set CLASSPATH and PATH for jmidi
set path=%path%;\java\jdk1.2.2\java\bin
set classpath=%classpath%;/java/lib/javamidi/bin
