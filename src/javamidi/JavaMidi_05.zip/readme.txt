Here's JavaMidi version 5, a package that implements MIDI I/O for Java using the host OS's native MIDI
support.  This version contains native classes for Win32 platforms; classes for the Mac
using OMS have also been written.  The high-level Java interface to both these is the same.

The motivation for v5 was the new timestamped input option.  Refer to the docs on the new MidiPortMessage
class and corresponding MidiPort.readMessage() method.

If you use JavaMidi in your projects, please put a credit in for the package and the author.  Thanks.

--Robert Marsanyi

Updates:
	- V05: fixed bug that prevented opening, closing then reopening.
	- V05: added timestamped input.
	- V04: added an active sensing filter, since people were reporting that active sensing
	  messages were overflowing the input buffer.
	- V04: rewrote for JNI, rather than JRI.  This is the newer standard native code interface,
	  supported by (all?) current Win32 Java VMs.
	- V03: replaced dll with non-debug version.  This is a _lot_ smaller and a _lot_
	  faster.
	- V03: defined MidiPort.MIDIPORT_NODEVICE to allow use with systems that have only an
	  input or output, but not both.  You can now open and use one or the other or both.

Notes:

bin	- contains JavaMidi classes and the Win32 DLL.
doc	- contains the javadoc-generated package documentation.
TestJavaMidi
	- contains a simple test program.
setjavamidi.bat
	- sets the PATH and CLASSPATH environment variables to work with JavaMidi.  You'll
	  need to modify this.

To use:

Modify setjavamidi.bat or manually set the variables PATH and CLASSPATH so that

	PATH includes the directory where the MidiPort.dll file lives, as well
	  as the path to the Java binaries.  Alternatively, copy MidiPort.dll to
	  your /windows or /windows/system directory, where dll's are searched
	  for automatically by Windows.
	CLASSPATH includes the directory where the folder jmidi lives

To try it out:

- Hook your PC MIDI Out cable to a synth or something
- Set the environment variables as specified above
- Change to the TestJavaMidi directory
- type "java Main -simple".

You should see(hear) a single noteon, a delay and a single noteoff.

If that works, try

- type "java Main -device 0 0"

This does the same thing, but lets you specify which MIDI devices to use on the command line.
It prints the list of devices on the screen when it runs, too.

If that works, try

- hook up your PC MIDI In cable to a keyboard or something
- type "java Main -input"
- send some MIDI to the PC

This'll display the incoming messages.  You can stop the program with ^C, or by sending a
program change message.

To use in your programs:

- If you're using VJ++ to program with, make sure that the directory containing jmidi is 
    in the project settings.
- Put an "import jmidi.*" statement at the top of your class source files.

Feedback:
Please let me know of problems or suggestions for improvement by mailing rnm@whidbey.com.

--rbt