/*
  MidiPortImp.c

  Implementation of native MidiPort methods for Win32
  Author: Robert Marsanyi
  Copyright 1996 Robert Marsanyi
  All Rights Reserved.
*/

#include <StubPreamble.h>
#include "jmidi_MidiPort.h"

#include <mmsystem.h>

#define MP_NUM_INPUT_BUFFERS (2)
#define MP_INBUF_SIZE (256)    /* bytes */
#define MP_CIRCBUF_SIZE (512)  /* bytes */

#define ENABLE_INPUT (1) /* set to 1 to compile input routines */

typedef struct MidiPortContext
{
	char          *mpc_inBuf[MP_NUM_INPUT_BUFFERS];
	char          *mpc_circBuffer;
	volatile char *mpc_circWritePtr, *mpc_circReadPtr;
	HANDLE        mpc_writeEvent;
	HMIDIIN       mpc_midiInHandle;
	HMIDIOUT      mpc_midiOutHandle;
	LPMIDIHDR     mpc_midiInHeaders[MP_NUM_INPUT_BUFFERS];
	LPMIDIHDR     mpc_midiOutHeader;
	BOOLEAN       mpc_BufferOverrun;
	volatile long mpc_MessagesPending;
	long          mpc_InputErrors;
	BOOLEAN       mpc_enforceNewMessage;
} MidiPortContext;

struct MidiPortContext gMPC;

#if ENABLE_INPUT
void CALLBACK MPReceiveMessage( HMIDIIN, UINT, DWORD, DWORD, DWORD );
UINT MPQueueSysexBuffer( LPMIDIHDR );
long MPStartInput( void );
long MPStopInput( void );
#endif

#ifndef DBUG
#define DBUG(x) /* { printf x; } */
#endif
/***************************
Midi GetNumDevices, GetDeviceName Routines
***************************/

long jmidi_MidiPort_nGetNumDevices(struct Hjmidi_MidiPort *me,long type)
{
	switch( type )
	{
	case jmidi_MidiPort_MIDIPORT_INPUT:
		return( midiInGetNumDevs() );
	case jmidi_MidiPort_MIDIPORT_OUTPUT:
		return( midiOutGetNumDevs() );
	default:
		return(-1);
	}
}

struct Hjava_lang_String *jmidi_MidiPort_nGetDeviceName(struct Hjmidi_MidiPort *me,long type,long num)
{
	char *name;
	MIDIINCAPS inCaps;
	MIDIOUTCAPS outCaps;
	Hjava_lang_String *jString = NULL;

	switch( type )
	{
		case jmidi_MidiPort_MIDIPORT_INPUT:
			if( midiInGetDevCaps( num, &inCaps, sizeof(MIDIINCAPS) ) != MMSYSERR_NOERROR )
				goto clean;
			
			// make a Java String from the name
			name = inCaps.szPname;
			jString = makeJavaString( name, strlen(name) );
			break;
		case jmidi_MidiPort_MIDIPORT_OUTPUT:
			if( midiOutGetDevCaps( num, &outCaps, sizeof(MIDIOUTCAPS) ) != MMSYSERR_NOERROR )
				goto clean;
			
			// make a Java String from the name
			name = outCaps.szPname;
			jString = makeJavaString( name, strlen(name) );
			break;
	}

clean:
	return(jString);
}

/***************************
Midi Open, Close Routines
***************************/

long jmidi_MidiPort_nOpen(struct Hjmidi_MidiPort *this)
{
	UINT err = MMSYSERR_NOERROR;
	long outputDeviceNumber, inputDeviceNumber;
	int i;

	// extract the requested device from the Hjmidi_MidiPort structure
	outputDeviceNumber = unhand(this)->outputDeviceNumber;
	inputDeviceNumber = unhand(this)->inputDeviceNumber;
	
	// make sure there's a MIDI output device out there!
	if( (midiOutGetNumDevs() == 0) || ((unsigned)outputDeviceNumber >= midiOutGetNumDevs()) )
	{
		err = -1;
		goto clean;
	}

	// make sure there's a MIDI input device out there!
	if( (midiInGetNumDevs() == 0) || ((unsigned)inputDeviceNumber >= midiInGetNumDevs()) )
	{
		err = -1;
		goto clean;
	}

	// allocate a MIDIHDR structure for output
	if( (gMPC.mpc_midiOutHeader = malloc( sizeof(MIDIHDR) )) == NULL )
	{
		err = -1;
		goto clean;
	}

	// allocate buffers for sysex input
	for( i = 0; i < MP_NUM_INPUT_BUFFERS; i++ )
	{
		gMPC.mpc_inBuf[i] = NULL;
		if( (gMPC.mpc_inBuf[i] = malloc( MP_INBUF_SIZE )) == NULL )
		{
			err = -1;
			goto clean;
		}
	}

	// allocate a circular buffer for all input messages
	if( (gMPC.mpc_circBuffer = malloc( MP_CIRCBUF_SIZE )) == NULL )
	{
		err = -1;
		goto clean;
	}

	// create a manual-reset event for write signalling
	if( (gMPC.mpc_writeEvent = CreateEvent( NULL, TRUE, FALSE, NULL )) == NULL )
	{
		err = -1;
		goto clean;
	}

	// open the midi output port
	if( (err = midiOutOpen( &(gMPC.mpc_midiOutHandle), outputDeviceNumber, (DWORD)&(gMPC.mpc_writeEvent), 0, CALLBACK_EVENT )) != MMSYSERR_NOERROR )
		goto clean;

#if ENABLE_INPUT	
	// allocate MIDIHDR structures for input
	for( i = 0; i < MP_NUM_INPUT_BUFFERS; i++ )
	{
		if( (gMPC.mpc_midiInHeaders[i] = malloc( sizeof(MIDIHDR) )) == NULL )
		{
			err = -1;
			goto clean;
		}
		else
		{
			LPMIDIHDR hdr = gMPC.mpc_midiInHeaders[i];
			hdr->lpData = gMPC.mpc_inBuf[i];
			hdr->dwBufferLength = MP_INBUF_SIZE;
			hdr->dwUser = i;
		}
	}

	// open the midi input port
	if( (err = midiInOpen( &(gMPC.mpc_midiInHandle), inputDeviceNumber, (DWORD)&(MPReceiveMessage), 0, CALLBACK_FUNCTION )) != MMSYSERR_NOERROR )
		goto clean;

	// start input
	if( (err = MPStartInput()) != MMSYSERR_NOERROR )
		goto clean;

#else
	// set the input Handle to NULL
	gMPC.mpc_midiInHandle = NULL;
#endif

	return( err );

clean:
	jmidi_MidiPort_nClose( this );
	return( err );
}

long jmidi_MidiPort_nClose(struct Hjmidi_MidiPort *this)
{
	UINT err = 0;
	int i;

	if( gMPC.mpc_midiOutHandle != NULL )
	{
		// reset the output port to clear all pending output
		midiOutReset( gMPC.mpc_midiOutHandle );

		// close the output
		midiOutClose( gMPC.mpc_midiOutHandle );
		gMPC.mpc_midiOutHandle = NULL;
	}
	if( gMPC.mpc_midiInHandle != NULL )
	{
		// reset the input port to clear pending input
		MPStopInput();
		gMPC.mpc_midiInHandle = NULL;
	}

	if( gMPC.mpc_writeEvent != NULL )
	{
		CloseHandle( gMPC.mpc_writeEvent );
		gMPC.mpc_writeEvent = NULL;
	}

	if( gMPC.mpc_circBuffer != NULL )
	{
		free( gMPC.mpc_circBuffer );
		gMPC.mpc_circBuffer = NULL;
	}

	for( i = 0; i < MP_NUM_INPUT_BUFFERS; i++ )
	{
		if( gMPC.mpc_inBuf[i] != NULL )
		{
			free( gMPC.mpc_inBuf[i] );
			gMPC.mpc_inBuf[i] = NULL;
		}
	}

	if( gMPC.mpc_midiOutHeader != NULL )
	{
		free( gMPC.mpc_midiOutHeader );
		gMPC.mpc_midiOutHeader = NULL;
	}

	return( 0 );
}

/***************************
Midi Output Routines
***************************/

long jmidi_MidiPort_nWriteShortMessage(struct Hjmidi_MidiPort *this, char status, char data1, char data2)
{
	UINT msg;

	if( status & 0x80 ) msg = (status & 0xFF) | (data1 & 0xFF) << 8 | (data2 & 0xFF) << 16;
	else msg = (data1 & 0xFF) | (data2 & 0xFF) << 8;

	return( midiOutShortMsg( gMPC.mpc_midiOutHandle, msg ) );
}

long jmidi_MidiPort_nWriteLongMessage(struct Hjmidi_MidiPort *this,HArrayOfByte *buf,long len,long timeout)
{
	LPMIDIHDR lpHeader = gMPC.mpc_midiOutHeader;
	UINT err;
	DWORD waitResult;

	// check that we have allocated a header structure
	if( lpHeader == NULL )
	{
		err = -1;
		goto clean;
	}

	// set up the header and prepare it
	lpHeader->lpData = unhand(buf)->body;
	lpHeader->dwBufferLength = len;
	lpHeader->dwBytesRecorded = len;
	lpHeader->dwFlags = 0;

	if( (err = midiOutPrepareHeader( gMPC.mpc_midiOutHandle, lpHeader, sizeof(MIDIHDR) )) != MMSYSERR_NOERROR)
		goto clean;

	// reset the output Event
	if( ResetEvent( gMPC.mpc_writeEvent ) == 0 ) /* 0 => error occurred */
	{
		err = -1;
		goto clean;
	}

	// send the string
	if( (err = midiOutLongMsg( gMPC.mpc_midiOutHandle, lpHeader, sizeof(MIDIHDR) )) != MMSYSERR_NOERROR)
		goto clean;

	if( !(lpHeader->dwFlags & MHDR_DONE) )
	{
		// wait for done signal
		if( (waitResult = WaitForSingleObject( gMPC.mpc_writeEvent, timeout )) == WAIT_FAILED )
		{
			err = waitResult;
			goto clean;
		}
		
		// if we timed out, abort the write to reclaim ownership of the data buffer
		if( waitResult == WAIT_TIMEOUT )
		{
			err = waitResult;
			DBUG(("Debugging: wait timed out."));
			midiOutReset( gMPC.mpc_midiOutHandle );
		}
	}

	// unprepare the header
	err = midiOutUnprepareHeader( gMPC.mpc_midiOutHandle, lpHeader, sizeof(MIDIHDR) );

clean:
	return( err );
}

/***************************
Midi Input Routines
***************************/
#if ENABLE_INPUT

/*
MPInitializeBuffer
sets the read and write pointers to the start of the buffer
*/

long MPStartInput( void )
{
	long err = 0;
	int i;

	gMPC.mpc_circReadPtr = gMPC.mpc_circWritePtr = gMPC.mpc_circBuffer;
	gMPC.mpc_enforceNewMessage = TRUE;

	// queue input buffers to the input port
	for( i = 0; i < MP_NUM_INPUT_BUFFERS; i++ )
	{
		LPMIDIHDR hdr = gMPC.mpc_midiInHeaders[i];
		if( (err = MPQueueSysexBuffer(hdr)) != MMSYSERR_NOERROR )
			goto clean;
	}

	// start processing MIDI input
	if( (err = midiInStart( gMPC.mpc_midiInHandle )) != MMSYSERR_NOERROR )
		goto clean;

	gMPC.mpc_BufferOverrun = FALSE;

clean:
	return(err);
}

long MPStopInput( void )
{
	long err = 0;

	if( (err = midiInReset( gMPC.mpc_midiInHandle )) != MMSYSERR_NOERROR )
		goto clean;
	gMPC.mpc_MessagesPending = 0;

clean:
	return( err );
}

/*
MPQueueSysexBuffer
sets up the MIDIHDR for the buffer and passes it to the input device
*/

UINT MPQueueSysexBuffer( LPMIDIHDR hdr )
{
	UINT err = MMSYSERR_NOERROR;

	// prepare midi header
	hdr->dwFlags = 0;

	DBUG((" midiInPrepareHeader..." ));
	if( (err = midiInPrepareHeader( gMPC.mpc_midiInHandle, hdr, sizeof( MIDIHDR )) != MMSYSERR_NOERROR ) )
		goto clean;
	DBUG(( "OK\n"));

	// send header to input device
	DBUG((" midiInAddBuffer..." ));
	if( (err = midiInAddBuffer( gMPC.mpc_midiInHandle, hdr, sizeof( MIDIHDR )) != MMSYSERR_NOERROR ) )
		goto clean;
	DBUG(( "OK\n"));

clean:
	return(err);
}

/*
MPCircBufferFree
returns the number of bytes in the buffer that are free
*/
unsigned long MPCircBufferFree( void )
{
	long distance = (long)gMPC.mpc_circReadPtr - (long)gMPC.mpc_circWritePtr;
	if( distance <= 0 ) distance += MP_CIRCBUF_SIZE;
	return((unsigned)distance);
}

/*
MPWriteToInputBuffer
Write a variable number of bytes to the circular buffer, if possible
*/
int MPWriteToInputBuffer( char* data, unsigned long size )
{
	int overrun = 0;

	if( MPCircBufferFree() >= size )
	{
		// figure length(s) of chunks to copy
		unsigned long size1, size2;
		DWORD dwToEnd = (((char*)gMPC.mpc_circBuffer + MP_CIRCBUF_SIZE) - gMPC.mpc_circWritePtr);

		DBUG(("Writing: old (rd,wr) = (0x%x, 0x%x)\n", gMPC.mpc_circReadPtr, gMPC.mpc_circWritePtr));
		
		if( size > dwToEnd )
		{
			size1 = dwToEnd;
			size2 = size - size1;
		}
		else
		{
			size1 = size;
			size2 = 0;
		}

		// copy the first and (optionally) the second chunk to the circular buffer
		memcpy( gMPC.mpc_circWritePtr, data, size1 );
		if( size2 > 0 ) memcpy( gMPC.mpc_circBuffer, data + size1, size2 );
	
		// advance the write pointer
		if( size2 == 0 ) gMPC.mpc_circWritePtr += size1;
		else gMPC.mpc_circWritePtr = gMPC.mpc_circBuffer + size2;

		DBUG(("Writing: old (rd,wr) = (0x%x, 0x%x)\n", gMPC.mpc_circReadPtr, gMPC.mpc_circWritePtr));
	}
	else
	{
		printf(" OVERRUN!\n" );
		overrun = -1;
	}

	return( overrun );
}

/*
MPGetMessageLength
Filched from Bill's M2 code "hr.c"
Args
    statusByte
        MIDI status byte

Results
    length > 1 or Err code < 0.
*/
long MPGetMessageLength (char statusByte)
{
                                          /* 8n 9n An Bn Cn Dn En */
    static const char ChannelLenTable[]  = { 3, 3, 3, 3, 2, 2, 3 };

                                          /* F0 F1 F2 F3 F4 F5 F6 F7 F8 F9 FA FB FC FD FE FF */
    static const char SystemLenTable[]   = { 0, 2, 3, 2, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1 };  /* 0 for undefined (or unknown for F0) */

    long result;

    if (!(statusByte & 0x80)) return -1;        /* !!! error code: bad MIDI status byte */

    result = statusByte < 0xF0
        ? ChannelLenTable [statusByte >> 4 & 0x7]
        : SystemLenTable [statusByte - 0xF0];

    return result > 0 ? result : -1;            /* !!! error code: bad MIDI status byte */
}

/*
MPReceiveMessage
This is the callback function for the MIDI device.  It basically queues messages in the circular
buffer for subsequent reading by the client app.
*/
void CALLBACK MPReceiveMessage( HMIDIIN hMidiIn, UINT wMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2 )
{
	char smallMidiPacket[3];
	switch( wMsg )
	{
	case MIM_OPEN:
		{
			DBUG(("CALLBACK says Opened!\n"));
			break;
		}
	case MIM_CLOSE:
		{
			DBUG(("CALLBACK says Closed!\n"));
			break;
		}
	case MIM_MOREDATA:
	case MIM_DATA:
		{
			if( !gMPC.mpc_BufferOverrun )
			{
				long len;

				smallMidiPacket[0] = dwParam1 & 0xFF;
				len = MPGetMessageLength( smallMidiPacket[0] );
				if( len > 1 )
				{
					smallMidiPacket[1] = (dwParam1 >> 8) & 0xFF;
				}
				if( len > 2 )
				{
					smallMidiPacket[2] = (dwParam1 >> 16 ) & 0xFF;
				}
				if( MPWriteToInputBuffer( smallMidiPacket, len ) < 0 )
				{
					gMPC.mpc_BufferOverrun = TRUE;
				}
				else
				{
					gMPC.mpc_MessagesPending += 1;
					gMPC.mpc_enforceNewMessage = FALSE;
				}
			}
			break;
		}
	case MIM_LONGDATA:
		{
			int err = 0;
			LPMIDIHDR headerData = (LPMIDIHDR)dwParam1;

			if( !gMPC.mpc_BufferOverrun )
			{
				if( headerData->dwBytesRecorded > 0 )
				{
					if( ((gMPC.mpc_enforceNewMessage == TRUE) && (*(headerData->lpData) & 0x80))
					  || (gMPC.mpc_enforceNewMessage == FALSE) )
					{
						if( MPWriteToInputBuffer( headerData->lpData, headerData->dwBytesRecorded ) < 0 )
						{
							gMPC.mpc_BufferOverrun = TRUE;
						}
						else
						{
							char* lastBytePtr = headerData->lpData;

							lastBytePtr += headerData->dwBytesRecorded - 1;
							if( (*lastBytePtr & 0xFF) == 0xF7 ) gMPC.mpc_MessagesPending += 1;
							
							gMPC.mpc_enforceNewMessage = FALSE;
						}
					}
				}
			}

			// requeue the buffer
			if( headerData->dwBytesRecorded > 0 )
			{
				if( (err = MPQueueSysexBuffer( headerData )) != MMSYSERR_NOERROR )
				  DBUG(("CALLBACK: error requeueing header = %i\n", err));
			}
			break;
		}
	case MIM_ERROR:
	case MIM_LONGERROR:
		{
			gMPC.mpc_InputErrors += 1;
			break;
		}
	default:
		{
			// for debugging
			DBUG(( "Error in callback: received a message that isn't coded for.\n" ));
			break;
		}
	}
}

long jmidi_MidiPort_nReadMessage(struct Hjmidi_MidiPort *this,HArrayOfByte *buf,long len)
{
	long numRead = 0;

	DBUG(("Reading: old (rd,wr) = (0x%x, 0x%x)\n", gMPC.mpc_circReadPtr, gMPC.mpc_circWritePtr));

	// if there's a message waiting
	if( (gMPC.mpc_circReadPtr != gMPC.mpc_circWritePtr) && (gMPC.mpc_MessagesPending > 0) )
	{
		char* lpByteArray = unhand(buf)->body;

		// read up to the next status byte, or until buffer is empty, or until the destination is full
		do
		{
			lpByteArray[numRead++] = *gMPC.mpc_circReadPtr++;
			if( gMPC.mpc_circReadPtr >= gMPC.mpc_circBuffer + MP_CIRCBUF_SIZE )
				gMPC.mpc_circReadPtr = gMPC.mpc_circBuffer;
		}
		while( !(*gMPC.mpc_circReadPtr & 0x80) && (numRead < len) && (gMPC.mpc_circReadPtr != gMPC.mpc_circWritePtr));

		// include end sysex, if it's there
		if( ((*gMPC.mpc_circReadPtr & 0xFF) == 0xF7) && (numRead < len) && (gMPC.mpc_circReadPtr != gMPC.mpc_circWritePtr))
		{
			lpByteArray[numRead++] = *gMPC.mpc_circReadPtr++;
			if( gMPC.mpc_circReadPtr >= gMPC.mpc_circBuffer + MP_CIRCBUF_SIZE )
				gMPC.mpc_circReadPtr = gMPC.mpc_circBuffer;
		}

		// if the message is complete, decrement messagesPending
		if( (lpByteArray[numRead - 1] == 0xF7) || (gMPC.mpc_circReadPtr == gMPC.mpc_circWritePtr) || (*gMPC.mpc_circReadPtr & 0x80) )
			gMPC.mpc_MessagesPending--;
	}

	DBUG(("Reading: new (rd,wr,pending) = (0x%x, 0x%x, %i)\n", gMPC.mpc_circReadPtr, gMPC.mpc_circWritePtr,
	  gMPC.mpc_MessagesPending));

	// return number of bytes read
	return( numRead );
}

long jmidi_MidiPort_nMessagesWaiting(struct Hjmidi_MidiPort *this)
{
	if( gMPC.mpc_BufferOverrun == TRUE ) return( -1 );
	else return( gMPC.mpc_MessagesPending );
}

long jmidi_MidiPort_nResetInput(struct Hjmidi_MidiPort *this)
{
	long err = 0;
	
	if( (err = MPStopInput()) != MMSYSERR_NOERROR )
		goto clean;
	if( (err = MPStartInput()) != MMSYSERR_NOERROR )
		goto clean;

clean:
	return(err);
}

#else

long jmidi_MidiPort_nReadMessage(struct Hjmidi_MidiPort *this,HArrayOfByte *buf,long len)
{
	return(-1);
}

long jmidi_MidiPort_nMessagesWaiting(struct Hjmidi_MidiPort *this)
{
	return(-1);
}

long jmidi_MidiPort_nResetInput(struct Hjmidi_MidiPort *this)
{
	return(-1);
}

#endif