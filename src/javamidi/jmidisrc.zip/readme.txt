README for Source code for JavaMidi.

Java MIDI is a package that implements MIDI I/O for Java using the host OS's native MIDI
support.  This version contains native classes for Win32 platforms; classes for the Mac
using OMS have also been written.  The high-level Java interface to both these is the same.

You can download the pre-compiled executables for JavaMIDI at:

     http://www.softsynth.com/javamidi
	 
--Robert Marsanyi

Notes:

ms - source for use with JDirect and JView. You should create a DLL call "cMIDI.dll".
pc - source for use with standard Java using the JRI interface. For "MidiPort.dll"
mac - source for Macintosh.

Feedback:
Please let me know of problems or suggestions for improvement by mailing rnm@whidbey.com.

--rbt
