//
//
// MidiPort
//
// Author: Robert Marsanyi
// Copyright 1996 Robert Marsanyi
// All Rights Reserved.
//
//

import java.util.Vector;

class MidiPort 
{
    // static variables
	static public final int MIDIPORT_INPUT = 0;
	static public final int MIDIPORT_OUTPUT = 1;
	
	// library loader
	static
	{
        System.loadLibrary("MidiPort");
    }

	// public instance variables -----------------------------------------
	int inputDeviceNumber = -1;
	int outputDeviceNumber = -1;
	boolean isOpen = false;

	// constructors ------------------------------------------------------
	public MidiPort() {}
	public MidiPort( int inputDeviceNumber, int outputDeviceNumber ) throws MidiPortException
	{
		setDeviceNumber( MIDIPORT_INPUT, inputDeviceNumber );
		setDeviceNumber( MIDIPORT_OUTPUT, outputDeviceNumber );
	}

	// accessors ---------------------------------------------------------
	public void setDeviceNumber( int type, int n ) throws MidiPortException
	{
		boolean wasOpen = isOpen;
		if( isOpen ) close();
		
		switch( type )
		{
		case MIDIPORT_INPUT:
			inputDeviceNumber = n;
			break;
		case MIDIPORT_OUTPUT:
			outputDeviceNumber = n;
			break;
		default:
			throw new MidiPortException(-1);
		}

		if( wasOpen ) open();
	}

	public int getDeviceNumber( int type ) throws MidiPortException
	{
		switch( type )
		{
		case MIDIPORT_INPUT:
			return( inputDeviceNumber );
		case MIDIPORT_OUTPUT:
			return( outputDeviceNumber );
		default:
			throw new MidiPortException(-1);
		}
	}

	// native methods ----------------------------------------------------
	private native static int nGetNumDevices( int type );
	private native static String nGetDeviceName( int type, int num );
	private native int nOpen();
	private native int nClose();
	private native int nWriteShortMessage( byte status, byte data1, byte data2 );
	private native int nWriteLongMessage( byte[] message, int len, int timeout );
	private native int nReadMessage( byte[] message, int maxLength );
	private native int nMessagesWaiting();

	private native int nResetInput();

	// wrapper methods ---------------------------------------------------
	public static int getNumDevices( int type ) throws MidiPortException
	{
		int err = nGetNumDevices( type );
		if( err < 0 ) throw new MidiPortException(err);
		return(err);
	}

	public static String getDeviceName( int type, int num ) throws MidiPortException
	{
		String name;
		
		name = nGetDeviceName( type, num );
		if( name == null ) throw new MidiPortException();
		return(name);
	}

	public static Vector enumerateDevices(int type ) throws MidiPortException
	{
		Vector result = new Vector();
			
		for( int i = 0; i < getNumDevices( type ); i++ )
		{
			result.addElement( getDeviceName( type, i ) );
		}

		return(result);
	}

	public void open() throws MidiPortException
	{
		// check that devices have been set
		if( (getDeviceNumber( MIDIPORT_INPUT ) < 0) || (getDeviceNumber( MIDIPORT_OUTPUT ) < 0) )
		  throw new MidiPortException(-1);

		int err = nOpen();
		if( err != 0 ) throw new MidiPortException(err);
		else isOpen = true;
	}

	public void close() throws MidiPortException
	{
		int err = nClose();
		if( err != 0 ) throw new MidiPortException(err);
		else isOpen = false;
	}

	public void writeShortMessage( byte status, byte data1, byte data2 ) throws MidiPortException
	{
		int err = nWriteShortMessage( status, data1, data2 );
		if( err != 0 ) throw new MidiPortException(err);
	}

	public void writeShortMessage( byte status, byte data1 ) throws MidiPortException
	{
		int err = nWriteShortMessage( status, data1, (byte)0 );
		if( err != 0 ) throw new MidiPortException(err);
	}
	
	public void writeLongMessage( byte[] message, int len, int timeout ) throws MidiPortException
	{
		int err = nWriteLongMessage( message, len, timeout );
		if( err != 0 ) throw new MidiPortException(err);
	}

	public int readMessage( byte[] message, int maxLength ) throws MidiPortException
	{
		int err = nReadMessage( message, maxLength );
		if( err <= 0 ) throw new MidiPortException(err);
		else return(err);
	}

	public int messagesWaiting() throws MidiPortException
	{
		int err = nMessagesWaiting();
		if( err < 0 ) throw new MidiPortException("Buffer overrun");
		else return(err);
	}

	public void resetInput() throws MidiPortException
	{
		int err = nResetInput();

		if( err < 0 ) throw new MidiPortException(err);
	}
}

