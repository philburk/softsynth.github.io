/*
  midiport.h
  Header for C midi library code

  Author: Robert Marsanyi
  Copyright 1996 Robert Marsanyi
  All Rights Reserved.
*/

#ifndef _MIDIPORT_H
#define _MIDIPORT_H

#define MidiPort_MIDIPORT_INPUT 0
#define MidiPort_MIDIPORT_OUTPUT 1

#ifdef __cplusplus
extern "C" {
#endif

long MidiPort_WriteLongMessage(char*,long,long);
long MidiPort_ReadMessage(char*,long);
long MidiPort_ResetInput(void);
long MidiPort_MessagesWaiting(void);
long MidiPort_GetDeviceName(long,long,LPTSTR,long);
long MidiPort_Close();
long MidiPort_Open(long,long);
long MidiPort_WriteShortMessage(char,char,char);
long MidiPort_GetNumDevices(long);

#ifdef __cplusplus
}
#endif

#endif /* _MIDIPORT_H */
