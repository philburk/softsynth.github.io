<?

// HTML e-mail address collection
// by Phil Burk
//

	$emailAddress = strip_tags($HTTP_POST_VARS['emailAddress']);

// Function to check the validity of an e-mail address.
// From Joseph Lumbroso, http://www.lumbroso.com/scripts/
function checkEmailValidity( $address )
{
   return eregi( "^[_\.0-9a-z-]+@([0-9a-z][0-9a-z-]+\.)+[a-z]{2,3}$", $address );     
}
  
    if( ($emailAddress != "" ) )
    {
        if( !checkEmailValidity( $emailAddress ) )
        {
?>

<html>
<body bgcolor="#FFFFFF">
<font face="Arial" color="#000000">
<h1>Please hit the Back button<br>
and enter a valid e-mail address!</h1>
</font>
</body>
</html>

<?
            return;
        }
    }

    if( $emailAddress != "" )
    {
        $today = date("Ymd");
        $letter = "$emailAddress,$today\n";
        
// Append letter to log file.
        $fp = fopen("/var/www/softsynth/logs/pforth_addr.txt", "a" );
        if( fp === false )
        {
            echo("Could not open log file.<br>");
        }
        else
        {
            fwrite( $fp, $letter );
            fclose( $fp );
        }

// Send email to host.
		$targetName = "nospam";
		$targetName += "@";
		$targetName += "softsynth.com";
		mail( $targetName, "pForth request log",
		    "$letter" );

    }
        
    include("download.html");

?>
