<?php
// Default title. Override this by defining $pageTitle in your own page before including Aardvark.
$aardvarkDefaultTitle = "SoftSynth, music and computers";
// Default extra head information. Override this by defining $pageExtraHead in your own page before including Aardvark.
$aardvarkDefaultExtraHead = "<!-- extra head -->";

// Define left side navigation links.
$aardvarkLeftLinks = array(
	'/index.php' => 'Home',
	'/products.php' => 'Products',
	'/jsyn/index.php' => 'JSyn',
	'/syntona/index.php' => 'Syntona',
	'/pforth/index.php' => 'pForth',
	'/music/index.php' => 'Music',
	'/info/index.php' => 'Info',
	'/news/index.php' => 'News',
	'/links/index.php' => 'Links',
	'/contacts.php' => 'Contact&nbsp;Us',
	'/aboutus.php' => 'About&nbsp;Us' );

?>
