README for JSyn
Copyright (C) 1997 Phil Burk
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.

This ZIP file contains the plugin needed to play JSyn Java Applets in
Netscape Communicator. 

--------------- License ---------------------------

Please read the accompanying file "license.txt".

--------------- Installation -------------------------

Double click on the ZIP archive to unpack it. If you use the 
WinZip Wizard, then it will probably automatically run the 
NanoInstaller for the JSyn Plugins.

If for some reason, the NanoInstaller does not run, just double 
click on the SETUP.EXE icon.

This installation will copy "npjsyn.dll" and "npjsyn.jar" to
the Netscape plugins directory.

------------------------------------------------------

If you encounter ANY bugs, or have any suggestions please let me
know. 

Please visit the JSyn web site at http://www.softsynth.com/jsyn
for more information or to download the latest version.

Thank you,
Phil Burk
philburk@softsynth.com
