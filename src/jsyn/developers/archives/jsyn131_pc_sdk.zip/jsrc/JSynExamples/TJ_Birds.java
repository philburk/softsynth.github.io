
package JSynExamples;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view102.*;

/**
 * Generate some fake bird sounds using Java Audio Synthesiser.
 * Demonstrates use of EventBuffer with set().
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

public class TJ_Birds extends Applet
{
	int            numBirds;
	CozumelBird[]  birds;
	Button[]       buttons;
	BusReader      unitBusReader;
	LineOut        unitOut;
	SynthScope     scope;
	Dialog         scopeDialog;

/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_Birds applet = new TJ_Birds();
		AppletFrame frame = new AppletFrame("Birds", applet);
		frame.resize(440,200);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{
		setLayout( new GridLayout(0,1) );
		
		try
		{
/* Start synthesis engine. */
		Synth.startEngine( 0, Synth.DEFAULT_FRAME_RATE / 2.0 );  /* Try a lower frame rate. */

		unitBusReader = new BusReader( );
		unitOut = new LineOut( );

/* Set priority low so that Bus_Read can get current data from bus.
** The Bus_Writes will run at a higher default priority.
*/
		unitBusReader.setPriority(Synth.PRIORITY_LOW);
		unitBusReader.output.connect( 0, unitOut.input, 0 );
		unitBusReader.output.connect( 0, unitOut.input, 1 );

/* Make several synth birds. */
		numBirds = 5;
		birds = new CozumelBird[numBirds];
		buttons = new Button[numBirds];
		for( int i=0; i<numBirds; i++ )
		{
			birds[i] = new CozumelBird( unitBusReader.busInput, 1000.0 + ((4000.0*i)/(numBirds+1)) );
			birds[i].start();
/* Add some buttons to trigger chirps. */
			add( buttons[i] = new Button("Bird" + i) );
		}

/* Create an oscilloscope to show bus output. */
		if( true )
		{
			scope = new SynthScope();
			scope.createProbe( unitBusReader.output, "BusOut", Color.yellow );
			scope.finish();

			scopeDialog = new Dialog( (Frame) getParent(), "JSyn Scope", false );
			scopeDialog.add( "Center", scope );
			scopeDialog.reshape( 200,100, 500,400 );
			scopeDialog.show();
		}
		else
		{
			add( new UsageDisplay() );
		}

/* Synchronize Java display. */
			getParent().validate();
			getToolkit().sync();

/* Start execution of units. */
			unitBusReader.start();
			unitOut.start();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}

	public void stop()
	{
			scopeDialog.hide();
			removeAll();
		try
		{
/* Stop execution of units. */
/*			for( int i=0; i<numBirds; i++ )
			{
				birds[i].stop();
			}
			unitBusReader.stop();
			unitOut.stop();

			for( int i=0; i<numBirds; i++ )
			{
				birds[i].delete();
			}
			birds = null;
			numBirds = 0;
			buttons = null;
			unitBusReader.delete();
			unitBusReader = null;
			unitOut.delete();
			unitOut = null;
			scopeDialog = null;
			scope = null;
*/
/* Stop synthesis engine. */
			Synth.stopEngine();
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}

	public boolean action(Event evt, Object what)
	{
		try
		{
/* Determine which bird button was hit and trigger that bird. */
			for( int i=0; i<numBirds; i++ )
			{
				if( evt.target == buttons[i] )
				{
					birds[i].chirp();
					return true;
				}
			}
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
			return true;
		}
		return false;
    }
}
	
/**
 * These are designed to sound somewhat like the black birds with a long
 * tail that are common in Cozumel, Mexico.
 * This class is part of TJ_Birds.
 */
class CozumelBird extends SynthCircuit
{
	TriangleOscillator unitOsc;
	SawtoothOscillator unitLFO1;
	ExponentialLag unitLagAmp;
	MultiplyAddUnit unitFreqMix;
	WaveShaper unitWaveShaper;
	BusWriter unitBusWriter;

	SynthTable tableMod2Amp;
	SynthBusInput   bus;
	double     topFreq;

	public CozumelBird( SynthBusInput bus, double topFreq )
	throws SynthException
	{
		super();
		this.topFreq = topFreq;
		this.bus = bus;

		add( unitOsc         = new TriangleOscillator());
		add( unitLFO1        = new SawtoothOscillator());
		add( unitLagAmp      = new ExponentialLag());
		add( unitFreqMix     = new MultiplyAddUnit());
		add( unitBusWriter   = new BusWriter());

/* Create a waveshaper that converts the sawtooth input to an amplitude envelope.
** When the sawtooth goes / the waveshaper will go /\.
** Thus the amplitude will be 1.0 when the freq offset is zero,
** and will be 0.0 when the freq offset is -1.0 and +1.0.
*/
		add( unitWaveShaper  = new WaveShaper());
		tableMod2Amp = new SynthTable( 3 );
		double[] data = { 0, 1.0, 0 };
		tableMod2Amp.write( data );
		unitWaveShaper.tablePort.setTable( tableMod2Amp );

/* Amplitude control. */
		unitLFO1.output.connect( unitWaveShaper.input );
		unitLagAmp.halfLife.set( 0.1 );
		unitLagAmp.output.connect( unitWaveShaper.amplitude );
		unitWaveShaper.output.connect( unitOsc.amplitude );

/* Frequency control. */
		unitLFO1.output.connect( unitFreqMix.inputA );
		unitFreqMix.inputB.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ );
		unitFreqMix.inputC.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ );
		unitFreqMix.output.connect( unitOsc.frequency );

		unitBusWriter.busOutput.connect( bus );

		unitOsc.output.connect( unitBusWriter.input);
		compile();
	}
	
/* Trigger wierd chirp from "bird". */
	public void chirp()
	throws SynthException
	{
		int dur = 100;
		int ticks = Synth.getTickCount();
/* Change modulation rate randomly. */
		for( int i=0; i<6; i++ )
		{
/* Use event buffer to schedule modulation over time. */
			unitLagAmp.input.set(ticks, 0.5); /* Ramp up amplitude. */
			unitLFO1.frequency.set(ticks,  50.0 * (Math.random()*(Math.random() - 0.5)));
			unitFreqMix.inputB.set(ticks,  600.0 * Math.random() + 100.0); /* Mod Depth */
			unitFreqMix.inputC.set(ticks,  0.5*topFreq * (Math.random() + 1.0)); /* Center Freq */
			ticks += dur*(Math.random() + 0.5);
			unitLagAmp.input.set(ticks, 0.0); /* Ramp down amplitude. */
			ticks += dur*(Math.random() + 0.5);
		}
   }
}

