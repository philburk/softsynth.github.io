package com.softsynth.jsyn;
import java.util.*;

/**
 *	The SynthTable class is a container for digital audio data.  The actual data may need to reside in memory that is accessible to 
 *	DMA or to a DSP so we cannot assume that it is in main memory.  We also need to maintain cache coherence if the data is 
 *	going to be read or written by hardware other than the CPU.  For this reason, SynthTable cannot use memory allocated by, or 
 *	accessable to, the application.
 *
 *	SynthTables differ from Samples in that SynthTables can be read via random access,
 *  while Samples can only be read sequentially.  Thus tables can be used to
 *  implement function lookup and wave shaping, and also can be used with oscillators
 *  that have negative or very high frequencies.
 *	Samples are read by SynthUnits that are controlled by "Rate" ports.
 *	SynthTables are read by SynthUnits that are controlled by "Frequency" ports
 *	When using a hardware accelerator, SynthSample and SynthTable data may reside in different memories.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see SynthSample
 */

public class SynthTable extends SynthObject
{
	int  numFrames;

/**
 * Create an empty table. You must call allocate() before using the table.
 */
	public SynthTable()
	{
		super();
	}
/**
 * Create a monophonic SynthTable with the specified number of frames.
 * @param numFrames Number of sample frames to allocate.
 * @exception SynthException	 If there is insufficient memory.
 */
	public SynthTable( int numFrames )
		throws SynthException
	{
		allocate( numFrames );
	}
/**
 * @exception SynthException	 If the memory allocation fails.
 */
	public void allocate( int numFrames ) throws SynthException
	{
		delete();
		this.numFrames = numFrames;
		peerToken = Synth.CreateTable( numFrames );
		if( peerToken < 0 ) throw new SynthException( peerToken, numFrames );
	}

/**
 * <P>Write data from an array of shorts to the Tables internal storage area.
 * The internal storage may be in main memory or it could be located on a
 * sound card and only accessable by DMA.
 * The 16 bit data will be scaled to -1.0 to +1.0 internally using N/32768.
 * @exception SynthException	 If the data will not fit in the table.
 */
	public void write( int startFrame, int partNum, short[] data, int srcOff, int numShorts ) throws SynthException
	{
		int result = Synth.WriteTable( peerToken, startFrame, data, srcOff, numShorts );
		if( result < 0 ) throw new SynthException( result, peerToken, startFrame );
	}
	public void write( int startFrame, short[] data, int srcOff, int numShorts ) throws SynthException
	{
		write( startFrame, 0, data, srcOff, numShorts );
	}
	public void write(  short[] data ) throws SynthException
	{
		write( 0, 0, data, 0, data.length );
	}
/**
 * <P>Write data from an array of doubles to the Tables internal storage area.
 * The internal storage may be in main memory or it could be located on a
 * sound card and only accessable by DMA.
 * The data will be clipped to -1.0 to +1.0.
 * @exception SynthException	 If the data will not fit in the table.
 */
	public void write( int startFrame, int partNum, double[] data, int srcOff, int numShorts ) throws SynthException
	{
		int result = Synth.WriteTableDoubles( peerToken, startFrame, data, srcOff, numShorts );
		if( result < 0 ) throw new SynthException( result, peerToken, startFrame );
	}
	public void write( int startFrame, double[] data, int srcOff, int numShorts ) throws SynthException
	{
		write( startFrame, 0, data, srcOff, numShorts );
	}
	public void write(  double[] data ) throws SynthException
	{
		write( 0, 0, data, 0, data.length );
	}

	public int length()
	{
		return numFrames;
	}
}
