/**
 * Oscilloscope
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;
import java.util.*;
import java.awt.*;
import java.applet.*;
import com.softsynth.jsyn.*;

class SynthProbe extends SampleWriter_16F1
{
	SynthSample         mySamp;
	public short[]      data;

	public SynthProbe( SynthOutput outPort, int partNum, int size ) throws SynthException
	{
		super();
		data = new short[ size ];
		outPort.connect( partNum, input, 0 );
		mySamp = new SynthSample( size, 1 );
	}
	
	void trigger() throws SynthException
	{
		samplePort.clear();
		samplePort.queue( mySamp, 0, mySamp.getNumFrames(), Synth.FLAG_AUTO_STOP );
	}

	void readData()  throws SynthException
	{
		mySamp.read( 0, data, 0, mySamp.getNumFrames() );
	}

}

class SynthProbeCircuit  extends SynthCircuit
{
	Vector       probes;
	int          sampleSize;

/* Create a circuit with N probes that can be started in sync. */
	public SynthProbeCircuit( int sampleSize ) throws SynthException
	{
		probes = new Vector();
		this.sampleSize = sampleSize;
	}

	public SynthProbe addProbe( SynthOutput outPort, int partNum )  throws SynthException
	{
		SynthProbe probe = new SynthProbe( outPort, partNum, sampleSize );
		probes.addElement( probe );
		add( probe );
		return probe;
	}

	void trigger() throws SynthException
	{
		stop();
		for( int j=0; j<probes.size(); j++)
		{
			SynthProbe probe = (SynthProbe) probes.elementAt(j);
			probe.trigger();
		}
		start();
	}
	void readData() throws SynthException
	{
		for( int j=0; j<probes.size(); j++)
		{
			SynthProbe probe = (SynthProbe) probes.elementAt(j);
			probe.readData();
		}
	}

}

class SynthScopeProbePanel extends Panel
{
	Button           VSupButton;
	Button           VSdownButton;
	Checkbox         showButton;
	WaveDisplay      display;
	Label            label;
	Label            scaleLabel;
	WaveTrace        trace;

	public SynthScopeProbePanel( WaveTrace trace, String name ) throws SynthException
	{
		this.trace = trace;

		setLayout( new GridLayout( 1,3 ) );

		add( label = new Label( name ) );

		Panel midPanel = new Panel();
		midPanel.add( showButton = new Checkbox("Show") );
		midPanel.add( VSupButton = new Button("V*2") );
		midPanel.add( VSdownButton = new Button("V/2") );
		add( midPanel );

		add( scaleLabel = new Label( "1.0" ) );
		label.setForeground( trace.color );
		label.setBackground( Color.black );

		showButton.setState( true );
	}

	public void setLabel( String name )
	{
		label.setText( name );
		repaint();
	}

	void useDisplay( WaveDisplay display )
	{
		if( display == null )
		{
			this.display.removeTrace( trace );
		}
		else
		{
			display.addTrace( trace );
		}
		this.display = display;
	}

	public void setColor( Color color )
	{
		trace.color = color;
		label.setForeground( color );
	}
	public Color getColor( )
	{
		return trace.color;
	}
	
	public boolean action(Event evt, Object what)
	{
		if( evt.target == VSupButton )
		{
			trace.scaleFactor = 2.0 * trace.scaleFactor;
			display.repaint();
			scaleLabel.setText( Double.toString( trace.scaleFactor ) );
			repaint();
			return true;
		}
		else if( evt.target == VSdownButton )
		{
			trace.scaleFactor = 0.5 * trace.scaleFactor;
			display.repaint();
			scaleLabel.setText( Double.toString( trace.scaleFactor ) );
			repaint();
			return true;
		}
		else if( evt.target == showButton )
		{
			if( showButton.getState() )
			{
				display.addTrace( trace );
			}
			else
			{
				display.removeTrace( trace );
			}
			display.repaint();
			return true;
		}
		return false;
    }

}

public class SynthScope  extends Panel implements Runnable
{

	SynthProbeCircuit  probeCircuit; /* Put all probes in circuit for synchronized start. */
	WaveDisplay      waveDisplay;
	Button           captureButton;
	Checkbox         autoBox;
	Button           zoomInButton;
	Button           zoomOutButton;
	Button           panLeftButton;
	Button           panRightButton;
	Panel            probeGroup;
	Panel            controlPanel;
	Thread           thread;
	boolean          runAuto = false;
	int              sampleSize;

	public SynthScope( int sampleSize )
		throws SynthException
	{
		this.sampleSize = sampleSize;

/* Use GridBagLayout to get reasonable sized components. */
        GridBagLayout  gridbag  =  new  GridBagLayout();
        GridBagConstraints  constraint  =  new  GridBagConstraints();
        setLayout(gridbag);
        constraint.gridwidth  =  GridBagConstraints.REMAINDER; 
        constraint.fill  =  GridBagConstraints.BOTH;
        constraint.weightx  =  1.0;

		add( waveDisplay = new WaveDisplay() );
		waveDisplay.setBackground( Color.black );

/* Make waveDisplay fill available vertical space for scope. */
        constraint.gridheight  =  GridBagConstraints.RELATIVE;  
        constraint.weighty  =  1.0;
		gridbag.setConstraints(waveDisplay,  constraint);
        constraint.weighty  =  0.0;

		add( probeGroup = new Panel() );

        constraint.gridheight  =  GridBagConstraints.REMAINDER;  
		gridbag.setConstraints(probeGroup,  constraint);

		probeGroup.setLayout( new GridLayout(0,1) );
		probeGroup.add( controlPanel = new Panel() );
		controlPanel.add( captureButton = new Button("Capture") );
		controlPanel.add( autoBox = new Checkbox("Auto") );
		autoBox.setState(true);
		controlPanel.add( zoomInButton = new Button("Zoom In") );
		controlPanel.add( zoomOutButton = new Button("Zoom Out") );
		controlPanel.add( panLeftButton = new Button("<<<") );
		controlPanel.add( panRightButton = new Button(">>>") );
		controlPanel.add( new UsageDisplay() );

		probeCircuit = new SynthProbeCircuit( sampleSize );

		handleAutoBox();

	}

	public SynthScope() throws SynthException
	{
		this( 1024 );
	}

	public void run()
	{
		int period = (int) Synth.getTickRate();

		while(true)
		{
			try
			{
				Synth.sleepForTicks( period );
				capture();
			}
			catch( SynthException e )
			{
				return;
			}
		}
	}

/**
 *	Display a panel for this probe on the scope. 
 *
 * @exception SynthException   If an error occurs.
 */
	public void addProbe( SynthScopeProbePanel probePanel )
	throws SynthException
	{
		probePanel.useDisplay( waveDisplay );
		probeGroup.add( probePanel );
		repaint();
	}
/**
 *	Remove the probe from the scope. 
 *
 * @exception SynthException	 If an error occurs.
 */
	public void removeProbe( SynthScopeProbePanel probePanel )
	throws SynthException
	{

		probePanel.useDisplay( null );
		probeGroup.remove( probePanel );
		repaint();
	}

/**
 *	Conveniance call that creates a SynthProbe and adds it to scope.
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public SynthScopeProbePanel createProbe( SynthOutput outPort, String name, Color color )
	throws SynthException
	{
		SynthProbe probe = probeCircuit.addProbe( outPort, 0 );
		WaveTrace  trace = new WaveTrace( probe.data, color, 1.0 );
		SynthScopeProbePanel probePanel = new SynthScopeProbePanel( trace, name );
		addProbe( probePanel );
		return probePanel;
	}

/**
 * Acquire fresh data then update the display.
 */
	public synchronized void capture()
	throws SynthException
	{
		probeCircuit.trigger();
		Synth.sleepForTicks( (sampleSize / Synth.getFramesPerTick()) + 1 ); /* FIXME - use sample completion notification when implemented. */
		probeCircuit.readData();
		waveDisplay.repaint();
	}

/* Process autoBox event which controls periodic capture thread. */
	void handleAutoBox()
	{
		if( thread ==  null)
		{
			thread = new Thread( this );
		}

		if (autoBox.getState())
		{
			if( thread.isAlive() )
			{
				thread.resume();      /* Resume, or start if needed. */
			}
			else
			{
				thread.start();
			}
		}
		else
		{
			if( thread.isAlive() )
			{
				thread.suspend();       /* Pause if alive */
			}
		}
	}

	public boolean action(Event evt, Object what)
	{
		try
		{
			if( evt.target == captureButton )
			{
				capture();
				return true;
			}
			else if( evt.target == autoBox )
			{
				handleAutoBox();
				return true;
			}
			else if( evt.target == zoomInButton )
			{
				waveDisplay.zoomIn();
				waveDisplay.repaint();
				return true;
			}
			else if( evt.target == zoomOutButton )
			{
				waveDisplay.zoomOut();
				waveDisplay.repaint();
				return true;
			}
			else if( evt.target == panLeftButton )
			{
				waveDisplay.panLeft();
				waveDisplay.repaint();
				return true;
			}
			else if( evt.target == panRightButton )
			{
				waveDisplay.panRight();
				waveDisplay.repaint();
				return true;
			}
		}
		catch (SynthException e)
		{
			SynthAlert.showError(this,e);
			return true;
		}
		return false;
    }


}

