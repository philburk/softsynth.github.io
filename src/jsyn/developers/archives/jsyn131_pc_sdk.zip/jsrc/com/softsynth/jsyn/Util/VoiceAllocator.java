package com.softsynth.jsyn.util;import java.util.*;import java.io.*;import com.softsynth.jsyn.*;/** Voice Allocator for managing the allocation and reuse of voices. * Uses an abstract method makeVoice() which must be defined in later classes.<br> * To allocate a voice if freely available, use allocate().<br> * To allocate a free voice, or steal the oldest voice use steal().
 *  * @see TJ_PlayKeys1
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */public abstract class VoiceAllocator{	SynthCircuit        voices[];
	boolean             allocated[];
	int                 times[];
	int                 maxVoices;	int                 numVoices = 0;/** Specify the maximum number of voices that can be allocated at a time.
 * If an attempt is made to 
 */
	public VoiceAllocator( int maxVoices )
	{
		this.maxVoices = maxVoices;		voices = new SynthCircuit[maxVoices];
		allocated = new boolean[maxVoices];
		for( int i=0; i<maxVoices; i++ ) allocated[i] = false;		times = new int[maxVoices];
	}
	/** @return Maximum number of voices that will be allocated.
 */	public int getMaxVoices()	{ return maxVoices;	}	
/** Create a new voice. This method must be defined in your classes.
 */	public abstract SynthCircuit makeVoice() throws SynthException;

/* Add a voice to the pool. */
	SynthCircuit addVoice( int time ) throws SynthException
	{
		if( numVoices == maxVoices ) return null;
		SynthCircuit circ = makeVoice();
		voices[numVoices] = circ;
		mark( numVoices, time);
		numVoices++;
		return circ;
	}

/* Search for earliest voice with matching allocation status. */
	int searchEarliest( boolean ifSteal, int time )
	{
		int minDelta = Integer.MAX_VALUE;
		int chosen = -1;
		for( int i=0; i<numVoices; i++ )
		{
			int delta = times[i] - time;
	// Is voice free, or can we steal it?
			if( ifSteal || (!allocated[i] && (delta <= 0)))
			{
	// Find earliest such voice.
				if( delta < minDelta )
				{
					minDelta = delta;
					chosen = i;
				}
			}
		}
		return chosen;
	}
	
	void mark( int chosen, int time )
	{
		allocated[chosen] = true;
		times[chosen] = time;
//		System.out.println("VoiceAllocator: mark " + chosen + " at " + time );
	}
	
/** Allocate a voice to use.
 * @return a voice or null if maximum number of voices are already allocated.
 */
	public synchronized SynthCircuit allocate( int time ) throws SynthException
	{
/* If no voices, just make one. */
		if( numVoices == 0 ) return addVoice( time );
		
/* Look for earliest free voice. */
		int chosen = searchEarliest( false, time );
		if( chosen >= 0 )
		{
			mark(chosen,time);
			return voices[chosen];
		}
		
/* If not maxed out, just make one. */
		if( numVoices < maxVoices ) return addVoice( time );

		return null;
	}
	
/** Try to allocate a voice then steal oldest voice if none other available. */
	public SynthCircuit steal( int time ) throws SynthException
	{
/* First try to allocate one. */
		SynthCircuit circ = allocate( time );
		if( circ != null ) return circ;
		
/* Then steal earliest allocated voice. */
		int chosen = searchEarliest( true, time );
		if( chosen >= 0 )
		{
//			System.out.println("VoiceAllocator: steal " + chosen);
			mark(chosen,time);
			return voices[chosen];
		}
		return null;
	}
	public SynthCircuit steal()  throws SynthException
	{
		return steal( Synth.getTickCount() );
	}
	
/** Free a voice for others to use. */
	public synchronized void free( int time, SynthCircuit circuit )
	{
		for( int i=0; i<numVoices; i++ )
		{
			if( circuit == voices[i] )
			{
//				System.out.println("VoiceAllocator: free " + i + " at " + time);
				allocated[i] = false;
				times[i] = time;
				break;
			}
		}
	}
	
	public void free( SynthCircuit circuit )  throws SynthException
	{
		free( Synth.getTickCount(), circuit );
	}

}
