package com.softsynth.jsyn.util;
import java.util.*;
import com.softsynth.jsyn.*;
/** Voice Allocator that mixes the voice onto a bus using a BusWriter.
 * Uses an abstract method makeVoice() which must be defined in later classes.<br>
 * Mixed result can be obtained using from a SynthOutput port obtained using getOutput().
 * 
 * @see TJ_PlayKeys1
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see BusWriter
 */
public abstract class  BussedVoiceAllocator extends VoiceAllocator
{
	BusReader     busReader;

	public BussedVoiceAllocator( int maxVoices ) throws SynthException
	{
		super( maxVoices );
		busReader = new BusReader( );
/* Set priority low so that BusReader can get current data from bus.
** The Bus_Writes will run at a higher default priority.
*/
		busReader.setPriority(Synth.PRIORITY_LOW);
		busReader.start();
	}
	
	public SynthCircuit addVoiceToMix( SynthCircuit circuit ) throws SynthException
	{
		BusWriter busWriter = new BusWriter();
		circuit.output.connect( busWriter.input );
		busWriter.busOutput.connect( busReader.busInput );
		busWriter.start();
		return circuit;
	}
	
	public SynthOutput getOutput()
	{
		return busReader.output;
	}
}
