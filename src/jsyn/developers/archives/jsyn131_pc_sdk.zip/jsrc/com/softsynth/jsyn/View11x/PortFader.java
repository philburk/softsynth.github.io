package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
/**
 * Fader for controlling a Java Synthesis Unit's Port.
 * Displays Port name and Value.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class PortFader extends LabelledFader implements Tweakable
{
	SynthVariable port;
	String     portName;
/**
 * Create a PortFader that will provide user control over a SynthPort.
 * @param port The port to be controlled using the ScrollBar.
 * @param aliasName Overrides the actual name of the port with a more meaningful name.
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public PortFader( SynthVariable port, String aliasName, double startValue, double min, double max )
	{
		super( null, 0, aliasName, startValue, min, max );
		this.port = port;
		tweak( 0, startValue);
	}
	public PortFader( SynthVariable port, double startValue, double min, double max )
    {
		this( port, port.getAlias(), startValue, min, max );
	}
	
	public SynthVariable getPort() { return port; }
/** Specify port to be controlled by fader.
 */
	public void setPort( SynthVariable port )
	{
		this.port = port;
	}
	
	public void tweak( int idx, double fval )
	{
		try
		{
			port.set(fval);
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
}
