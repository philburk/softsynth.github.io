package com.softsynth.jsyn;
import java.util.*;

/**
 *	The SynthEnvelope contains a set of duration value pairs that describe a contour,
 * or a function in time. It can be used to shape the amplitude of notes or provide
 * complex modulation of any parameter.
 * <br>
 * The actual data may need to reside in memory that is accessible to 
 *	DMA or to a DSP so we cannot assume that it is in main memory.  We also need to maintain cache coherence if the data is 
 *	going to be read or written by hardware other than the CPU.  For this reason, Envelopes cannot use memory allocated by, or 
 *	accessable to, the application.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see EnvelopePlayer
 * @see SynthEnvelopeQueue
 * @see SynthSample
 */

public class SynthEnvelope extends SynthChannelData
{

/**
 * Create an Envelope with the specified number of frames. 
 * @exception SynthException	 If memory allocation fails.
 */
	public SynthEnvelope( int numFrames )
	throws SynthException
	{
		super( numFrames );
		this.numFrames = numFrames;
		peerToken = Synth.CreateEnvelope( numFrames );
		if( peerToken < 0 ) throw new SynthException( peerToken, numFrames );
	}
/**
 * Create an Envelope that will contain the contents of the double array. 
 * @exception SynthException	 If memory allocation fails.
 */
	public SynthEnvelope( double[] data )
	throws SynthException
	{
		this( data.length/2 );
		write( 0, data, 0, numFrames );
	}

/**
 * <P>Write data from an array of doubles to the Envelopes internal storage area.
 * The internal storage may be in main memory or it could be located on the
 * sound card and only accessable by DMA. 
 * @exception SynthException	 If frames are out of range.
 */
	public void write( int startFrame, double[] data, int srcOff, int numFrames )
	throws SynthException
	{
		int result = Synth.WriteEnvelope( peerToken, startFrame, data, srcOff, numFrames );
		if( result < 0 ) throw new SynthException( result, peerToken, startFrame );
	}

/**
 * Read from the Envelope into an array of doubles.
 * @exception SynthException	 If frames are out of range.
 */
	public void read( int startFrame, double[] data, int srcOff, int numFrames )
	throws SynthException
	{
		int result = Synth.ReadEnvelope( peerToken, startFrame, data, srcOff, numFrames );
		if( result < 0 ) throw new SynthException( result, peerToken, startFrame );
	}

}
