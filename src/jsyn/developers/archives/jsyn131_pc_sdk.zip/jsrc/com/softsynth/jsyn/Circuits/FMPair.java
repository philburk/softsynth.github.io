package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
/**
 * FMPair creates pair of sine wave oscillators.
 */

public class FMPair extends SynthCircuit
{
	public SineOscillator  myCarrier;
	public SineOscillator  myModulator;
	public ExponentialLag  myLag;
	public AddUnit         myAdd;

	public SynthInput      amplitude;
	public SynthOutput     output;

	public FMPair( double halfLife )
	throws SynthException
	{
/* Make FM pair. */
		add( myCarrier = new SineOscillator() );
		add( myModulator = new SineOscillator() );
		add( myLag = new ExponentialLag() );
		add( myAdd = new AddUnit() );

		myModulator.output.connect( myAdd.inputA );
		myAdd.inputB.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ ); /* So we can use Hz */
		myAdd.output.connect( myCarrier.frequency );

		myLag.current.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ ); /* So we can use Hz */
		myLag.output.connect( myModulator.amplitude );
		myLag.halfLife.set( halfLife );

		addPort( amplitude = myCarrier.amplitude );
		addPort( output = myCarrier.output );
	}
	
	public void trigger( int timestamp, double carrierFrequency, double modFrequency, double modIndex )
	throws SynthException
	{
		myModulator.frequency.set( timestamp, modFrequency );
		myAdd.inputB.set( timestamp, carrierFrequency );
/* Calculate random modulation index and ping modulator. */
		myLag.current.set( timestamp, modIndex * carrierFrequency );
		start( timestamp );
	}

}