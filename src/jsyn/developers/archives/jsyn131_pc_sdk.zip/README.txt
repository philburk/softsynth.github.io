README for JSyn
Copyright (C) 1997 Phil Burk
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.

Because JSyn is still under development and undergoing rapid change, it
is currently only available for testing and evaluation purposes. JSyn may
NOT be redistributed by any means. JSyn is available AS IS with no
warranty of fitness or suitability for any purpose. Use at your own risk.

You are free to distribute your own applications that use JSyn, but please
ask your users to get the latest version of JSyn from our web site.

For HTML docs on how to install and use JSyn, please browse "jsyn\docs\index.html".

If you encounter ANY bugs, or have any suggestions please let me
know. Also please let me know if you develop any JSyn applications. I would
like to mention them on my web site.

Please visit the JSyn web site at http://www.softsynth.com/jsyn
for more information or to download the latest version.

Thank you,
Phil Burk
philburk@softsynth.com
