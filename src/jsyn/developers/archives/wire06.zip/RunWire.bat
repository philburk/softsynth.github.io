@rem run Wire Patch Editor for JSyn
set CLASSPATH=Wire.jar;%CLASSPATH%
java com.softsynth.wire.Wire -o20 -g

