README for JSyn PV V13.1
Copyright (C) 1997 Phil Burk
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.
--------------

V13.1 is a bug fix release designed to fix the following bugs:

1) BackToFront FIFO Full" - This error can occur when hundreds of events are
posted in the future, and then no JSyn calls are made before the events execute.
The fix involved converting the BackToFront FIFO from an atomic array based FIFO to
an atomic singly linked list design.

2) Samples or envelopes queued up when stopEngine() called were not getting freed.

3) When an array of type double was passed to SynthTable.write(), out-of-range values
were not getting clipped properly. Values below -1.0 were getting set to +1.0 instead
of -1.0.

INSTALLATION:

1) Replace the old JSynV13.dll and CSynV13.dll files in the "JSynV13\lib" directory
with the new files.

2) Replace the old "npjsyn.dll" file in the "Netscape\Communicator\Program\Plugins"
directory with the new file.

--------------
Because JSyn is still under development and undergoing rapid change, it
is currently only available for testing and evaluation purposes. JSyn may
NOT be redistributed by any means. JSyn is available AS IS with no
warranty of fitness or suitability for any purpose. Use at your own risk.

You are free to distribute your own applications that use JSyn, but please
ask your users to get the latest version of JSyn from our web site.

For HTML docs on how to install and use JSyn, please browse "jsyn\docs\index.html".

If you encounter ANY bugs, or have any suggestions please let me
know. Also please let me know if you develop any JSyn applications. I would
like to mention them on my web site.

Please visit the JSyn web site at http://www.softsynth.com/jsyn
for more information or to download the latest version.

Thank you,
Phil Burk
philburk@softsynth.com
