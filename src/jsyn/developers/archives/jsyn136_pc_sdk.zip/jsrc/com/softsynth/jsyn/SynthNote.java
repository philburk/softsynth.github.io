package com.softsynth.jsyn;
import java.util.*;
/**
 * SynthCircuit that can play "notes" with frequency and amplitude specified.
 *
 * This class has its own frequency, amplitude and output ports,
 * So do not declare new ones in your sub-classes.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 008
 * @see Synth
 * @see util.VoiceAllocator
 */

public class SynthNote extends SynthCircuit
{
	public SynthInput  frequency;
	public SynthInput  amplitude;

	public SynthNote()  throws SynthException
	{
		super();
	}

	public void noteOn( int time, double frequency, double amplitude ) throws SynthException
	{
		this.frequency.set( time, frequency );
		this.amplitude.set( time, amplitude );
		setStage( time, 0 );
	}

	public void noteOff( int time ) throws SynthException
	{
		setStage( time, 1 );
	}

	public void note( int time, int duration, double frequency, double amplitude )
	throws SynthException
	{
		noteOn( time, frequency, amplitude );
		noteOff( time+(duration/2) );
	}
}
