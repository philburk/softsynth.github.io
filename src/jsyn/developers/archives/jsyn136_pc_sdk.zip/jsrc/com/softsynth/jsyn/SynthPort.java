package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthPort class for Java Audio Synthesis
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthPort
{
	SynthSound sound;
	String     name;
	String     alias;  /* A different name for external use. */
	int        peerToken;
	int        portIndex;

	SynthPort( SynthSound sound, String name ) throws SynthException
	{
		this.sound = sound;
		this.name = name;
		this.alias = name;
		portIndex = Synth.hashName( name );
		if( sound != null )
		{
			peerToken = sound.peerToken;
			sound.addPort( this );
		}
		else
		{
			peerToken = 0;
		}
	}

	public String toString()
	{
		return alias;
	}

	public void setAlias( String alias )
	{
		this.alias = alias;
	}
	public String getAlias()
	{
		return alias;
	}
	
	public String getName()
	{
		return name;
	}

/**
 * Specify type of signal that the port uses.  This controls how values
 * passed using set are converted to internal raw values.
 * SynthUnits typically have their ports set to the appropriate signal type.
 * Thus if you set the Frequency of an Osc_Triangle directly you will not need to
 * call setSignalType.
 * But if you are calculating frequency control signals using LFOs and Math units then
 * you may wish to set their port signal types so that you can specify the port values
 * in Hertz. For example, you may be calculating frequency using a MultiplyAddUnit.
 * Set the ports that control modulation depth and center frequency to SIGNAL_TYPE_OSC_FREQ
 * so that these values may be specified in Hertz.
 * Using setSignalType() will help ensure that your sounds will be the same
 * regardless of the Engine's frame rate.
 * 
 * @param signalType Selects signal type. Legal values are:

<UL><LI>
Synth.SIGNAL_TYPE_RAW_SIGNED = internal signal type that ranges from -1.0 to +1.0.
This is used for Amplitude as an example.
</LI>
<LI>
Synth.SIGNAL_TYPE_RAW_UNSIGNED = internal signal type that ranges from 0.0 to +2.0.
This is used for Amplitude as an example.
</LI>
<LI>
Synth.SIGNAL_TYPE_OSC_FREQ = oscillator frequency.  Using this signal type
allows you to call set with Frequency values in Hertz.  (SIGNED)
</LI>
Synth.SIGNAL_TYPE_SAMPLE_RATE = SynthSample reader sample rate.  Using this signal type
allows you to call set with SynthSample rate values in Hertz. The frequency
that you actually hear will depend on the content of the sample. A bassoon
sample played at 44100 Hz will sound lower than a picollo sample
played at 44100 Hz.  (UNSIGNED)
</LI>
<LI>
Synth.SIGNAL_TYPE_HALF_LIFE = half life of an exponential decay function. (UNSIGNED)
</LI>
</UL>
 * @exception SynthException	 If portIndex out of range,
 *            or signalType is invalid, or one tries to switch between signed and unsigned
 *            signal types.
 */
	public void setSignalType( int signalType, int partIndex )
	throws SynthException
	{
		int nativeError = Synth.SetPortSignalType( peerToken, portIndex, partIndex, signalType );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, partIndex, signalType );
	}
	public void setSignalType( int signalType )
	throws SynthException
	{
		setSignalType( signalType, 0 );
	}

	public int getSignalType( int partIndex  )
	throws SynthException
	{
		int nativeError = Synth.GetPortSignalType( peerToken, portIndex, partIndex );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, partIndex );
		return nativeError;
	}

	public int getSignalType()
	throws SynthException
	{
		return getSignalType( 0 );
	}

/** Set signal type to the type of the passed in port.
 * @exception SynthException	 If port portIndex is not recognized, or index out of range,
 *            or signalType is invalid, or one tries to switch between signed and unsigned
 *            signal types.
 */
	public void setSignalType( SynthPort port )
	throws SynthException
	{
		setSignalType( port.getSignalType() );
	}

/* Pass port to subclasses to give them a chance to track connections. */
	void addConnection( SynthPort port ) {}
	void removeConnection( SynthPort port ) {}
	
	static void connectUnits( SynthPort outPort, int outIndex, SynthPort inPort, int inIndex )
	throws SynthException
	{
		if( Synth.verbosity >= Synth.TERSE )
		{
			System.out.println( "JSyn: connect( " +
				       Integer.toHexString(outPort.peerToken) +
				", " + outPort.name +
				", " + outIndex +
				", " + Integer.toHexString(inPort.peerToken) +
				", " + inPort.name +
				", " + inIndex + " )" );
		}

		int nativeError = Synth.ConnectUnits( outPort.peerToken, outPort.portIndex, outIndex,
			inPort.peerToken, inPort.portIndex, inIndex );
		if( nativeError < 0 ) throw new SynthException( nativeError, outPort.name, outPort.peerToken, inPort.peerToken );
//		inPort.addConnection( outPort );
//		outPort.addConnection( inPort );
	}

	static void disconnectUnits( SynthPort port, int index )
	throws SynthException
	{
		int err = Synth.DisconnectUnits( port.peerToken, port.portIndex, index );
		if( err < 0 ) throw new SynthException( err, port.name, port.peerToken, index );
	}

}
