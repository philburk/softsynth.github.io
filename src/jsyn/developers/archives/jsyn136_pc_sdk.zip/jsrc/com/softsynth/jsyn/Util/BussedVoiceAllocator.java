package com.softsynth.jsyn.util;
import java.util.*;
import com.softsynth.jsyn.*;
/** Voice Allocator that mixes the voice onto a bus using a BusWriter.
 * Uses an abstract method makeVoice() which must be defined in later classes.<br>
 * Here is an example of how to define makeVoice from TJ_PlayKeys1.
 * It creates an allocator with a maximum of 4 voices. When a new voice is required,
 * it is created using the method below.
 <pre>
 		BussedVoiceAllocator ringAllocator = new BussedVoiceAllocator( 4 )
			{
				public SynthCircuit makeVoice() throws SynthException
				{
					SynthNote circ = new RingModBell();
					return addVoiceToMix( circ ); // mix through bus writer
				}
			};
 </pre>
 * Mixed result can be obtained using from a SynthOutput port obtained using getOutput()
 * or the public member "output".
 * 
 * @see TJ_PlayKeys1
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see BusWriter
 */
public abstract class  BussedVoiceAllocator extends VoiceAllocator
{
	BusReader     busReader;
	Vector        writers;
	public SynthOutput   output;

	public BussedVoiceAllocator( int maxVoices ) throws SynthException
	{
		super( maxVoices );
		writers = new Vector(); // hold references to busWriters so they don't get deleted
		busReader = new BusReader( );
		output = busReader.output;
/* Set priority low so that BusReader can get current data from bus.
** The Bus_Writes will run at a higher default priority.
*/
		busReader.setPriority(Synth.PRIORITY_LOW);
		busReader.start();
	}
	
	public SynthCircuit addVoiceToMix( SynthCircuit circuit ) throws SynthException
	{
		BusWriter busWriter = new BusWriter();
		writers.addElement( busWriter ); // hold references to busWriters so they don't get deleted
		circuit.output.connect( busWriter.input );
		busWriter.busOutput.connect( busReader.busInput );
		busWriter.start();
		return circuit;
	}
	
	public SynthOutput getOutput()
	{
		return busReader.output;
	}
}
