package com.softsynth.jsyn.view11x;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.util.*;

/**
 * Panel for harmonic synthesis of a wave table for JSyn
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class WaveMaker extends Panel
{
	HarmonicTable   table;
	HarmonicFader[] faders;
	int             numSamples;
	int             numPartials;
	public short[]  data;
	Button          sawButton;
	Button          squareButton;
	Button          triButton;
	Button          clearButton;
	double          minVal = 0.0;
	double          maxVal = 0.0;
	WaveDisplay     display;

	public WaveMaker( HarmonicTable table, WaveDisplay display )
	{
		this.table = table;
		this.display = display;
		numSamples = table.length(); /* Assume includes guard point. */
		numPartials = table.getNumPartials();
		data       = new short[numSamples];
		faders     = new HarmonicFader[numPartials];

		setLayout( new GridLayout(1,0) );

		for( int i=0; i<numPartials; i++ )
		{
			faders[i] = new HarmonicFader( this, i );
			add( faders[i] );
		}

		add( sawButton = new Button("Saw"));
		sawButton.addActionListener(	new ActionListener() {
					public void actionPerformed(ActionEvent e)
					{ handleSawtoothButton(); } } );

		add( squareButton = new Button("Sqr"));
		squareButton.addActionListener(	new ActionListener() {
					public void actionPerformed(ActionEvent e)
					{ handleSquareButton(); } } );
		
		add( triButton = new Button("Tri"));
		triButton.addActionListener(	new ActionListener() {
					public void actionPerformed(ActionEvent e)
					{ handleTriButton(); } } );
		
		add( clearButton = new Button("Clr"));
		clearButton.addActionListener(	new ActionListener() {
					public void actionPerformed(ActionEvent e)
					{ handleClearButton(); } } );
		
		table.clear();
		updateFaders();
	}
	
	void handleSawtoothButton()
	{
		table.sawtooth();
		updateFaders();
		display.repaint();
	}
	void handleSquareButton()
	{
		table.square();
		updateFaders();
		display.repaint();
	}
	void handleTriButton()
	{
		table.triangle();
		updateFaders();
		display.repaint();
	}
	void handleClearButton()
	{
		table.clear();
		updateFaders();
		display.repaint();
	}
	
	void setPartial( int index, double value )
	{
		table.setPartial( index, value );
		table.build();
		display.repaint();
	}
	
	void updateFaders()
	{
		for( int h=0; h<numPartials; h++ )
		{
			faders[h].setValue( table.getPartial(h) );
		}
	}
}

class HarmonicFader extends Panel  implements CustomFaderListener
{
	final static int range = 100;
	final static int halfRange = range/2;
	CustomFader  fader;
	Label        label;
	int          index;
	WaveMaker    maker;

	public HarmonicFader( WaveMaker maker, int index )
	{
		this.index = index;
		this.maker = maker;
		setLayout( new BorderLayout() );
		fader = new CustomFader( Scrollbar.VERTICAL, range, 10, 0, range );
		fader.addCustomFaderListener( this );
		add("Center",fader);
		label = new Label(Integer.toString(index + 1)); /* Zero is first harmonic. */
		add("South",label);
	}

/* Value can range from -1.0 to 1.0 which map to range and 0 respectively. */
	public void setValue( double val )
	{
		int ival = (int) ((double)halfRange - (val * (double)halfRange));
		fader.setValue(ival);
	}
	
/** Any class listening to a CustomFader must implement CustomFaderListener by defining this method */
    public void customFaderValueChanged(Object fader, int value)
	{
		maker.setPartial( index, (double) (halfRange-value) / (double)halfRange );
	}
}