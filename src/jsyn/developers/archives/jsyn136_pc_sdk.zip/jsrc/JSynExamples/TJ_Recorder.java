/** 
 * Record and Playback sound using LineIn.
 * Uses AWT 1.1 for the GUI.
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package JSynExamples;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view11x.*;
import com.softsynth.jsyn.util.*;
import com.softsynth.jsyn.circuits.*;

public class TJ_Recorder extends Applet
{
	LineIn                 lineIn;
	LineOut                lineOut;
	final static int       NUM_CHANNELS = 1;
	final static double    RECORD_TIME = 5.0; // seconds
	MyRecorder             recorder;
	
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_Recorder applet = new TJ_Recorder();
		AppletFrame frame = new AppletFrame("Record and Playback Sound.", applet);
		frame.resize(500,200);
		frame.show();
		frame.test();
	}
				
/*
 * Setup synthesis.
 */
	public void start()
	{
//		setLayout( new GridLayout(0,1) );
		try
		{

		Synth.initialize();
		
/* Make waveform unit generators. */
		lineIn = new LineIn();
		lineOut = new LineOut();

/* Use a recorder to record and playback captured audio. */
		recorder = new MyRecorder( RECORD_TIME, Synth.DEFAULT_FRAME_RATE/4, NUM_CHANNELS );

		for( int i=0; i<NUM_CHANNELS; i++ )
		{
			lineIn.output.connect( i, recorder.input, i );
			recorder.output.connect( i, lineOut.input, i );
		}

		add( recorder.buildGUI() );
		
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	
/* Synchronize Java display. */
		getParent().validate();
		getToolkit().sync();
	}


	public void stop()
	{
		lineOut.delete();
		lineOut = null;
		removeAll(); // remove portFaders
/* Turn off tracing. */
		Synth.verbosity = Synth.SILENT;
/* Stop synthesis engine. */
		Synth.terminate();
	}
	
	class MyRecorder extends Recorder
	{
		public MyRecorder( double seconds, double frameRate, int numChannels )
		{
			super( seconds, frameRate, numChannels );
		}
		
	/** Record a block of sound.
	*/
	   	public void record( boolean ifLoop )
	   	{
	   		Synth.start( Synth.FLAG_ENABLE_INPUT | Synth.FLAG_DISABLE_OUTPUT, frameRate );
	   		lineIn.start();
	   		super.record( ifLoop );
	   	}		

	/** Play back the recorded sound.
	*/
	   	public void play(  boolean ifLoop )
	   	{
	   		Synth.start( 0, frameRate );
	   		lineOut.start();
	   		super.play( ifLoop );
	   	}
			
	/** Stop playing or recording.
	*/
	   	public void stop()
	   	{
	   		super.stop();
	   		lineIn.stop();
	   		lineOut.stop();
	   		Synth.stop();
	   	}
	}
}

/** Define a class that records sound into an in memory sample and plays it back.
*/
class Recorder
{
   	SynthSample        sample;
   	SampleWriter       sampleWriter;
   	SampleReader       sampleReader;
   	public SynthInput  input;
   	public SynthOutput output;
   	Button             recordButton, playButton, stopButton;
   	Checkbox           loopBox;
   	double             frameRate;
   	int                mode;
   	public final static int STOPPED = 0;
   	public final static int PLAYING = 1;
   	public final static int RECORDING = 2;

   	public Recorder( double seconds, double frameRate, int numChannels )
   	{
		this.frameRate = frameRate;
		
   		sample = new SynthSample( (int)(frameRate * seconds), numChannels );
			
   		switch( numChannels )
		{
		case 1:
			sampleWriter = new SampleWriter_16F1();
   			sampleReader = new SampleReader_16F1();
			break;
		case 2:
			sampleWriter = new SampleWriter_16F2();
   			sampleReader = new SampleReader_16F2();
			break;
		default:
			throw new SynthException("Only support 1 or 2 channel recording.");
		}
			
   		input = sampleWriter.input;
   		output = sampleReader.output;
   	}

   	public Panel buildGUI()
   	{
   		Panel panel = new Panel();
   		panel.add( recordButton = new Button("Record") );
/* Define an actionListener class that will record() when the button is pressed. */
   		recordButton.addActionListener(
   			new ActionListener()
   			{
   				public void actionPerformed(ActionEvent e)
   				{
   					record( loopBox.getState() );
   				}
   			} );
			
			
   		panel.add( stopButton = new Button("Stop") );
   		stopButton.addActionListener(	new ActionListener() {
   				public void actionPerformed(ActionEvent e)
   				{ stop();	} } );
			
   		panel.add( playButton = new Button("Play") );
   		playButton.addActionListener(	new ActionListener() {
   				public void actionPerformed(ActionEvent e)
   				{ play( loopBox.getState() );	} } );
			
   		panel.add( loopBox = new Checkbox("Loop") );
			
   		return panel;
   	}
		
   	void setMode( int mode )
   	{
   		this.mode = mode;
   		switch( mode )
   		{
   		case STOPPED:
   			recordButton.setEnabled( true );
   			playButton.setEnabled( true );
   			stopButton.setEnabled( false );
   			break;
   		case PLAYING:
   		case RECORDING:
   			recordButton.setEnabled( false );
   			playButton.setEnabled( false );
   			stopButton.setEnabled( true );
   			break;
   		}	
   	}
		
/** Record a block of sound.
*/
   	public void record( boolean ifLoop )
   	{
   		sampleWriter.start();
   		if( ifLoop )
   		{
   			sampleWriter.samplePort.queueLoop( sample );
   		}
   		else
   		{
   			sampleWriter.samplePort.queue( sample );
   		}
   		setMode( RECORDING );
   	}		

/** Play back the recorded sound.
*/
   	public void play(  boolean ifLoop )
   	{
   		sampleReader.start();
   		if( ifLoop )
   		{
   			sampleReader.samplePort.queueLoop( sample );
   		}
   		else
   		{
   			sampleReader.samplePort.queue( sample );
   		}
    	setMode( PLAYING );
  	}
		
/** Stop playing or recording.
*/
   	public void stop()
   	{
   		sampleWriter.samplePort.clear();
   		sampleWriter.stop();
   		sampleReader.samplePort.clear();
   		sampleReader.stop();
    	setMode( STOPPED );
   	}
}

