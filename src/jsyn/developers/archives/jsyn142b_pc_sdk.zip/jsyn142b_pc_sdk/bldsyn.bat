@rem Build JSyn and Examples
@set MYCLASSES=classes
@set CLASSPATH=%MYCLASSES%
@set SSDIR=jsrc\com\softsynth
@set JSYNDIR=%SSDIR%\jsyn
set JVCOM=%JAVAC% -nowarn -d %MYCLASSES% 
set JAVAC=javac
%JVCOM% %SSDIR%\util\*.java %SSDIR%\view\*.java %SSDIR%\math\*.java
%JVCOM% %JSYNDIR%\*.java %JSYNDIR%\view102\*.java %JSYNDIR%\util\*.java
%JVCOM% %JSYNDIR%\view11x\*.java %JSYNDIR%\view\*.java %JSYNDIR%\circuits\*.java
rem ALL DONE!
