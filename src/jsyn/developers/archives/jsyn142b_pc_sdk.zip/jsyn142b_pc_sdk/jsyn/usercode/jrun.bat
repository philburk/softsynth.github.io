@rem Run User JSyn Program
set CLASSPATH=.;..\..\classes
java %1%

