/**
 * Beep when a button is pressed.
 * Demonstrates starting and stopping an oscillator using JSyn.
 *
 * @author (C) 1998 Phil Burk, All Rights Reserved
 */

package mystuff;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/* DO: Change TJ_Beep to match the name of your class. Must match file name! */
public class TJ_Beep extends Applet
{
/* DO: Declare Synthesis Objects here */
	SineOscillator   myBeep;
	EnvelopePlayer   myEnvPlayer;
	SynthEnvelope    myEnv;
	LineOut          myOut;
	
	Button           hitme;
	
/* Can be run as either an application or as an applet. */
	public static void main(String args[])
	{
/* DO: Change TJ_Beep to match the name of your class. Must match file name! */
	   TJ_Beep  applet = new TJ_Beep();
	   AppletFrame frame = new AppletFrame("Test JSyn", applet);
	   frame.resize(300,100);
	   frame.show();
 /* Begin test after frame opened so that DirectSound will use Java window. */
	   frame.test();
	}

 /*
  * Setup synthesis by overriding start() method.
  */
	public void start()  
	{
	   try
	   {
		  Synth.startEngine(0);
 /* DO: Your setup code goes here. ******************/
 /* Create unit generators. */
			myBeep = new SineOscillator()   ;
			myEnvPlayer = new EnvelopePlayer();
			myOut = new LineOut();

/* Connect units together. */
			myBeep.output.connect( myEnvPlayer.amplitude );
			myEnvPlayer.output.connect( myOut.input );
			
/* Create Envelope to be played. */
			double[] data =
			{
				0.10, 1.0,  /* duration,value pair for frame[0] */
				0.30, 0.5,
				0.80, 0.0  
			};
			myEnv = new SynthEnvelope( data );
			
			myBeep.amplitude.set( 0.5 );
			
/* Create a button that causes a beep. */
			add( hitme = new Button("Beep") );
			
/* Start units. */
			myEnvPlayer.start();
			myBeep.start();
			myOut.start();
/* *****************************************/

/* Synchronize Java display to make buttons appear. */
			getParent().validate();
			getToolkit().sync();
			
	   } catch(SynthException e) {
		  SynthAlert.showError(this,e);
	   }
	}

/*
 * Clean up synthesis by overriding stop() method.
 */
	public void stop()  
	{
	   try
	   {
 /* Your cleanup code goes here. */
		  removeAll(); // remove components from Applet panel.
		  myBeep.stop();
		  Synth.stopEngine();
	   } catch(SynthException e) {
		  SynthAlert.showError(this,e);
	   }
   }
   
   	public boolean action(Event evt, Object what)
   	{
   		try
   		{
			if( evt.target == hitme )
   			{
/* Select random frequency. */
				myBeep.frequency.set( (Math.random() * 440.0) + 60.0 );
/* Queue envelope to trigger sound. */
   				myEnvPlayer.envelopePort.clear();
   				myEnvPlayer.envelopePort.queue( myEnv );
   				return true;
   			}
   		} catch (SynthException e) {
   			SynthAlert.showError(this,e);
   			return true;
   		}
   		return false;
    }
}