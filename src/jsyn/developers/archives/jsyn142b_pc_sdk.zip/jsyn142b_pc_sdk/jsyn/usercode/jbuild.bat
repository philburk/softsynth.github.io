@rem Build User JSyn Program
set CLASSDIR=..\..\classes
set CLASSPATH=.;%CLASSDIR%
javac -d  %CLASSDIR%  *.java
