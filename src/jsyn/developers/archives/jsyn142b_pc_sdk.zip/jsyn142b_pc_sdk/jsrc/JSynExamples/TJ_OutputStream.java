
package JSynExamples;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.util.*;
import com.softsynth.jsyn.view11x.*;

/** 
 * Generate a stream of audio data by doing DSP calculations in Java.
 * Output the synthesized data using SampleQueueOutputStream
 *
 * @author (C) 2000 Phil Burk, All Rights Reserved
 */
public class TJ_OutputStream extends Applet implements Runnable
{
	SampleReader       mySampler;
	LineOut            myOut;
	final static int   FRAMES_PER_BLOCK = 400; // number of frames to synthesize at one time
	final static int   FRAMES_IN_BUFFER = 8*1024;
	final static int   NUM_CHANNELS = 2;
	final static int   SAMPLES_PER_BLOCK = FRAMES_PER_BLOCK * NUM_CHANNELS;
	short[]            data = new short[SAMPLES_PER_BLOCK];
	double             phaseIncr = 0.02;
	double             phase = 0.0;
	double             freqScalar = 1.01;
	SampleQueueOutputStream  outStream;
	Thread             thread;
	Button             startButton, stopButton;
	
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_OutputStream applet = new TJ_OutputStream();
		AppletFrame frame = new AppletFrame("Test SampleQueueOutputStream", applet);
		frame.resize(600,300);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{
		setLayout( new GridLayout(0,1) );
		
		try
		{
// Make sure we are using the necessary version of JSyn
		Synth.requestVersion( 140 );
		
// Start synthesis engine.
		Synth.startEngine( 0 );

// Create SynthUnits to play sample data.
		if( NUM_CHANNELS == 1 )
		{
			mySampler = new SampleReader_16F1();
		}
		else if( NUM_CHANNELS == 2 )
		{
			mySampler = new SampleReader_16F2();
		}
		else
		{
			throw new RuntimeException("This example only support mono or stereo!");
		}
		myOut = new LineOut();

// Create a stream that we can write to.
		outStream = new SampleQueueOutputStream( mySampler.samplePort, FRAMES_IN_BUFFER, NUM_CHANNELS );
		
// Connect SynthUnits to output.
		mySampler.output.connect( 0, myOut.input, 0 );
		mySampler.output.connect( NUM_CHANNELS - 1, myOut.input, 1 );

// Show faders so we can manipulate sound parameters.
		add( new PortFader( mySampler.amplitude, 0.7, 0.0, 1.0 ) );

// Start execution of units.
		myOut.start();
		
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	
		add( startButton = new Button("Start") );
   		startButton.addActionListener(
   			new ActionListener()
   			{
   				public void actionPerformed(ActionEvent e)
   				{
   					startStream();
   				}
   			} );

		add( stopButton = new Button("Stop") );
   		stopButton.addActionListener(
   			new ActionListener()
   			{
   				public void actionPerformed(ActionEvent e)
   				{
   					stopStream();
   				}
   			} );
		
// Synchronize Java display.
		getParent().validate();
		getToolkit().sync();
	}

	public void run()
	{
		try
		{
			while( thread != null )
			{
				sendBuffer();
			}
		} catch( SynthException e )
		{
			System.out.println("run() caught " + e );
		}
	}

/** Generate an audio signal and send it to the stream to be heard.
 */
	void sendBuffer()
	{
	// synthesize some audio
		int i=0;
		while( i<SAMPLES_PER_BLOCK )
		{
		// calculate triangle wave from phase
			double tri;
			if( phase > 0.0 ) tri = 1.0 - (2.0 * phase);
			else tri = 1.0 + (2.0 * phase);
		// convert to full amplitude signed 16 bit
			data[i++] = (short) (tri * 32767.0);
		// write lower amplitude sawtooth to optional second channel
			if( NUM_CHANNELS > 1 ) data[i++] = (short) (phase * 8000.0); 
		// advance phaser and wrap between -1.0 and +1.0
			phase += phaseIncr;
			if( phase > 1.0 ) phase -= 2.0;
		}
	// make frequency slide up and down
		phaseIncr *= freqScalar;
		final double SCALAR = 0.99;
		if( phaseIncr > 0.02 ) freqScalar = SCALAR;
		else if( phaseIncr < 0.002 ) freqScalar = 1.0 / SCALAR;
	
	// Write data to the stream.
	// Will block if there is not enough room so run in a thread.
		outStream.write( data, 0, FRAMES_PER_BLOCK );
	}
	
	public void stop()
	{
		try
		{
			thread = null;
			
// Delete unit peers.
			mySampler.delete();
			mySampler = null;
			myOut.delete();
			myOut = null;
			removeAll(); // remove portFaders
// Turn off tracing.
			Synth.verbosity = Synth.SILENT;
// Stop synthesis engine.
			Synth.stopEngine();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}

	void startStream()
	{
	// Prefill output stream buffer so that it starts out full.
		while( outStream.available() > FRAMES_PER_BLOCK ) sendBuffer();
	// Start slightly in the future so everything is synced.
		int time = Synth.getTickCount() + 4;
		mySampler.start( time );
		outStream.start( time );
			
	// launch a thread to keep stream supplied with data
		thread = new Thread( this );
		thread.start();
	}
	
	void stopStream()
	{
		System.out.println("Wait for flush().");
		outStream.flush(); // wait for all data already written to stream to be played
		System.out.println("flush() done.");
		thread = null;
		int time = Synth.getTickCount();
		mySampler.stop( time );
		outStream.stop( time );
	}
}
