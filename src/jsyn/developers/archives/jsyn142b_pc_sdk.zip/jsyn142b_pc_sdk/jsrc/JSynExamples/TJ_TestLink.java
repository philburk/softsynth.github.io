/**
 * Test link to native code in Java Audio Synthesiser
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */
package JSynTests;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

public class TJ_TestLink extends Applet
{

	public void start() // throws SynthEngineException
	{
		int  getFramesPerTick = Synth.getFramesPerTick();
		System.out.println("getFramesPerTick = " + getFramesPerTick);
	}
	
	public void alive()
	{
		System.out.println("TJ_TestLink is alive!");
	}
}
