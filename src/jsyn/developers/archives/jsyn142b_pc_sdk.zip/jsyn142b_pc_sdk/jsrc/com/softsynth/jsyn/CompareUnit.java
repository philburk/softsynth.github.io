package com.softsynth.jsyn;
import java.util.*;

/**
 *	CompareUnit unit.
 <P>
 Output logic level value.
 <P>
 output = ( inputA > InputB ) ? 1.0 : 0.0;
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 006
 * @see MinimumUnit
 * @see SchmidtTrigger
 */

public class CompareUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public CompareUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext,  "Logic_Compare", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public CompareUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public CompareUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
