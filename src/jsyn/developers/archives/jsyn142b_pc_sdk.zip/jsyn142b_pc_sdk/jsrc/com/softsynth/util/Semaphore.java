package com.softsynth.util;

/** Atomic sepahore.
 */
public class Semaphore
{
	boolean inUse = false;
	
	public synchronized boolean  request()
	{
		boolean result = false;
		if( !inUse )
		{
			result = inUse = true;
		}
		return result;
	}
	
	public synchronized void free()
	{
		inUse = false;
	}
}
