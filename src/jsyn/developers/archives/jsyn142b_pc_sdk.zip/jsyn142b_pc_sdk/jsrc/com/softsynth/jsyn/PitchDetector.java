package com.softsynth.jsyn;
import java.util.*;

/**
 *	PitchDetector unit.
 *
 * Analyses an input signal and outputs an estimated frequency.
 * 
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class PitchDetector extends SynthUnit 
{
	public SynthInput input;
	public SynthOutput period;
	public SynthOutput confidence;

 	public PitchDetector( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Table_Lookup", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		period = new SynthOutput( this, "Period" );
		confidence = new SynthOutput( this, "Confidence" );
	}
/**
 *	Create a PitchDetector that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public PitchDetector( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public PitchDetector( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
