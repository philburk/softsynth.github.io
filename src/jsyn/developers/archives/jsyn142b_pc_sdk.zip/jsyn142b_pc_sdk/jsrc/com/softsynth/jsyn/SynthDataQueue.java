package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthDataQueue class for Java Audio Synthesis.
 * Root class for SynthEnvelopeQueue and SynthSampleQueue.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthDataQueue extends SynthPort
{
	SynthDataQueue( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	SynthDataQueue( SynthSound sound ) throws SynthException
	{
		super( sound, "Data" );
	}

/**
 * Clear any data on this queue.
 * @exception SynthException	 If queue name is not recognized.
 */
	public void clear()
	throws SynthException
	{
		int nativeError = Synth.ClearDataQueue( sound.context, peerToken, portHash );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken );
	}
	public void clear( int time )
	throws SynthException
	{
		int nativeError = Synth.ClearDataQueueAt( sound.context, time, peerToken, portHash );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken );
	}

/* ================================
** Implementation of methods in a way that is non-specific to samples or envelopes.
** The subclasses SynthSampleQueue and SynthEnvelopeQueue will only allow
** the appropriate data class to be passed.
*/

/*
 * Queue all or a portion of this data to be played once by this SynthUnit.
 * Queued data will be played in First-In-First-Out(FIFO) order.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( SynthChannelData channelData, int startFrame, int numFrames, int flags )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueData( sound.context, peerToken, portHash, channelDataToken, startFrame, numFrames, flags);
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken, startFrame );
	}
	public void queue( SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		queue( channelData, startFrame, numFrames, 0 );
	}

/*
 * Queue all or a portion of this channelData to be played by this SynthUnit in a loop.
 * If there is any channelData data after this in the queue then this portion will not be played.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueData( sound.context, peerToken, portHash, channelDataToken, startFrame, numFrames, Synth.FLAG_LOOP_IF_LAST );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}
/*
 * Queue all or a portion of this channelData to be played once by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( int time, SynthChannelData channelData, int startFrame, int numFrames, int flags)
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueDataAt( sound.context, time, peerToken, portHash, channelDataToken, startFrame, numFrames, flags );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}
	public void queue( int time, SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		queue( time, channelData, startFrame, numFrames, 0 );
	}
/*
 * Queue all or a portion of this channelData to be played in a loop by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( int time, SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueDataAt( sound.context, time, peerToken, portHash, channelDataToken, startFrame, numFrames, Synth.FLAG_LOOP_IF_LAST );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}

/**
 *	Convenience method that will queue the attack portion of a channelData and the sustain loop if it exists.
 *	This could be used to implement a NoteOn method.
 *
 * @exception SynthException When placement in the queue fails.
 */
	public void queueOn( int time, SynthChannelData channelData )
	throws SynthException
	{
		clear( time );

		if( channelData.getSustainBegin() < 0 )
		{
		// no sustain loop, handle release
			if( channelData.getReleaseBegin() < 0 )
			{
				queue( time, channelData, 0, channelData.getNumFrames() );	 /* No loops. */
			}
			else
			{
				queue( time, channelData, 0, channelData.getReleaseEnd() );		
				queueLoop( time, channelData, channelData.getReleaseBegin(), channelData.getReleaseSize() );
			}
		}
		else
		{
			if( channelData.getSustainEnd() > 0 )
			{
				int size = channelData.getSustainBegin();
			// Is there an initial portion before the sustain loop?
				if( size > 0 )
				{
					queue( time, channelData, 0, size );
				}
				size = channelData.getSustainSize();
				if( size > 0 )
				{
					queueLoop( time, channelData, channelData.getSustainBegin() , size );
				}
			}
		}
	}

	public void queueOn( SynthChannelData channelData )
	throws SynthException
	{
		queueOn( sound.synthContext.getTickCount(), channelData );
	}
	
	
/**
 *	Convenience method that will queue the decay portion of a channelData, or the gap and
 *	release loop portions if they exist. 
 *	This could be used to implement a NoteOff method.
 * @ifStop Will cause Synth.FLAG_AUTO_STOP to be passed if decay portion queued without
 *    a release loop. This will stop execution of the unit.
 * @exception SynthException  When placement in the queue fails.
 */
	public void queueOff( int time, SynthChannelData channelData, boolean ifStop )
	throws SynthException
	{
     	if( channelData.getSustainBegin() >= 0 )	 /* Sustain loop? */
		{
			int relSize = channelData.getReleaseSize();
			if( channelData.getReleaseBegin() < 0 )
			{	/* Sustain loop, no release loop. */
				int susEnd = channelData.getSustainEnd();
				int size = channelData.getNumFrames() - susEnd;
				//System.out.println("queueOff: size = " + size );
				if( size <= 0 )
				{
				// always queue something so that we can stop the loop 20001117
					size = 1;
					susEnd = channelData.getNumFrames() - 1;
				}
				queue( time, channelData, susEnd, size,
						   (ifStop ? Synth.FLAG_AUTO_STOP : 0) );

			}
			else if( channelData.getReleaseBegin() >  channelData.getSustainEnd() )
			{  /* Queue gap between sustain and release loop. */
				queue( time, channelData, channelData.getSustainEnd(),
					channelData.getReleaseEnd() - channelData.getSustainEnd() );		
				if( relSize > 0 ) queueLoop( time, channelData, channelData.getReleaseBegin(), relSize );
			}
			else if( relSize > 0 ) 
			{  /* No gap between sustain and release. */
				queueLoop( time, channelData, channelData.getReleaseBegin(), relSize );
			}
		}
		/* If no sustain loop, then nothing to do. */
	}
/**
 * Passes false to queueOff for ifStop
 * @exception SynthException  When placement in the queue fails.
 */
	public void queueOff( int time, SynthChannelData channelData )
	throws SynthException
	{
		queueOff( time, channelData, false );
	}
	
	public void queueOff( SynthChannelData channelData )
	throws SynthException
	{
		queueOff( sound.synthContext.getTickCount(), channelData );
	}
/**
 * @return number of frames read or written by a port
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public int getNumFramesMoved( int partIndex )
	throws SynthException
	{
		int value = Synth.GetPortFrames( sound.context, peerToken, portHash, partIndex);
/* Check for error return indicator disguised as -1. */
		if( value < -1)
		{
			throw new SynthException( "Error in getNumFramesMoved()" );
		}
		return value;
	}
	public int getNumFramesMoved()
	throws SynthException
	{
		return getNumFramesMoved(0);
	}


}
