package com.softsynth.jsyn;
import java.util.*;
import com.softsynth.util.*;

/**
 * This class provides a context for the synthesis to occur.
 * By using separate contexts, multiple JSyn programs can run at different
 * sample rates, including non-real-time.
 * This is particularly important when writing Applets for a
 * browser because their execution may overlap.<p>
 * 
 * The methods are similar to the Synth class methods.
 * But the Synth class creates a shared SynthContext for compatability with older apps.
 * You should delete the context when you are through using it to recover the allocated memory.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 142
 * @see Synth
 * @see SynthObject
 */
public class SynthContext  
{
	private int     context;
	private boolean gotInputPermission = false;
	private SharedSleeper sleeper;
	private Vector trackedObjects; // Keep list of objects so that garbage collector doesn't kill them.
	private Vector trackingThreads;
	
	boolean deleteByGarbageCollector = true; // DON'T CHANGE DEFAULT
	int          flags = 0;
	int          openCount;
	double       millisPerTick;
	

	public SynthContext()
	{
		context = Synth.CreateContext();
		if( context == 0 )
		{
			throw new SynthException("Could not allocate native SynthContext!");
		}
		
		trackedObjects = new Vector();
		trackingThreads = new Vector();
				
		// Create SharedSleeper with instance method that calls engine.
		sleeper = new SharedSleeper()
			{
				public synchronized int bumpIndex()
				{
					// call native 
					Synth.SleepUntilTick( getContext(), getTickCount() + 1 );
					return getTickCount();
				};
			};
	}
	
	public void delete()
	{
		//System.out.println("SynthContext.delete() : openCount = " + openCount );
		if( openCount > 0 ) terminate();
		Synth.DeleteContext( context );
		context = 0;
	}
	
	protected int getContext()
	{
		return context;
	}
	
	public int debug( )
	{
		return debug( Synth.DEBUG_REPORT, 0 );
	}
	
	public int debug( int command, int data )
	{
		return Synth.Debug( context, command, data );
	}

/**
 *	Returns the fraction of critical resources used by synthesis engine.
 *  A value of 0.5 would be 50%.
 *
 *	@return fraction of resources used.
 */
	public double getUsage()
	{
		return Synth.GetUsage( context );
	}

/**
 *	@return Number of units, samples, tables and other objects allocated.
 */
	public int getObjectCount()
	{
		return Synth.GetObjectCount( context );
	}
	
/**
 *	Returns index of last calculated frame.
 *	The frame index will tend to jump upwards because frames are calculated in 
 *	large blocks by a high priority process.
 *
 *	@return Index of last calculated frame.
 */
	
	public int getFrameCount()
	{
		return Synth.GetFrameCount( context );
	}
	
/** Get current time in ticks. This is the basic clock use for scheduling in JSyn.
 *	@return Count of synthesis ticks.
 */
	public int getTickCount()
	{
		return Synth.GetTickCount( context );
	}

/**
 *	@return Number of audio frames per clock tick.
 */
	public int getFramesPerTick()
	{
		return Synth.GetFramesPerTick( context );
	}
	
/** Rate that frames are generated, typically 44100.0.
 *	@return Number of audio frames per second.
 */
	public double getFrameRate( )
	{
		return Synth.GetFrameRate( context );
	}
	
/**
 *	@return Number of clock ticks per second.
 */
	public double getTickRate( )
	{
		return Synth.GetTickRate( context );
	}
	
 /**
 * Sleep until the specified tick is reached.
 * @exception SynthException	 If timer not running.
 */
	public void sleepUntilTick( int tick )
	throws SynthException
//	throws InterruptedException
	{
		if( (flags & Synth.FLAG_NON_REAL_TIME) != 0 )
		{
			try
			{
				sleeper.addThread();
				sleeper.sleepUntilIndex( tick );
			} catch( InterruptedException e )
			{
				// System.err.println("sleepUntilIndex() interrupted. FIXME");
			}
		}
		else
		{
			int current = getTickCount();
			while( (tick-current) > 0 )
			{
				if( openCount == 0 ) break;
				sleepForTicks(tick-current);
				current = getTickCount();
			}
		}
	}
		
/**
 * Used by sleep routines to keep FIFOs clear.
 *	@return errors from Synth engine running in background.
 */
	public void checkEngineErrors() 
	throws SynthException
	{
		int result = Synth.CheckEngineErrors( context );
		if( result < 0 )
		{
			throw new SynthException( result, "background engine error detected while sleeping" );
		}
	}
	
/**
 * Sleep for the specified number of ticks.
 * @exception SynthException	 If timer not running.
 */
	public void sleepForTicks( int ticks )
	throws SynthException
//	throws InterruptedException
	{
		//System.out.println("sleepForTicks(" + ticks + ")" + ", openCount = " + openCount);
		if( (flags & Synth.FLAG_NON_REAL_TIME) != 0 )
		{
			sleepUntilTick( ticks + getTickCount() );
		}
		else
		{
			int maxTicksPerSecond = (int) (getTickRate() / 2.0);
			if( maxTicksPerSecond < 1 ) throw new SynthException("getTickRate() = " + getTickRate());
			int ticksPerSleep;
			try{
				while( ticks > 0 )
				{
	// Don't sleep for more than a given time so that we can check background FIFO.
					if( ticks > maxTicksPerSecond ) ticksPerSleep = maxTicksPerSecond;
					else ticksPerSleep = ticks;
	// Use Java sleep to let other Java threads run.
					int millis = (int)((double)ticksPerSleep * millisPerTick) + 1;
					Thread.sleep(millis);
					ticks -= ticksPerSleep;
					if( openCount > 0 ) checkEngineErrors();
					else throw new SynthException("Engine stopped.");
				}
			} catch( InterruptedException e )
			{
				System.err.println("sleepForTicks() interrupted.");
			}
		}
	}
	
/**
 *	Calls initialize() and start( flags, frameRate ).
 *
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized void startEngine( int flags, double frameRate )
	throws SynthException
	{
		initialize();
		start( flags, frameRate );
	}

/** Ask for permission to turn on audio input. ABORT if not.
 */
	final boolean askInputPermission()
	{
		com.softsynth.jsyn.view102.MessageDialog dlg = new com.softsynth.jsyn.view102.MessageDialog(
			"This Java Applet is requesting permission to turn on the\n" +
			"microphone or other audio input.\n" +
			"Press OK to grant permission.",
			"OK", "DENY" );
		return ( dlg.ask() == 0 );
	}
	
/* DISABLED
 * If the flag Synth.FLAG_ENABLE_INPUT is set, and JSyn is running
 * as a plugin, then a dialog will appear asking for permission to
 * record from the microphone. If granted, then AudioInputPermission
 * will be set true. If not then the process will abort.
*/
/**
 * Starts execution of process that performs synthesis.
 * This must be called before performing any synthesis.
 * 
 * @param flags used to select options. Legal flags are Synth.FLAG_NON_REAL_TIME, Synth.FLAG_ENABLE_INPUT, Synth.FLAG_DISABLE_OUTPUT.
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized void start( int flags, double frameRate )
	throws SynthException
	{
		this.flags = flags;
		
		if( Synth.isPlugin && ((flags & Synth.FLAG_ENABLE_INPUT) != 0) && !gotInputPermission)
		{
			if( askInputPermission() )
			{
				gotInputPermission = true;
			}
			else
			{
				System.err.println("Aborting to prevent unauthorized use of microphone.");
				System.exit(0); // Bye Bye
			}
		}
		sleeper.setIndex( getTickCount() );
		
// System.out.println("JSyn Engine starting.");
		int err = Synth.Start( context, flags, frameRate );
// System.out.println("JSyn Engine started. Returned " + err);
		if( err < 0 ) throw new SynthException( err, flags );
		millisPerTick = 1000.0/getTickRate(); /* Cache on this side of native method interface. */
		if( Synth.verbosity > Synth.TERSE )
		{
			System.out.println("JSyn: V" + Synth.getVersion() + ", frame rate = " + getFrameRate() );
		}
	}
	
	public synchronized void start( int flags )
	throws SynthException
	{
		start( flags, Synth.DEFAULT_FRAME_RATE );
	}
	
/** Return SharedSleeper that is used to coordinate non-real-time synthesis.
 */
	public SharedSleeper getSleeper()
	{
		return sleeper;
	}
/**
 * Initialize Library.
 * This must be called before any other synthesis functions.
 * Resets AudioInputPermission.
 *
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized void initialize()
	throws SynthException
	{
		gotInputPermission = true; // FIXME - what is best default
/* Check for suitable version number in DLL. */
		int version;
		if( (version = Synth.getVersion()) != Synth.VERSION )
		{
			System.err.println("Version mismatch! Java = " + Synth.VERSION + ", 'native = " + version );
			throw new SynthException( Synth.JS_ERR_OBSOLETE, version );
		}
		int err = Synth.Initialize( context );
		if( err < 0 ) throw new SynthException( err, 0 );
		openCount += 1;
	}
	
/**
 * Starts execution of process using default frameRate.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public void startEngine( int flags )
	throws SynthException
	{
		startEngine( flags, Synth.DEFAULT_FRAME_RATE );
	}
/**
 * Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized void stopEngine( )
	throws SynthException
	{
		stop();
		terminate();
	}
/**
 * Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized void stop( )
	throws SynthException
	{
		if( sleeper != null )
		{
			sleeper.removeThread();
		}
		int err = Synth.Stop(context);
		if( err < 0 ) throw new SynthException( err, 0 );
	}

/**
 *	Terminate library.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized void terminate( )
	throws SynthException
	{
		if( Synth.verbosity > Synth.TERSE )
		{
			System.out.println( "Synth.terminate() called.");
		}
		deleteAll();
		openCount -= 1;
		int err = Synth.Terminate(context);
//		System.out.println( "Synth.Terminate() returned " + err);
		if( err < 0 ) throw new SynthException( err, 0 );
	}
/*
 * Attempt to reclaim engine resources by running garbage collector.
 */
	public void reclaim() // FIXME - make not public again
	{
		new Exception().printStackTrace();
		Runtime rt = Runtime.getRuntime();
		int lastNum = 0;
		int newNum = getObjectCount();
		while( newNum != lastNum )
		{
			lastNum = newNum;
			rt.gc();
			System.out.println("reclaim() - num = " + newNum);
			newNum = getObjectCount();
		}
		rt.runFinalization();
	}

/* Create container for units.
 * @exception SynthException	If sub sounds invalid.
 */
	int createCircuit( int[] peerArray, int flags )
	throws SynthException
	{
		int token;
		int numUnits = peerArray.length;
		token = Synth.CreateCircuit( context, peerArray, numUnits, flags );
		if( token < 0 ) throw new SynthException( token, numUnits );
		return token;
	}
	
/** Delete a synth object only if the engine is running to prevent Netscape hangs.
 * Also remove from tracking vector.
 */
	int delete( SynthObject sob )
	{
		trackedObjects.removeElement( sob );
		if( openCount > 0 )
		{
			return Synth.Delete( context, sob.getPeer() );
		}
		else return 0;
	}
	
/** Set trace flags for debugging. */
	public void setTrace( int mask )
	{
		Synth.verbosity = mask;
		Synth.SetTrace( context, mask );
	}
	public int getTrace()
	{
		return Synth.GetTrace( context );
	}
	
// --------------- object tracking moved from SynthObject --------
	
	public boolean isTrackingEnabled()
	{
		return trackingThreads.contains( Thread.currentThread() );
	}
	
/** Request that all SynthObjects created by <b>the currently executing thread</b>
 * be automatically tracked when created, or not. Calls can be nested.
 * @see track
 */
	public void enableTracking( boolean ifTrack )
	{
		if( ifTrack )
		{
			trackingThreads.addElement( Thread.currentThread() );
		}
		else
		{
			trackingThreads.removeElement( Thread.currentThread() );
		}
	}
	
/** Keep a reference to this object in a vector in the SynthObject class.
 * This will prevent the garbage collector from accidentally deleting a JSyn object that is
 * active but not referenced by any other Java objects.
 * It also allows the object to be deleted automatically by stopEngine()
 * or by calling deleteAll().
 */
	public void track( SynthObject sob )
	{
		trackedObjects.addElement( sob ); // keep reference
	}
	
/** Delete all units, SynthSamples, SynthEnvelopes and other Synth objects created since
 * Synth.startEngine() was called. This will be called automatically by
 * Synth.stopEngine().
 */
	public synchronized void deleteAll() throws SynthException
	{
		while( !trackedObjects.isEmpty() )
		{
			SynthObject sobj = (SynthObject) trackedObjects.lastElement();
//			System.out.println("deleteAll: deleting " + sobj );
			sobj.delete();
		}
		trackingThreads.removeAllElements();
	}
/**
 * Enable deletion of the native portion of SynthObjects (eg. units and samples)
 * when the Java portion is deleted by the Garbage Collector.<br>
 * Warning: enabling this can cause unexpected removal of objects that may be
 * making sound but are  no longer referenced by Java.
 * The sudden silence can be embarassing.<br>
 * Warning: disabling this can cause native resources to accumulate unless you explicitly
 * delete them using their delete() method.
 * This can consume memory and cause memory allocation to fail.<br>
 * The safest thing to do is to disable this and delete() your own objects
 * when you are through using them.
 * @param ifEnabled set true to enable deletion, false to disable, default is true
 * @see Synth.getObjectCount
 */
	public void enableDeletionByGarbageCollector( boolean ifEnabled )
	{
		deleteByGarbageCollector = ifEnabled;
	}
}
