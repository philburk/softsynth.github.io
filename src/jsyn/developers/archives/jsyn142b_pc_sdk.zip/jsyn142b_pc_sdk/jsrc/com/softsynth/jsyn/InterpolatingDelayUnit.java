package com.softsynth.jsyn;
import java.util.*;

/**
 *	InterpolatingDelayUnit
 <P>
 InterpolatingDelayUnit provides a variable time delay with an input and output.
 The internal data format is the same resolution as a SynthTable which is
 floating point if the sound processor supports it.
 The amount of delay can be varied from 0.0 to the delayTime specified at creation.
 The fractional delay values are calculated by linearly interpolating between
 adjacent values in the delay line.
 <P>
 This unit can be used to implement time varying delay effects such as a flanger
 or a chorus. It can also be used to implement physical models of acoustic instruments,
 or other tuneable delay based resonant systems.
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 * @see InterpolatingDelayUnit
 * @see SampleWriter_16F1
 */

public class InterpolatingDelayUnit extends SynthFilter
{
/** Delay time in seconds. Range: 0.0 to unit's maxDelayTime in seconds. */
	public SynthInput delay;

 	public InterpolatingDelayUnit( SynthContext synthContext, int calculationRate, double maxDelayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		super( synthContext, "Delay_Interpolated", calculationRate, (int) (0.5 + (maxDelayTime * synthContext.getFrameRate())) );
		delay = new SynthInput( this, "Delay" );
	}

	public InterpolatingDelayUnit(  int calculationRate, double delayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		this( Synth.getSharedContext(), calculationRate, delayTime );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public InterpolatingDelayUnit( SynthContext synthContext, double delayTime ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO, delayTime );
	}
	public InterpolatingDelayUnit( double delayTime ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO, delayTime );
	}
	public InterpolatingDelayUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, 1.0 );
	}
	public InterpolatingDelayUnit() throws SynthException
	{
		this( 1.0 );
	}
}
