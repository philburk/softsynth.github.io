package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import com.softsynth.util.NumericOutput;
import java.util.*;
import java.awt.*;

/**
 * Edit an envelope for use with noteOn() and noteOff().
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class NoteEnvelopeEditor extends Panel
{
	EnvelopeEditor envEeditor;
}
