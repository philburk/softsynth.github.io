package com.softsynth.view;

/** Interface to get values back from a CustomFader.  Any class
that uses a CustomFader will be notified of its value being changed 
by implementing this interface. <br>
@author Nick Didkovsky and Phil Burk
*/
public interface CustomFaderListener
{
  /** Handle a value change from a CustomFader.
   */
  	public void customFaderValueChanged( CustomFader fader, int value);
}
