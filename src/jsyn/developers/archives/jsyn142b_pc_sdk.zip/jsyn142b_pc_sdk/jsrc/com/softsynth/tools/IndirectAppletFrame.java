package com.softsynth.tools;
import java.util.*;
import java.awt.*;
import java.applet.*;
/**
 * Frame that allows a program to be run as either an Application or an IndirectApplet.
 * Used by JSyn example programs.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved 
 */

public class IndirectAppletFrame  extends Frame
{
	IndirectApplet indApplet;

	public IndirectAppletFrame(String frameTitle, IndirectApplet indApplet)
	{
		super(frameTitle);
		this.indApplet = indApplet;
		add("Center", indApplet);
		repaint();
	}

	public void test()
	{
		indApplet.init();
		indApplet.start();
	}

	public boolean handleEvent( Event evt )
	{
		switch (evt.id)
		{
			case Event.WINDOW_DESTROY:
				indApplet.stop();
				indApplet.destroy();
				dispose();
				try
				{
					System.exit(0);
				} catch( SecurityException e)
				{
					System.err.println("System.exit(0) not allowed by Java VM.");
				}
				return true;

			default:
				return super.handleEvent(evt);
		}			 
	}
}

