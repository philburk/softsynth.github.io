package com.softsynth.jsyn;
import java.util.*;

/** Equal Tempered Tuning
 * Calculates frequencies based on pitch indices.
 * Every interval between successive notes in the tuning is equal to the next, thus the name.
 * A typical Western piano is tuned to twelve tone equal temperament, or "12 TET".
 * A "12 TET" is what many traditional European and American musicians refer to as "in tune".
 * Traditional musicians from other parts of the world, however, tend to use non-equal tempered
 * tunings, for example, the Javanese 5-tone Slendro and 7-tone Pelog tunings.
 */
public class EqualTemperedTuning
{
	static final double BASE_MIDI_C = 8.1758224;  // very low C
	int      notesPerOctave;
	double   fundamental;
	double   inverseOctave;  // inverse of notesPerOctave;
	
/** Create a twelve tone equal tempered tuning with a fundamental of 110.0 Hz.
 */
	public EqualTemperedTuning()
	{
		this( 110.0, 12 );
	}
	
/** Create a twelve tone equal tempered tuning.
 * @param fundamental Frequency that will be returned when getFrequency(0) is called.
 */
	public EqualTemperedTuning( double fundamental )
	{
		this( fundamental, 12 );
	}
	
/** Create a twelve tone equal tempered tuning.
 * @param fundamental Frequency that will be returned when getFrequency(0) is called.
 * @param notesPerOctave Frequency will double when pitch increased by this amount. Typically 12 for Western music.
 */
	public EqualTemperedTuning( double fundamental, int notesPerOctave )
	{
		setFundamental( fundamental );
		setNotesPerOctave( notesPerOctave );
	}
	
	public void setNotesPerOctave( int notesPerOctave )
	{
		this.notesPerOctave = notesPerOctave;
		inverseOctave = 1.0 / notesPerOctave;
	}
	public int getNotesPerOctave()
	{
		return notesPerOctave;
	}
	
	public void setFundamental( double fundamental )
	{
		this.fundamental = fundamental;
	}
	public double getFundamental()
	{
		return fundamental;
	}

/** Calculate pitch based on frequency. The fundamental frequency will return zero.
 */	
	public double getPitch( double frequency )
	{
		return notesPerOctave * Math.log(frequency/fundamental) / Math.log( 2.0 );
	}

/** Calculate frequency based on pitch. A pitch of zero will return the fundamental frequency.
 * A pitch of 1.00 will return a frequency one semitone above the fundamental.
 * A pitch of 1.50 will return a frequency one semitone plus 50 cents above the fundamental.
 */
	public double getFrequency( double pitch )
	{
		return fundamental * Math.pow( 2.0, (pitch * inverseOctave) );
	}
	
/** Calculate frequency based on integer pitch and a detune value in cents.
 */
	public double getFrequency( int pitch, int cents )
	{
		return getFrequency( pitch + (cents/100.0) );
	}

/** Calculate frequency based on integer pitch.
 */
	public double getFrequency( int pitch )
	{
		return getFrequency( (double) pitch );
	}

/** Calculate MIDI pitch based on frequency in Hertz. Middle C is 60.0.
 */	
	public static double getMIDIPitch( double frequency )
	{
		return 12 * Math.log(frequency/BASE_MIDI_C) / Math.log( 2.0 );
	}
	
/** Calculate frequency in Hertz based on MIDI pitch. Middle C is 60.0.
 */
	public static double getMIDIFrequency( double pitch )
	{
		return BASE_MIDI_C * Math.pow( 2.0, (pitch * (1.0/12.0)) );
	}
	
/** Calculate frequency based on MIDI pitch. Middle C is (60,0).
 */
	public static double getMIDIFrequency( int pitch, int cents )
	{
		return getMIDIFrequency( pitch + (cents/100.0) );
	}
}
