package com.softsynth.jsyn.view102;
import java.awt.*;
import java.util.*;

/** Custom Fader written to work around bugs and other problems with existing Scrollbar class.
 * AWT 1.0.2 and AWT 1.1 versions are both derived from the InternalCustomFader class.
 * @see InternalCustomFader
@author Nick Didkovsky and Phil Burk
*/
public class CustomFader extends InternalCustomFader
{
	public CustomFader(int orientation, int val, int visible, int min, int max)
	{
		super( orientation, val, visible, min, max);
	}
	
/* Respond to 1.0.2 style AWT mouse actions. */
	public boolean mouseDown( Event evt, int x, int y )
	{
//		System.out.println("AWT1.0.2 - down " + x + ", " + y );
		handleMousePressed( evt.shiftDown(), x, y );
		return true;
	}
	public boolean mouseDrag( Event evt, int x, int y )
	{
		handleMouseDragged( x, y );
		return true;
	}
	public boolean mouseUp( Event evt, int x, int y )
	{
		handleMouseReleased( x, y );
		return true;
	}
	public boolean mouseEnter( Event evt, int x, int y )
	{
		handleMouseEntered( x, y );
		return true;
	}
	public boolean mouseExit( Event evt, int x, int y )
	{
		handleMouseExited( x, y );
		return true;
	}


}

 