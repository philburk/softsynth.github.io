package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/**     FM Pair
        Based on Andrew Gram's FMCircuit.
*/

public class FMPair extends SynthNote
{
	SineOscillator modOsc;
	SineOscillator carOsc;
	AddUnit adder;
	public SynthInput modFrequency;
	public SynthInput modAmplitude;
        
	public FMPair() throws SynthException
	{
	// FIXME - we break up the creation into two stages so we can over ride port assignments
	// before calling addPort().
		makeCircuit();
		addAllPorts();
	}
		
	void makeCircuit()
	{
/* Add SynthUnits to circuit */
		add(modOsc = new SineOscillator());
		add(carOsc = new SineOscillator());
		add(adder = new AddUnit());

/* Connect units together. */
		modOsc.output.connect(adder.inputB);
		adder.output.connect(carOsc.frequency);
                
/* Make ports visible. */
		modFrequency = modOsc.frequency;
		modAmplitude = modOsc.amplitude;
		frequency = adder.inputA;
		amplitude = carOsc.amplitude;
		output = carOsc.output;
               
/* Set ports to useful values and ranges. */
		modFrequency.setup( 0.0, 600.0, 12000.0 );
		modAmplitude.setup(   0.0, 200.0, 10000.0 );
		frequency.setup(  0.0, 300.0, 8000.0 );
		amplitude.setup(   0.0, 0.5, 10.0 );
    }

/* Do addPorts in separate method so we can override port assignments. */
	void addAllPorts()
	{
		addPort(modFrequency, "modFrequency");
		addPort(modAmplitude, "modAmplitude");
		addPort(frequency, "frequency");
		addPort(amplitude);
		addPort(output);
	}

}
