package com.softsynth.view;

/** Event used with ValueListener interface.
 * @author Nick Didkovsky and Phil Burk
*/
public class ValueEvent extends java.util.EventObject
{
	double value = 0.0;
	
	public ValueEvent( Object source, double value )
	{
		super( source );
		this.value = value;
	}
	public ValueEvent( Object source )
	{
		super( source );
	}
	
	public double getValue()
	{
		return value;
	}
	
	public void setValue( double value )
	{
		this.value = value;
	}
}
