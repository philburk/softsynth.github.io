package com.softsynth.jsyn;
import java.util.*;

/**
 *	SchmidtTrigger unit.
 <P>
 Output logic level value with hysteresis.
 Transition high when input exceeds setlevel. Only go low when input is below resetLevel.
 This can be used to reject low level noise on the input signal.

 The default values for setlevel and resetLevel are both 0.0.
 Setting setLevel to 0.1 and resetLevel to -0.1 will give some hysteresis.

 The outputPulse is a single sample wide pulse set when the output
 transitions from low to high.

  <P>
 <PRE>
   if( output == 0.0 )
	  output = ( input > setLevel ) ? 1.0 : 0.0;
   else   if( output > 0.0 )
	  output = ( input <= resetLevel ) ? 0.0 : 1.0;
   else
      output = previous_output;
 </PRE>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 010
 * @see CompareUnit
 */

public class SchmidtTrigger extends SynthUnit
{
	public SynthInput input;
	public SynthInput setLevel;
	public SynthInput resetLevel;
	public SynthOutput outputPulse;
	public SynthOutput output;

 	public SchmidtTrigger( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Logic_SchmidtTrigger", calculationRate );
		input = new SynthInput( this, "Input" );
		setLevel = new SynthInput( this, "SetLevel" );
		resetLevel = new SynthInput( this, "ResetLevel" );
		outputPulse = new SynthOutput( this, "OutputPulse" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public SchmidtTrigger( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SchmidtTrigger( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
