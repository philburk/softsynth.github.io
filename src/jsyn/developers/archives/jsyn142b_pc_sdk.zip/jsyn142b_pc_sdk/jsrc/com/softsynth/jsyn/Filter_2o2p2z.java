package com.softsynth.jsyn;
import java.util.*;

/**
 *	Filter_2o2p2z unit.
Second Order, Two Pole, Two Zero filter using the following formula: <P>
<PRE>
     y(n) = 2.0 * (A0*x(n) + A1*x(n-1)  + A2*x(n-2) - B1*y(n-1)  - B2*y(n-2))
</PRE><P>

where y(n) is Output, x(n) is Input, x(n-1) is a delayed copy of the input,
and y(n-1) is a delayed copy of the output.
<P>
This filter is a recursive IIR or Infinite Impulse Response filter.
it can be unstable depending on the values of the coefficients.
<P>
A thorough description of the digital filter theory needed to fully describe this filter is beyond the scope of this
document.
Calculating coefficients is non-intuitive; the interested user is referred to one of the standard texts on filter theory
(e.g., Moore, "Elements of Computer Music", section 2.4).
<P>
Special thanks to Robert Bristow-Johnson for contributing his filter equations to the
music-dsp list.
They were used for calculating the coefficients for the lowPass, highPass, bandPass, EQ,
and shelving calculations.

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 011
 * @see Synth
 * @see SynthUnit
 * @see Filter_1o1z
 * @see Filter_1o1p
 * @see Filter_2o2p
 * @see Filter_1o1p1z
 * @see StateVariableFilter
 */

public class Filter_2o2p2z extends SynthFilter
{
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A0;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A1;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A2;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable B1;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable B2;

	double           omega = 0.0;
	double           cs = 0.0;
	double           sn = 0.0;
	double           Q = 0.0;
	double           alpha = 0.0;

 	public Filter_2o2p2z( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Filter_2o2p2z", calculationRate, 0 );
		A0 = new SynthVariable( this, "A0" );
		A1 = new SynthVariable( this, "A1" );
		A2 = new SynthVariable( this, "A2" );
		B1 = new SynthVariable( this, "B1" );
		B2 = new SynthVariable( this, "B2" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public Filter_2o2p2z( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public Filter_2o2p2z( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}

	double sinh( double x )
	{
		return (0.5 * (Math.exp(x) - Math.exp(-x)));
	}


	void calcCommon( double freq, double bandwidth )
	{
		double ratio = freq / synthContext.getFrameRate();
		if( ratio >= 0.499 ) ratio = 0.499; /* Don't get close to Nyquist because it will blow up. */
		omega = 2.0 * Math.PI * ratio;
		cs = Math.cos( omega );
		sn = Math.sin( omega );
		Q = sn / (Math.log(2.0) * bandwidth * omega );
		alpha = sn * sinh( 0.5 / Q );
	}

/*
	Here is the equation that JSyn uses:
     y(n) = 2.0 * (A0*x(n) + A1*x(n-1)  + A2*x(n-2) - B1*y(n-1)  - B2*y(n-2))
	Here is the equation that RBJ uses:
     y[n] = (b0/a0)*x[n] + (b1/a0)*x[n-1] + (b2/a0)*x[n-2] - (a1/a0)*y[n-1] - (a2/a0)*y[n-2]
	
	So to translate between JSyn coefficients and RBJ coefficients:
	JSyn       RBJ
	A0       b0/(2*a0)
	A1       b1/(2*a0)
	A2       b2/(2*a0)
	B1       a1/(2*a0)
	B2       a2/(2*a0)
*/
/**
 * Set coefficients of filter for Low Pass operation.
 * Frequencies below the given frequency parameter will be passed.
 * Frequencies above will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Cutoff frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies
 *	for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void lowPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double onePlusAlpha =  1.0 + alpha;
		double scalar = 0.5 / onePlusAlpha;
		double c1 = (1.0 - cs);
		double A0_A2_Value = c1 * 0.5 * scalar;
	// translating to RBJ coefficients
	// A0 = (b0/(2*a0)
	//    = ((1 - cs)/2) / (2*(1 + alpha))
	//    = (c1*0.5) / (2.0*onePlusAlpha)
	//    = (c1*0.5) * (0.5/onePlusAlpha)
	//    = c1 * 0.5 * scalar
		A0.set( time, A0_A2_Value );
		A1.set( time, c1 * scalar );
		A2.set( time, A0_A2_Value );
		B1.set( time, -2.0 * cs * scalar );
		B2.set( time, (1.0 - alpha) * scalar );
	}

	public void lowPass( double frequency, double bandwidth ) throws SynthException
	{
		lowPass( synthContext.getTickCount(), frequency, bandwidth );
	}
	
/**
 * Set coefficients of filter for High Pass operation.
 * Frequencies above the given frequency parameter will be passed.
 * Frequencies below will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Cutoff frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void highPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double onePlusAlpha =  1.0 + alpha;
		double scalar = 0.5 / onePlusAlpha;
		double ct = (1.0 + cs);
		double A0_A2_Value = ct * 0.5 * scalar;
		A0.set( time, A0_A2_Value );
		A1.set( time, -ct * scalar );
		A2.set( time, A0_A2_Value );
		B1.set( time, -2.0 * cs * scalar );
		B2.set( time, (1.0 - alpha) * scalar );
	}

	public void highPass( double frequency, double bandwidth ) throws SynthException
	{
		highPass( synthContext.getTickCount(), frequency, bandwidth );
	}
	
/**
 * Set coefficients of filter for Band Pass operation.
 * Frequencies near the given frequency parameter will be passed.
 * Frequencies above and below will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void bandPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double onePlusAlpha =  1.0 + alpha;
		double scalar = 0.5 / onePlusAlpha;
		A0.set( time, alpha * scalar );
		A1.set( time, 0.0 );
		A2.set( time, -alpha * scalar );
		B1.set( time, -2.0 * cs * scalar );
		B2.set( time, (1.0 - alpha) * scalar );
	}

	public void bandPass( double frequency, double bandwidth ) throws SynthException
	{
		bandPass( synthContext.getTickCount(), frequency, bandwidth );
	}
/**
 * Set coefficients of filter for Notch operation.
 * Frequencies near the given frequency parameter will be cut.
 * Frequencies above and below will be passed to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void notch( int time, double frequency, double bandwidth ) throws SynthException
	{
/*  RBJ equations		
notch:          H(s) = (s^2 + 1) / (s^2 + s/Q + 1)

                b0 =   1
                b1 =  -2*cs
                b2 =   1
                a0 =   1 + alpha
                a1 =  -2*cs
                a2 =   1 - alpha
*/
		calcCommon( frequency, bandwidth );
		double onePlusAlpha =  1.0 + alpha;
		double scalar = 0.5 / onePlusAlpha;
		double A1_B1_Value = -2.0 * cs * scalar;
		A0.set( time, scalar );
		A1.set( time, A1_B1_Value );
		A2.set( time, scalar );
		B1.set( time, A1_B1_Value );
		B2.set( time, (1.0 - alpha) * scalar );
	}

	public void notch( double frequency, double bandwidth ) throws SynthException
	{
		notch( synthContext.getTickCount(), frequency, bandwidth );
	}

	double calcA( double dBGain )
	{
		return Math.pow( 10.0, (dBGain/40.0) );
	}
/**
 * Set coefficients of filter for Peaking EQ operation.
 * Frequencies near the given frequency parameter will be passed.
 * Frequencies above and below will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @param dBGain Gain in decibels at the center frequency. If dBGain is
 *      zero then the signal is unmodified.
 * @exception SynthException	  If port setting fails.
 */
	public void peakingEQ( int time, double frequency, double bandwidth, double dBGain ) throws SynthException
	{
		
/* RBJ coefficients
peakingEQ:      b0 =  1 + alpha*A
                b1 = -2*cs
                b2 =  1 - alpha*A    
                a0 =  1 + alpha/A
                a1 = -2*cs
                a2 =  1 - alpha/A
*/
		calcCommon( frequency, bandwidth );
		double A = calcA( dBGain );
		double alphaTimesA = alpha*A;
		double alphaOverA = alpha/A;
		double scalar = 0.5 / (1.0 + alphaOverA);
		double A1_B1_Value = -2.0 * cs * scalar;
		A0.set( time, (1.0 + alphaTimesA) * scalar );
		A1.set( time, A1_B1_Value );
		A2.set( time, (1.0 - alphaTimesA) * scalar );
		B1.set( time, A1_B1_Value );
		B2.set( time, (1.0 - alphaOverA) * scalar );
	}

	public void peakingEQ( double frequency, double bandwidth, double dBGain ) throws SynthException
	{
		peakingEQ( synthContext.getTickCount(), frequency, bandwidth, dBGain );
	}
	
	double calcBeta( double slope, double A )
	{
		double am1 = A-1;
		return Math.sqrt( (((A*A) + 1.0)/slope) - (am1*am1) ); //   (for shelving EQ filters only)
	}
	
/**
 * Set coefficients of filter for Low Shelf operation.
 * This is similar to the Bass control on a stereo.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @param dBGain Gain in decibels past the edge of the shelf. If dBGain is
 *      zero then the signal is unmodified.
 * @param slope Slope of the edge of the shelf. Should be < 1.0 to prevent
 *   irregularities in the frequency response curve.
 * @exception SynthException	  If port setting fails.
 */
	public void lowShelf( int time, double frequency, double bandwidth, double dBGain, double slope ) throws SynthException
	{

/*
lowShelf:       H(s) = A * (A + beta*s + s^2) / (1 + beta*s + A*s^2)

                b0 =    A*[ (A+1) - (A-1)*cs + beta*sn ]
                b1 =  2*A*[ (A-1) - (A+1)*cs           ]
                b2 =    A*[ (A+1) - (A-1)*cs - beta*sn ]
                a0 =        (A+1) + (A-1)*cs + beta*sn
                a1 =   -2*[ (A-1) + (A+1)*cs           ]
                a2 =        (A+1) + (A-1)*cs - beta*sn
*/
		calcCommon( frequency, bandwidth );
		double A = calcA( dBGain );
		double beta = calcBeta( slope, A );
		double beta_sn = beta * sn;
		double AP1 = A + 1.0;
		double AM1 = A - 1.0;
		double AP1cs = AP1 * cs;
		double AM1cs = AM1 * cs;
		double scalar = 0.5 / (AP1 + AM1cs + beta_sn); // 1/(2*a0) in RBJ
		
		A0.set( time, A * (AP1 - AM1cs + beta_sn) * scalar );
		A1.set( time, 2.0 * A * (AM1 - AP1cs) * scalar );
		A2.set( time, A * (AP1 - AM1cs - beta_sn) * scalar );
		B1.set( time, -2.0 * (AM1 + AP1cs) * scalar );
		B2.set( time, (AP1 + AM1cs - beta_sn) * scalar );
	}

	public void lowShelf( double frequency, double bandwidth, double dBGain, double slope ) throws SynthException
	{
		lowShelf( synthContext.getTickCount(), frequency, bandwidth, dBGain, slope );
	}

/**
 * Set coefficients of filter for High Shelf operation.
 * This is similar to the Treble control on a stereo.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking
 *      or between -3 dB frequencies for BPF and notch).
 * @param dBGain Gain in decibels past the edge of the shelf. If dBGain is 
 *      zero then the signal is supposed to be unmodified but isn't.
 * @param slope Slope of the edge of the shelf. Should be < 1.0 to prevent
 *   irregularities in the frequency response curve.
 * @exception SynthException	  If port setting fails.
 */
	public void highShelf( int time, double frequency, double bandwidth, double dBGain, double slope ) throws SynthException
	{

/*
highShelf:      H(s) = A * (1 + beta*s + A*s^2) / (A + beta*s + s^2)

                b0 =    A*[ (A+1) + (A-1)*cs + beta*sn ]
                b1 = -2*A*[ (A-1) + (A+1)*cs           ]
                b2 =    A*[ (A+1) + (A-1)*cs - beta*sn ]
                a0 =        (A+1) - (A-1)*cs + beta*sn
                a1 =    2*[ (A-1) - (A+1)*cs           ]
                a2 =        (A+1) - (A-1)*cs - beta*sn
*/
		calcCommon( frequency, bandwidth );
		double A = calcA( dBGain );
		double beta = calcBeta( slope, A );
		double beta_sn = beta * sn;
		double AP1 = A + 1.0;
		double AM1 = A - 1.0;
		double AP1cs = AP1 * cs;
		double AM1cs = AM1 * cs;
		double scalar = 0.5 / (AP1 - AM1cs + beta_sn); // 1/(2*a0) in RBJ
		
		A0.set( time,        A * (AP1 + AM1cs + beta_sn) * scalar );
		A1.set( time, -2.0 * A * (AM1 + AP1cs) * scalar );
		A2.set( time,        A * (AP1 + AM1cs - beta_sn) * scalar );
		B1.set( time,     -2.0 * (AM1 - AP1cs) * scalar );
		B2.set( time,            (AP1 - AM1cs - beta_sn) * scalar );
	}

	public void highShelf( double frequency, double bandwidth, double dBGain, double slope ) throws SynthException
	{
		highShelf( synthContext.getTickCount(), frequency, bandwidth, dBGain, slope );
	}
}
