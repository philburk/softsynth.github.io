package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleWriter base class.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SampleWriter extends SynthUnit 
{
	public SynthSampleQueue samplePort;
	public SynthInput input;

 	public SampleWriter( SynthContext synthContext, String unitName, int calculationRate ) throws SynthException
	{
		super( synthContext, unitName, calculationRate );
		samplePort = new SynthSampleQueue( this );
		input = new SynthInput( this, "Input" );
	}
 	public SampleWriter( String unitName, int calculationRate ) throws SynthException
	{
		this( Synth.getSharedContext(), unitName, calculationRate );
	}
}
