package com.softsynth.jsyn.view11x;
/**
 * Tweakable Interface
 * Used with LabelledFader and other editing components.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see LabelledFader
 */

public interface Tweakable extends com.softsynth.jsyn.view102.Tweakable 
{
}
