package com.softsynth.jsyn;
import java.util.*;

/**
 *	PanControl unit.
 <P>
  Generates control signals that can be used to control
  a mixer or the amplitude ports of two units.
  <PRE>
  temp = (pan * 0.5) + 0.5;
  output[0] = temp;
  output[1] = 1.0 - temp;
  </PRE>
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see SelectUnit
 */

public class PanControlUnit extends SynthUnit 
{
/** SIGNAL_TYPE_RAW_UNSIGNED.  Ranges -1 to +1. */
	public SynthInput pan;
/** This port has two parts, 0 and 1. */
	public SynthOutput output;

 	public PanControlUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_PanControl", calculationRate );
		pan = new SynthInput( this, "Pan" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
 	public PanControlUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public PanControlUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
