package com.softsynth.jsyn;
import java.util.*;
/**
 * SynthCircuit that can play "notes" with frequency and amplitude specified.
 * <br>
 * This class has its own frequency, amplitude and output ports,
 * So do not declare new ones in your sub-classes.
 * <br>
 * Please note that SynthNote is an incomplete class that is only intended
 * for use as a superclass for circuits. It cannot be used by itself directly.
 * Specifically, it has an "output" port that can be used to connect to other
 * units. But a bare SynthNote does not define any units and therefore has
 * a null output port. If you try to connect a SynthNote output to something
 * it will throw a NullPointerException.
 *<br>
 * You will need to put some real units in your SynthNote subclass and then do something like this:
<br><pre>
	addPort( output = osc.output );
</pre><br>
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 008
 * @see util.VoiceAllocator
 */

public class SynthNote extends SynthCircuit
{
	public SynthInput  frequency;
	public SynthInput  amplitude;

	public SynthNote()  throws SynthException
	{
		super( Synth.getSharedContext() );
	}
	
	public SynthNote( SynthContext synthContext )  throws SynthException
	{
		super( synthContext );
	}
	
	public void noteOn( int time, double frequency, double amplitude )
	{
		if( this.frequency != null ) this.frequency.set( time, frequency );
		if( this.amplitude != null ) this.amplitude.set( time, amplitude );
		setStage( time, 0 );
	}

	public void noteOff( int time )
	{
		setStage( time, 1 );
	}
	
	public void noteOnFor( int time, int duration, double frequency, double amplitude )
	{
		noteOn( time, frequency, amplitude );
		noteOff( time + duration );
	}

	public void note( int time, int duration, double frequency, double amplitude )
	{
		noteOn( time, frequency, amplitude );
		noteOff( time+(duration/2) ); // goofy
	}
}
