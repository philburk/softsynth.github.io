package com.softsynth.util;
import java.util.*;
import java.io.*;

/** An OutputStream wrapper for a RandomAccessFile
 * Needed by routines that output to an OutputStream.<p>
 * Note that if you are overwriting a RandomAccessFile then you should clear it before you start.
 * This will prevent having the remainder of a longer file stuck at the end of
 * a short file. In Java 1.2 you can call setLength(0).

 */
public class RandomOutputStream extends OutputStream
{
	RandomAccessFile randomFile;
	
	public RandomOutputStream( RandomAccessFile randomFile )
	{
		this.randomFile = randomFile;
	}
	
	public void write(int b) throws IOException
	{
		randomFile.write( b );
	}
	
	public void write(byte[] b) throws IOException
	{
		randomFile.write( b );
	}
	public void write(byte[] b, int off, int len) throws IOException
	{
		randomFile.write( b, off, len );
	}
		
	public void seek( long position )  throws IOException
	{
		randomFile.seek( position );
	}
	public long getFilePointer()  throws IOException
	{
		return randomFile.getFilePointer();
	}

}
