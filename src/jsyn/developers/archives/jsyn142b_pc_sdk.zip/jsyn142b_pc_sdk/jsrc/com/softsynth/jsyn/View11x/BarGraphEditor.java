package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Edit an array of double values using a bar-graph style display.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class BarGraphEditor extends com.softsynth.jsyn.view102.InternalBarGraphEditor implements MouseMotionListener
{
	public BarGraphEditor( double data[] )
	{
		super( data );
  		addMouseMotionListener(this);
	}
	
/* Respond to 1.1 style AWT mouse actions. */
	public void mousePressed( MouseEvent e )
	{
//		System.out.println("AWT1.1 - pressed " + e.getX() + ", " + e.getY() );
		convertMouse( e.isShiftDown(), e.getX(), e.getY() );
	}
	public void mouseDragged(MouseEvent e)
	{
//		System.out.println("AWT1.1 - dragged " + e.getX() + ", " + e.getY() );
		convertMouse( e.isShiftDown(), e.getX(), e.getY() );
	}
	public void mouseMoved( MouseEvent evt ) { }
	public void mouseReleased( MouseEvent evt ) { }
	public void mouseEntered( MouseEvent evt ) { }
	public void mouseExited( MouseEvent evt ) { }
	public void mouseClicked( MouseEvent evt ) { }

}
