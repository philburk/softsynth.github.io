/**
 * Test SynthSound or SynthCircuit by
 * putting PortFaders on all SynthInputs.
 * Also allows user to setStage() by clicking radio buttons.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

package com.softsynth.jsyn.view;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

public class SoundTester extends Panel
{
	Checkbox[] cbox;
	SynthSound sound;
	Button     hitButton;
	final static int NUM_STAGES = 8;

	public SoundTester( SynthSound sound ) throws SynthException
	{
		super();
		this.sound = sound;

		setLayout( new GridLayout(0,1) );

		SynthPort  newPort;
/* Query for the number of ports. */
		int numPorts = sound.getNumPorts();

/* Get each port.  Attach a PortFader to each SynthInput. */
		for(int i=0; i<numPorts; i++ )
		{
			newPort = sound.getPortAt( i );
//			System.out.println("Add " + newPort );
			if( (newPort instanceof SynthVariable) ) addInput( (SynthVariable) newPort );
		}

/* Add a radio grid to trigger states in sound. */
		Panel stageSetter = new Panel();
		CheckboxGroup cbg = new CheckboxGroup();
		cbox = new Checkbox[NUM_STAGES];
		stageSetter.add( new Label("Stage:") );
		for( int i=0; i<NUM_STAGES; i++ )
		{
			stageSetter.add(cbox[i] = new Checkbox(Integer.toString(i), cbg, (i==0) ));
		}
		add( stageSetter );

		add( hitButton = new Button("Hit") );

/* Add a button that polls and displays the current CPU usage. */
		add( new UsageDisplay() );
	}
	
	void addInput( SynthVariable input ) throws SynthException
	{
		add( new PortFader( input, input.get(), input.getMin(), input.getMax()) );
	}

	public boolean action(Event evt, Object what)
	{
		try
		{
			for( int i=0; i<NUM_STAGES; i++ )
			{
				if(cbox[i] == evt.target)
				{
					sound.setStage(i);
					return true;
				}
			}

			if( evt.target == hitButton )
			{
				sound.setStage(0);
				return true;
			}
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
			return true;
		}
		return false;
    }

}
