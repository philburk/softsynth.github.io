/**
 * This Applet class is used with IndirectAppletLoader.
 * It uses another applet for its CodeBase, etc.
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package com.softsynth.tools;
import java.util.*;
import java.awt.*;
import java.applet.Applet;

public class IndirectApplet extends Panel
{
	Applet       applet = null;
	
/** Set Applet to be used for getCodebase(), etc.
 */
	public void setApplet( Applet applet )
	{
		this.applet = applet;
	}
/** Get Applet to be used for getCodebase(), etc.
 */
	public Applet getApplet()
	{
		return applet;
	}
	
/** All these methods may be overridden by subclass.
 */
	public String[][] getParameterInfo() { return null; }
	public String getAppletInfo() { { return null; }}
	public void init() {}
	public void start() {}
	public void stop() {}
	public void destroy() {}
}
