package com.softsynth.jsyn.circuits;import java.util.*;import java.io.*;import com.softsynth.jsyn.*;/** WaveShaping sound circuit. Table index is driven by a sine wave to generate an output. * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
**/public class WaveShapingOscillator extends SynthNote{	SineOscillator   unitOsc;           /* used to scan small sections of the table */	EnvelopePlayer   rangeEnv;
	EnvelopePlayer   ampEnv;
	SynthEnvelope    rangeEnvData; 
	SynthEnvelope    ampEnvData; 
	WaveShaper       unitWaveShaper;	SynthInput       range;
		public WaveShapingOscillator( SynthTable table ) throws SynthException	{		add( unitWaveShaper   = new WaveShaper());		add( unitOsc          = new SineOscillator());		add( rangeEnv         = new EnvelopePlayer() );
		add( ampEnv           = new EnvelopePlayer() );
				unitWaveShaper.tablePort.setTable( table );
/* Create a range envelope and fill it with data. */
		double[] rangeData =
		{
			0.0,  0.0,   /* duration,value pairs */
			0.02, 1.0,
			0.2,  0.2,
			0.2,  0.3,
			2.0,  0.01,
		};
		rangeEnvData = new SynthEnvelope( rangeData );
		rangeEnvData.setSustainLoop( 2, 2+2 );

/* Create an amplitude envelope and fill it with data. */
		double[] ampData =
		{
			0.02, 0.9,   /* duration,value pair for frame[0] */
			0.1, 0.5,   /* duration,value pair for frame[1] */
			0.5, 0.0,   /* duration,value pair for frame[2] */
		};
		ampEnvData = new SynthEnvelope( ampData );
		ampEnvData.setSustainLoop( 1, 1 ); // hang on 1
		addPort( frequency = unitOsc.frequency );		addPort( amplitude = ampEnv.amplitude );		addPort( output = unitWaveShaper.output );		addPort( range = unitOsc.amplitude );		/* Connect units */		rangeEnv.output.connect( range );		ampEnv.output.connect( unitWaveShaper.amplitude );		unitOsc.output.connect( unitWaveShaper.input );				frequency.setup( 0.0, 200.0, 800.0 );		amplitude.setup( 0.0, 0.5, 1.0 );	}
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0:
//			stop( time );
			rangeEnv.envelopePort.clear( time );
			ampEnv.envelopePort.clear( time );
			rangeEnv.envelopePort.queueOn( time, rangeEnvData );
			ampEnv.envelopePort.queueOn( time, ampEnvData );
			start( time );
			break;
		case 1:
			rangeEnv.envelopePort.queueOff( time, rangeEnvData );
/* Set AutoStop feature of amp envelope so that unit stops when data gone. */
			ampEnv.envelopePort.queueOff( time, ampEnvData, true );
			break;
		}
	}
}
