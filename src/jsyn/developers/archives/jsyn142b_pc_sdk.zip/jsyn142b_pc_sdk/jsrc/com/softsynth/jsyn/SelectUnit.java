package com.softsynth.jsyn;
import java.util.*;

/**
 *	SelectUnit unit.
 <P>
 Select InputA or InputB based on value on Select port.
 <P>
 output = ( select > 0.0 ) ? inputA : inputB;
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 010
 * @see LatchUnit
 */

public class SelectUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthInput select;
	public SynthOutput output;

 	public SelectUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Logic_Select", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		select = new SynthInput( this, "Select" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public SelectUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SelectUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
