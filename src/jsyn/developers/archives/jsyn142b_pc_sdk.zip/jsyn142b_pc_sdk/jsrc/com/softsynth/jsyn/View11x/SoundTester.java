package com.softsynth.jsyn.view11x;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import com.softsynth.jsyn.*;
/**
 * Test SynthSound or SynthCircuit by
 * putting PortFaders on all SynthInputs.
 * Also allows user to setStage() by clicking radio buttons.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SoundTester extends com.softsynth.jsyn.view102.InternalSoundTester implements ActionListener, ItemListener 
{
	public SoundTester( SynthSound sound ) throws SynthException
	{
		super( sound );
		
		for( int i=0; i<NUM_STAGES; i++ )
		{
			cbox[i].addItemListener( this );

		}

		hitButton.addActionListener( this );
	}
	
	protected void addInput( SynthVariable input )
	{
		add( new com.softsynth.jsyn.view11x.PortFader( input, input.get(), input.getMin(), input.getMax()) ); // AWT 1.1
	}
	
	public void actionPerformed(ActionEvent e)
	{ 
		if( e.getSource() == hitButton ) this.sound.setStage(0);
	}

	public void itemStateChanged( ItemEvent e)
	{
		for( int i=0; i<NUM_STAGES; i++ )
		{
			if(cbox[i] == e.getSource() )
			{
				sound.setStage(i);
			}
		}
    }
}
