package com.softsynth.jsyn.view11x;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;

/**
 * This class draws an associated short array as a waveform.
 * Waveforms are added in the form of a WaveTrace object.
 * The left and right indices can be set to provide zoom and pan.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class WaveDisplay extends com.softsynth.jsyn.view102.WaveDisplay
{
}
