package com.softsynth.jsyn;
import java.util.*;
import java.awt.*;
import java.applet.*;
/**
 * Frame that allows a program to be run as either an Application or an Applet.
 * Used by JSyn example programs.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved 
 */

public class AppletFrame  extends Frame
{
	Applet applet;

	public AppletFrame(String frameTitle, Applet applet)
	{
		super(frameTitle);
		this.applet = applet;
		add("Center", applet);
		repaint();
	}

	public void test()
	{
		applet.init();
		applet.start();
	}

	public boolean handleEvent( Event evt )
	{
		switch (evt.id)
		{
			case Event.WINDOW_DESTROY:
				applet.stop();
				applet.destroy();
				dispose();
				try
				{
					System.exit(0);
				} catch( SecurityException e)
				{
					System.err.println("System.exit(0) not allowed by Java VM.");
				}
				return true;

			default:
				return super.handleEvent(evt);
		}			 
	}
}

