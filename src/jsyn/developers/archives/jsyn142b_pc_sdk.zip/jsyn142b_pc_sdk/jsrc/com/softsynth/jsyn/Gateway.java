package com.softsynth.jsyn;
import java.util.*;
import java.awt.*;

/**
 * Gateway interface to provide version synchronization between plugins
 * and applets. This is needed to avoid NoClassDefFoundErrors.
 *
 * @author Phil Burk (C) 2000
 */

public interface Gateway
{
	public void checkUpgrade( int packageVersion );
	public String getCopyright();
	public int getVersion();
}
