
package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Red Noise amplitude modulated by a LinearLag
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class LagAmpNoise extends SynthNote
{
	RedNoise   myNoise;
	LinearLag  myLag;
	
/* Declare port. */
	public SynthVariable target;
	public SynthVariable time;

/*
 * Setup synthesis.
 */
	public LagAmpNoise()  throws SynthException
	{
/* Create various unit generators and add them to circuit. */
		add( myNoise = new RedNoise() );
		add( myLag = new LinearLag() );

/* Connect SynthUnits to make control signal path. */
		myLag.output.connect( myNoise.amplitude );

/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( frequency = myNoise.frequency );
		addPort( amplitude = myNoise.amplitude );
		addPort( target = myLag.input, "target" );
		addPort( time = myLag.time );
		addPort( output = myNoise.output );
	}
	
/* Define a behavior for setStage() */
	public void setStage( int time, int stage )
	throws SynthException
	{
		if( stage == 0 )
		{
			start( time );
		}
		else
		{
			stop( time );
		}
	}
}

