package com.softsynth.view;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/** Our own horizontal fader (scrollbar), subclass of canvas, 
which uses CustomFaderListener interface to communicate 
with parent.
This fader is very similar to a Scrollbar except that it will jump to
a value if clicked while holding down the SHIFT key.<br><br>

To use this class, choose either the AWT 1.0.2 version of CustomFader
package com.softsynth.view102, or the AWT 1.1 version in package com.softsynth.view111.
Example of using a CustomFader:
<pre>
// A new fader with parent, with default value 50, visible of 10, min value 0, max value 100
myFader = new CustomFader(CustomFader.HORIZONTAL, 50, 10, 0, 100);

// Assumes "this" is a class that implements CustomFaderListener
myFader.addCustomFaderListener( this );

// set the increment that the value will jump when user clicks inside fader
myFader.setBlockIncrement(10);

// set the increment that the value will jump when user clicks on arrows of fader
myFader.setUnitIncrement(1);

// add it to layout
add(myFader);

...
</pre>
<br>
<br>
Parent must implement the CustomFaderListener interface.
This requires defining <b>public void customFaderValueChanged(CustomFader jsb)</b> 
to be notified of the fader's value changing.<br>
Example:
<pre>
 public void customFaderValueChanged(Object fader, int value)
 {
        System.out.println("Value = " + value);
 }
</pre>
This was written to provide a more consistent, less buggy Scrollbar substitute.

@author Nick Didkovsky and Phil Burk, SoftSynth.com, All Rights Reserved
*/
public class CustomFader extends Canvas implements MouseListener, MouseMotionListener
{
	public final static int HORIZONTAL = 0;
	public final static int VERTICAL = 1;
	Vector  listeners;
	boolean isHorizontal;
       
	int minVal;
	int maxVal;
	int value;
	int lineIncrement = 1;
	int blockIncrement = 10;
	int visibleAmount;
	int imageSizeX = -1; // set to -1 to force initial update
	int imageSizeY = -1;
 // set when event received. Control fader behavior across multiple faders
	protected static boolean isShiftDown;
	protected static boolean isMouseDown;
	
// In order to simplify switching between HORIZONTAL and VERTICAL, X and Y will only
// be used when drawing. Sizing will be done using W and Z. W is across the fader and
// can be thought of as a Width dimension. Z will stretch from end-to-end.
// The names left/right will be replaced with low/high to denote the low and high Z dimension.
	final int ARROW_SIZE_Z = 20;
	int thumbSize;
	int scrollerLowZ;
	int scrollerMidZ;
	int scrollerHighZ;
	int sizeW;   // pixels across fader
	int sizeZ;   // pixels from end to end
	int lowZ;    // z corresponding to minVal
	int highZ;   // z corresponding to maxVal
  
	static boolean currentlyDragging = false;
// Drag events may come from a different mouse than the one the user is affecting.
// So offset X,Y to the target fader coordinates.
	static CustomFader dragSourceFader;
	static CustomFader dragTargetFader;
	static int dragOffsetX;
	static int dragOffsetY;
  
	Image offscreenImage;

 /** Constructor with initial value, visible, min value, max value.  LineIncrement defaults to 1, PageIncrement defaults to 10 (see setUnitIncrement() and setBlockIncrement() below) */
	public CustomFader(int orientation, int val, int visible, int min, int max)
	{
		listeners = new Vector();
		isHorizontal = (orientation == HORIZONTAL);
		value = val;
		minVal = min;
		maxVal = max;
		setVisibleAmount( visible );
		setBackground( Color.lightGray );
		addMouseListener(this);
  		addMouseMotionListener(this);
	}


/** Add a listener to receive value change events.
 */
	public void addCustomFaderListener( CustomFaderListener listener )
	{
		listeners.addElement( listener );
	}
	public void removeCustomFaderListener( CustomFaderListener listener )
	{
		listeners.removeElement( listener );
	}
	
/** Set current value, minimum value, maximum value of fader */
	public void setValues(int val, int min, int max) {
		value = val;
		minVal = min;
		maxVal = max;	
	}
	
/** @return Scrollbar's current value */	 
	 public int getValue() {
	 	return value;
	}
	 
/** Set how much the value jumps when click to left or high of slider.  Default is 10 */
	public void setBlockIncrement(int v) {
		blockIncrement = v;
	}
	
	public int getBlockIncrement() {
		return blockIncrement;
	}

/** Set how much the value jumps when click on an arrow.  Default is 1 */
	public void setUnitIncrement(int v) {
		lineIncrement = v;
	}

	public int getLineIncrement() {
		return lineIncrement;
	}
		
	public int getVisibleAmount( int amount )
	{
		return visibleAmount;
	}
	
	public void setVisibleAmount( int amount )
	{
		if( amount < 1 ) amount = 1;
		visibleAmount = amount;
		setBlockIncrement( amount );
		updateThumbSize();
	}
// **************************************************************************
// ************ Private Internal Implementation Methods *********************
// **************************************************************************

	private void setInternalSize(int width, int height)
	{
		// if ((imageSizeX == width) || (imageSizeY == height)) return; // FIXED 3/10/00
		if ((imageSizeX == width) && (imageSizeY == height)) return;
		imageSizeX = width;
   		imageSizeY = height;
		if( isHorizontal )
		{
			sizeZ = width;
			sizeW = height;
		}
		else
		{
			sizeZ = height;
			sizeW = width;
		}
		if (sizeZ < (ARROW_SIZE_Z*2 + ARROW_SIZE_Z/2))
		{
			sizeZ = ARROW_SIZE_Z*2 + ARROW_SIZE_Z/2;
		}
		updateThumbSize();
   		buildOffscreenImage(); // MOD 4/8/98 resizes fader if window resize calls setSize()
	}

	
	private void updateThumbSize()
	{
		int spanZ = (sizeZ - (ARROW_SIZE_Z * 2));
		thumbSize = (spanZ * visibleAmount) / (maxVal - minVal + visibleAmount);
		if( thumbSize < (ARROW_SIZE_Z/2) ) thumbSize = ARROW_SIZE_Z / 2;
		lowZ = ARROW_SIZE_Z + (thumbSize / 2);  
		highZ = sizeZ - lowZ;
	}
	
	private boolean inLowArrow(int z) {
	 	return (z <= ARROW_SIZE_Z && z >= 0);
	}
	 
	private boolean inHighArrow(int z) {
	 	return ((z >= sizeZ - ARROW_SIZE_Z) && (z <= sizeZ));
	}
	
/** Send ValueChanged event to every subscribed listener. */
	void tellListeners()
	{
		Enumeration e = listeners.elements();
		while( e.hasMoreElements() )
		{
			CustomFaderListener listener = (CustomFaderListener) e.nextElement();
	 		listener.customFaderValueChanged( this, value );
		}
	}
	
/** Return value so that thumb will move under click position and make it easier to grab.
 */
	private int lowOfScroller(int z)
	{
		return scaleClipDeltaZ( scrollerMidZ - z );
	}
	
	private int highOfScroller(int z)
	{
		return scaleClipDeltaZ( z - scrollerMidZ );
	}
	
	private int scaleClipDeltaZ( int dz )
	{
		int dv;
		if( isShiftDown )
		{
			dv = deltaZToDeltaValue(dz);
		}
		else
		{
			if( dz < (thumbSize/2) ) return 0;
			dv = blockIncrement;
		}
	 	return dv;
	}
	
/** Add to current value. Clip at min/max. Repaint. */
	private void addToValue( int dz )
	{
	 	value += dz;
	 	if (value > maxVal) value = maxVal;
	 	else if (value < minVal) value = minVal;
	 	tellListeners();
	 	repaint();
	}
	 
/** see if mouse hit the scroller rectangle, ready to drag left or right */
	private void isOnScroller (int z) {
	 	currentlyDragging = currentlyDragging | (z >= scrollerLowZ && z <= scrollerHighZ);
	}
	 
	protected void handleMousePressed( boolean isShiftDown, int x, int y)
	{
		this.isShiftDown = isShiftDown;
		isMouseDown = true;
		dragSourceFader = this;
		dragTargetFader = this;
		currentlyDragging = isShiftDown;      // if clicked with shift down, start dragging
		setFaderByXY( x, y );
//		System.out.println("handleMousePressed: " + this + x + ", " + y );
	}
	
	void setFaderByXY( int x, int y)
	{
		int z,w,dz;
		if( isHorizontal )
		{
			z = x;
			w = y;
		}
		else
		{
			z = y;
			w = x;
		}
		if (inLowArrow(z)) addToValue( -lineIncrement );
		else if (inHighArrow(z)) addToValue( lineIncrement );
		else if ( (dz = lowOfScroller(z)) > 0 ) addToValue( -dz );
		else if ( (dz = highOfScroller(z)) > 0 ) addToValue( dz );
		else isOnScroller(z);
   }
   
	protected void handleMouseDragged( int x, int y)
	{
   		if (currentlyDragging)
		{
// adjust drag X,Y to this fader because it may be from other fader
			if( (dragTargetFader != null ) && (dragTargetFader != dragSourceFader) )
			{
				x += dragOffsetX;
				y += dragOffsetY;
//				System.out.println("handleMouseDragged: offset by " + dragOffsetX + ", " + dragOffsetY );
				dragTargetFader.dragFaderByXY( x, y );
			}
			else
			{
				dragFaderByXY( x, y );
			}
		}
	}
	void dragFaderByXY( int x, int y )
	{
//		System.out.println("dragFaderByXY: " + this + x + ", " + y );
		int z,w;
		if( isHorizontal )
		{
			z = x;
			w = y;
		}
		else
		{
			z = y;
			w = x;
		}
		value = zToValue(z);
     	if (value > maxVal) value = maxVal; // should not happen, x protected, but..
     	else if (value < minVal) value = minVal;
     	tellListeners();
		repaint();
   }
	protected void handleMouseEntered( int x, int y)
	{
		if( isMouseDown && isShiftDown )
		{
			dragTargetFader = this;
			dragOffsetX = dragSourceFader.bounds().x - this.bounds().x;
			dragOffsetY = dragSourceFader.bounds().y - this.bounds().y;
//			System.out.println("handleMouseEntered: " + this + dragOffsetX + ", " + dragOffsetY );
			handleMouseDragged( x, y );
		}
	}
	
	protected void handleMouseExited( int x, int y)
	{
		if( isMouseDown && isShiftDown )
		{
			dragTargetFader = null;
		}
	}
	
	protected void handleMouseReleased(int x, int y)
	{
		isMouseDown = false;
		currentlyDragging = false;
		dragSourceFader = null;
	}
   
// Various z <=> value conversions
	private int deltaZToDeltaValue(int dz)
	{
		return (dz * (maxVal - minVal)) / (highZ - lowZ);
	}
	
	private int zToValue(int z)
	{
		if (z < lowZ) return minVal;
		if (z > highZ) return maxVal;
		return deltaZToDeltaValue( z - lowZ ) + minVal;
	}
	
	private int deltaValueToDeltaZ( int dv )
	{
		return ((dv * (highZ - lowZ)) / (maxVal - minVal));
	}
	
	private int valueToZ( int val )
	{
		if (val < minVal) return lowZ;
		if (val > maxVal) return highZ;
		return deltaValueToDeltaZ(value - minVal) + lowZ;
	}
	
	public void setValue(int v)
	{
		if (v >= minVal && v<= maxVal) value = v;
		else throw new IllegalArgumentException("illegal CustomFader value: " + v);
		tellListeners();
		repaint();
	}
  
  /* flicker killer */
	public void update(Graphics g) {
		paint(g);
	}
  
	private void buildOffscreenImage() {
		offscreenImage = createImage(imageSizeX, imageSizeY);
	}
	
/** Draw polygon in either orientation for HORIZONTAL or VERTICAL. */
	private void zwFillPolygon( Graphics gg, int zvals[], int wvals[], int numPoints )
	{
		if( isHorizontal ) gg.fillPolygon(zvals, wvals, zvals.length);
		else gg.fillPolygon( wvals, zvals, zvals.length);
	}
   
	private void useBlack( Graphics bg )
	{
		bg.setColor( isEnabled() ? Color.black : Color.darkGray );
	}
	private void useWhite( Graphics bg )
	{
		bg.setColor( isEnabled() ? Color.white : Color.lightGray );
	}
	
	private void drawLowArrow(Graphics bg)
	{
   		zwDrawBevels(bg, 1, 1, ARROW_SIZE_Z, sizeW - 2);
   		int inset = 6;
   		int zOneThird = ARROW_SIZE_Z / 3;
   		int zTwoThirds = ARROW_SIZE_Z / 3 * 2;
// Draw triangle   		
   		int zvals[] = {zOneThird, zTwoThirds, zTwoThirds};
    	int wvals[] = {sizeW / 2, inset, sizeW-inset };
    	useBlack( bg );
		zwFillPolygon(bg, zvals, wvals, zvals.length);
   }
   
   private void drawHighArrow(Graphics bg) {
   		int leftMargin = sizeZ - 1 - ARROW_SIZE_Z;
  		zwDrawBevels(bg, leftMargin, 1, sizeZ - 1, sizeW - 2);
   		int inset = 6;
   		int zOneThird = ARROW_SIZE_Z / 3 + leftMargin;
   		int zTwoThirds = ARROW_SIZE_Z / 3 * 2 + leftMargin;
   		
   		int zvals[] = {zOneThird, zOneThird, zTwoThirds};
    	int wvals[] = {inset, sizeW-inset, sizeW / 2 };
    	useBlack( bg );
    	zwFillPolygon( bg, zvals, wvals, zvals.length);   
   }
   
   private void drawScrollRect(Graphics bg)
   {
   		scrollerMidZ = valueToZ( value );
   		scrollerLowZ = scrollerMidZ - thumbSize/2;
   		scrollerHighZ = scrollerMidZ + thumbSize/2;
   		zwDrawBevels(bg, scrollerLowZ, 1, scrollerHighZ, sizeW-2);
   }
   
/** Draw bevels in ZW space */
   private void zwDrawBevels(Graphics bg, int z1, int w1, int z2, int w2)
	{
		int delta = 2;
		int zvals[] = {z1, z2, z2 - delta, z1 + delta};
		int wvals[] = {w1, w1, w1 + delta, w1 + delta};
    	useWhite( bg );
		zwFillPolygon( bg, zvals, wvals, zvals.length);
		    
		int zvals2[] = {z1, z1, z1 + delta, z1 + delta};
		int wvals2[] = {w1, w2, w2 - delta, w1 + delta};
		zwFillPolygon( bg, zvals2, wvals2, zvals2.length);
		    
		int zvals3[] = {z2, z2, z2 - delta, z2 - delta};
		int wvals3[] = {w1, w2, w2 - delta, w1 + delta};
    	useBlack( bg );
		zwFillPolygon( bg, zvals3, wvals3, zvals3.length);    

		int zvals4[] = {z2, z2 - delta, z1 + delta, z1};
		int wvals4[] = {w2, w2 - delta, w2 - delta, w2};
		zwFillPolygon( bg, zvals4, wvals4, zvals4.length);    
	}
   
	public void paint(Graphics g)
	{
		setInternalSize( bounds().width, bounds().height );
		if (offscreenImage == null) buildOffscreenImage();
		if (offscreenImage != null)
		{
			Graphics bg = offscreenImage.getGraphics();
			bg.setColor( getBackground() );
			bg.fillRect(0,0,imageSizeX, imageSizeY);
/* Draw black line around image. */
			bg.setColor(Color.black);
			bg.drawLine(0, 0, imageSizeX-1, 0);
			bg.drawLine(imageSizeX-1, 0, imageSizeX-1, imageSizeY-1);
			bg.drawLine(imageSizeX-1, imageSizeY-1, 0, imageSizeY-1);
			bg.drawLine(0, 0, 0, imageSizeY-1);
			 				
			drawLowArrow(bg);
			drawHighArrow(bg);
			drawScrollRect(bg);
			g.drawImage(offscreenImage, 0, 0, this);
			bg.dispose();
  		} else {
  			System.out.println("Not ready to draw offscreenImage");
  		}
   }

// placate the MouseMotionListener interface for AWT 1.1
	public void mouseDragged(MouseEvent e)
	{
//		System.out.println("AWT1.1 - dragged " + e.getX() + ", " + e.getY() );
		handleMouseDragged( e.getX(), e.getY());
	}
	public void mouseMoved(MouseEvent e) { }
	
	// placate the MouseListener interface
	public void mousePressed(MouseEvent e)
	{
		handleMousePressed( e.isShiftDown(), e.getX(), e.getY());
//		System.out.println("AWT1.1 - pressed " + isShiftDown + ", " + e.getX() + ", " + e.getY() );
	}
	  
	public void mouseClicked(MouseEvent e) { }
	
	public void mouseReleased(MouseEvent e)
	{
//		System.out.println("AWT1.1 - released " + e.getX() + ", " + e.getY() );
		handleMouseReleased( e.getX(), e.getY());
	}
	public void mouseEntered(MouseEvent e)
	{
//		System.out.println("AWT1.1 - entered " + e.getX() + ", " + e.getY() );
		handleMouseEntered(e.getX(), e.getY());
	}
	public void mouseExited(MouseEvent e)
	{
//		System.out.println("AWT1.1 - entered " + e.getX() + ", " + e.getY() );
		handleMouseExited(e.getX(), e.getY());
	}
}

 