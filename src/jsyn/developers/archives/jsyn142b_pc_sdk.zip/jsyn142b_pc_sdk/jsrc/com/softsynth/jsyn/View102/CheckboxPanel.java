package com.softsynth.jsyn.view102;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/** A Panel containing an array of N checkboxes.
 * This is useful for drum machine type interfaces.
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class CheckboxPanel extends Panel
{
	Checkbox[] boxes;
	int previousHighlightIndex = -1;
	
	public CheckboxPanel( int numBoxes )
	{
		setLayout( new GridLayout( 1,0 ) );
		boxes = new Checkbox[ numBoxes ];
		for( int i=0; i<numBoxes; i++ )
		{
			add( boxes[i] = new Checkbox() );
		}
	}
	
/** @return the Nth checkbox in the panel */
	public Checkbox getNthBox( int N )
	{
		return boxes[N];
	}
	
/** Highlight an indexed checkbox. */
	public void highlight( int N )
	{
		if( previousHighlightIndex >= 0 )
		{
			boxes[previousHighlightIndex].setBackground( null );
		}
		boxes[N].setBackground( Color.orange );
		repaint();
		previousHighlightIndex = N;	
	}	
}
