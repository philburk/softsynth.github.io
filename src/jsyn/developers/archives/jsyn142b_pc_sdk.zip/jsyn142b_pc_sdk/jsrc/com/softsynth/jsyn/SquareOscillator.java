package com.softsynth.jsyn;
import java.util.*;

/**
 *	SquareOscillator unit. It has a woody, clarinet-like sound.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SquareOscillator extends SynthOscillator
{
 	public SquareOscillator( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Osc_Square", calculationRate, 0 );
	}
/**
 *	Create a SquareOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SquareOscillator( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SquareOscillator( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
