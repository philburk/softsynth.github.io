package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleReader base class.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SampleReader extends SynthUnit 
{
	public SynthInput amplitude;
	public SynthSampleQueue samplePort;
	public SynthOutput output;

 	public SampleReader( SynthContext synthContext, String unitName, int calculationRate ) throws SynthException
	{
		super( synthContext, unitName, calculationRate );
		amplitude = new SynthInput( this, "Amplitude" );
		samplePort = new SynthSampleQueue( this );
		output = new SynthOutput( this, "Output" );
	}
}
