package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleWriter_16F2 unit.
 * This unit writes two channels of input to a sample.
 * It can be used to capture a stereo recording of a performance.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 013
 * @see Synth
 * @see SynthChannelData
 */

public class SampleWriter_16F2 extends SampleWriter 
{
 	public SampleWriter_16F2( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Sample_Write16F2", calculationRate );
	}
/**
 *	Create a SampleWriter_16F2 that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SampleWriter_16F2( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SampleWriter_16F2( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
