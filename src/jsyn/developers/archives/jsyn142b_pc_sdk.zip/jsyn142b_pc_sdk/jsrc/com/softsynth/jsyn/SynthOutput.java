package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthPort class for Java Audio Synthesis
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthOutput extends SynthScalarPort
{
	SynthOutput( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}

/**	
 * Connect output port to an input port of another instrument.
 *  Each port can have multiple indexed parts.
 *  A stereo sample reader would, for example, have an "Output" with two parts. 
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void connect( int outIndex, SynthInput inPort, int inIndex ) throws SynthException
	{
		inPort.connect( inIndex, this, outIndex );
	}

	public void connect( SynthInput inPort ) throws SynthException
	{
		connect( 0, inPort, 0 );
	}

/**
 *	Disconnects all connections made to this port.
 *	Only one connection can be made to an input port so a connection 
 *  can be uniquely referenced by naming the input port.  Output ports have infinite fan-out.
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void disconnect( int index )
	throws SynthException
	{
		super.disconnectUnits( this, index );
	}
	public void disconnect( )
	throws SynthException
	{
		disconnect( 0 );
	}

}
