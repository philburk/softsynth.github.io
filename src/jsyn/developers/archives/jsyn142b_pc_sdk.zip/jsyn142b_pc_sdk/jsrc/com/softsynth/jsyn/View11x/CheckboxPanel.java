package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/** A Panel containing an array of N checkboxes.
 * This is useful for drum machine type interfaces.
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class CheckboxPanel extends com.softsynth.jsyn.view102.CheckboxPanel
{
	public CheckboxPanel( int numBoxes )
	{
		super( numBoxes );
	}
}
