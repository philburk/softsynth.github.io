package com.softsynth.jsyn;
import java.util.*;
/**
 * Exception class for JSyn
 * Converts error values returned from native 'C' JSyn methods into readable error messages.
 * Also handles some Java level errors.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthException extends RuntimeException
{
	public SynthException( int errorCode, String string, int data1, int data2 )
	{
		super( "JSyn error: " + Synth.errorCodeToString(errorCode) + "  -  " +
			string +
			", 0x" + Integer.toHexString(data1) + "=" + data1 +
			", 0x" + Integer.toHexString(data2) + "=" + data2 );
	}
	
	public SynthException( int errorCode, String string, int data )
	{
		this( errorCode, string, data, data );
	}
	public SynthException( int errorCode, String string )
	{
		this( errorCode, string, 0, 0 );
	}
	public SynthException( int errorCode,  int data )
	{
		this( errorCode, "", data, data );
	}
	public SynthException( int errorCode,  int data1, int data2 )
	{
		this( errorCode, "", data1, data2 );
	}
	public SynthException( String string )
	{
		this( Synth.JS_ERR_USER, string, 0, 0 );
	}
}
