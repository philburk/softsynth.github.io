package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * NoiseModSwoop
 *
 *   Sine----\
 *          Lag--\
 *             Scale------\ 
 *              Noise-->Filter----> Output
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */


public class NoiseModSwoop extends SynthNote
{
	WhiteNoise          myNoise;
	StateVariableFilter myFilter;
	ExponentialLag      myLag;
	SineOscillator      mySine;
	MultiplyUnit        myScalar;
	MultiplyAddUnit     myOffsetter;
	
/* Declare port. */
	public SynthInput noiseAmp;
	public SynthInput cutoff;
	public SynthInput resonance;
	public SynthVariable  halfLife; /* Decay time for exponential envelope. */

/*
 * Setup synthesis.
 */
	public NoiseModSwoop()  throws SynthException
	{
		super();

/* Create various unit generators and add them to circuit. */
		add( mySine = new SineOscillator() );
		add( myLag = new ExponentialLag() );
		add( myNoise = new WhiteNoise() );
		add( myFilter = new StateVariableFilter() );
		add( myOffsetter = new MultiplyAddUnit() );
		add( myScalar = new MultiplyUnit() );
		
/* Create SynthDistributors for signals which fan-out inside circuit. */
		amplitude = new SynthDistributor( this, "amplitude" );

/* Connect SynthUnits to make control signal path. */
		myLag.halfLife.set( 0.1 );
		
/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( noiseAmp = myNoise.amplitude, "noiseAmp" );
		addPort( resonance = myFilter.resonance );
		addPort( output = myFilter.output );
		addPort( frequency = mySine.frequency );
		addPort( halfLife = myLag.halfLife );

		mySine.output.connect( myOffsetter.inputA );
		amplitude.connect( myOffsetter.inputB );
		amplitude.connect( myOffsetter.inputC );
		myLag.output.connect( myScalar.inputA );
		myOffsetter.output.connect( myScalar.inputB );
		myScalar.output.connect( myFilter.amplitude );
/* Connect SynthUnits to make audio signal path. */
		myNoise.output.connect( myFilter.input );

/* Set ports to useful values and ranges. */
		noiseAmp.setup( 0.0, 0.7, 0.4 );
		resonance.setup(  0.0, 0.2, 0.3 );
		amplitude.setup(   0.0, 0.3, 0.999 );
		frequency.setup(   0.0, 10.0, 30.0 );
		halfLife.setup(0.0, 0.4, 1.0);
	}
	
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0:
			stop( time );
			mySine.phase.set( time, -0.5 ); /* Sine(-0.5)*offset + offset = 0.0 */
			myLag.current.set( time, 1.0 );
			start( time );
			break;
		}
	}
}

