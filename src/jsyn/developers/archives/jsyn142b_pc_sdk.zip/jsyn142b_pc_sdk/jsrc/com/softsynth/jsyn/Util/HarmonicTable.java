package com.softsynth.jsyn.util;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;

/**
 * A table containing harmonics of a fundamental sine wave.
 * This can be used to generate periodic waveforms using additive synthesis.
 */

public class HarmonicTable extends SynthTable
{
/** Generated waveform will be placed in this array.
 */
	public short[]  data;
	
	double[]     partials;
	double[]     samples;
	int          numPartials;
	int          numSamples;
	double       minVal = 0.0;
	double       maxVal = 0.0;

	public HarmonicTable( int numSamples, int numPartials ) throws SynthException
	{
		super( numSamples );
		partials   = new double[numPartials];
		samples    = new double[numSamples];
		data       = new short[numSamples];
		this.numSamples = numSamples;
		this.numPartials = numPartials;
		clear();
	}
/** Specify the relative amplitude for a harmonic partial.
 * Using index=0 controls the fundamentals amplitude.
 * The resulting waveform is normalized so only the relative amplitudes matter.
 */
	public void setPartial( int index, double amplitude )
	{
		partials[index] = amplitude;
	}
	public double getPartial( int index )
	{
		return partials[index];
	}

	public int getNumPartials()
	{
		return numPartials;
	}

/* Generate table for angle ranging from -PI to +PI */
	void addHarmonics()
	{
		double sinVal, sum;
		for( int i=0; i<(numSamples - 1); i++ )
		{
			sum = 0.0;
			for( int h=0; h<numPartials; h++ )
			{
				sinVal = Math.sin( (double)(h+1)*((2.0*Math.PI*((double) i)/((double)(numSamples - 1)))) );
				sum += partials[h] * sinVal;
			}
			samples[i] = sum;
		}
		samples[numSamples-1] = samples[0]; /* Set guard point. */
	}

	void findMinMax()
	{
		double curVal;
		minVal = Double.MAX_VALUE;
		maxVal = Double.MIN_VALUE;
		for( int i=0; i<numSamples; i++ )
		{
			curVal = samples[i];
			if( curVal < minVal ) minVal = curVal;
			if( curVal > maxVal ) maxVal = curVal;
		}
	}

/**
 * Scale data array by specified value.
 */
	void scale( double scalar )
	{
		for( int i=0; i<numSamples; i++ )
		{
			samples[i] *= scalar;
		}
	}
/**
 * Scale data to be within range of -1.0 to 1.0.
 */
	void normalize()
	{
		findMinMax();
		double absMax = Math.max( Math.abs(minVal), Math.abs(maxVal) );
		if( absMax < 0.001 ) absMax = 0.001;
		double scalar = 1.0 / absMax;
//		System.out.println("absMax = " + absMax + ", scalar = " + scalar );
		scale( scalar );
	}

/** Generate a waveform by adding sinewaves partials.
 */
	public void build()
	{
		addHarmonics();
		normalize();
		write( samples );  // write doubles directly instead of converting first to shorts

		for( int i=0; i<numSamples; i++ )
		{
			data[i] = (short) (32767.0 * samples[i]);
		}
	}

/** Set amplitudes for square waveform. Then build waveform. */
	public void square()
	{
		for( int h=0; h<numPartials; h++ )
		{
			double part;
			if( (h&1) == 1 )
			{
				part = 0.0;
			}
			else
			{
				part = 2.0/(Math.PI * (double)(h+1));
			}
			partials[h] = part;
		}
		build();
	}

/** Set amplitudes for triangle waveform. Then build waveform. */
	public void triangle()
	{
		for( int h=0; h<numPartials; h++ )
		{
			double part;
			if( (h&1) == 1 )
			{
				part = 0.0;
			}
			else
			{
				part = 1.0 / ((h+1)*(h+1));
			}
			partials[h] = part;
		}
		build();
	}
	
/** Set amplitudes for sawtooth waveform. Then build waveform. */
	public void sawtooth()
	{
		for( int h=0; h<numPartials; h++ )
		{
			double part = 1.0/((double)(h+1));
			if( (h&1) == 1 ) part = -part;
			partials[h] = part;
		}
		build();
	}

/** Zero the ampltudes and the waveform.
 */
	public void clear()
	{
		for( int h=0; h<numPartials; h++ )
		{
			partials[h] = 0.0;
		}
		build();
	}
}
