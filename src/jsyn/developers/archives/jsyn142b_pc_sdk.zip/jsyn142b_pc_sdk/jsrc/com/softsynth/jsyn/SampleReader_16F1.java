package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleReader_16F1 unit.
 * This unit plays a monophonic 16-bit sample at the unit's execution rate
 * (e.g., 44100 samples/sec).
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SampleReader_16F1 extends SampleReader 
{
 	public SampleReader_16F1( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Sample_Read16F1", calculationRate);
	}
/**
 *	Create a SampleReader_16F1 that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SampleReader_16F1( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SampleReader_16F1( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
