package com.softsynth.jsyn;
import java.util.*;

/**
 *	Filter_1o1p unit.
First Order, One Pole filter using the following formula: <P>
     y(n) = A0*x(n) - B1*y(n-1)<P>

where y(n) is Output, x(n) is Input and y(n-1) is a delayed copy of the output.
<P>
This filter is a recursive IIR or Infinite Impulse Response filter.
it can be unstable depending on the values of the coefficients.
<P>
A thorough description of the digital filter theory needed to fully describe this filter is beyond the scope of this
document.
Calculating coefficients is non-intuitive; the interested user is referred to one of the standard texts on filter theory
(e.g., Moore, "Elements of Computer Music", section 2.4).

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 006
 * @see Synth
 * @see SynthUnit
 * @see Filter_1o1z
 * @see Filter_1o1p1z
 * @see Filter_2o2p
 * @see Filter_2o2p2z
 * @see StateVariableFilter
 */

public class Filter_1o1p extends SynthFilter
{
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.6. */
	public SynthInput A0;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.3. */
	public SynthInput B1;

 	public Filter_1o1p( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Filter_1o1p", calculationRate, 0 );
		A0 = new SynthInput( this, "A0" );
		B1 = new SynthInput( this, "B1" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
  	public Filter_1o1p( SynthContext synthContext ) throws SynthException
 	{
 		this( synthContext, Synth.RATE_AUDIO );
 	}
 	public Filter_1o1p( ) throws SynthException
 	{
 		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
 	}
}
