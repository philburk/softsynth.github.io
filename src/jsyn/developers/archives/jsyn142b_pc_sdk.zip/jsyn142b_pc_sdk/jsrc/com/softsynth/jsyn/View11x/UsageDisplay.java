package com.softsynth.jsyn.view11x;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import com.softsynth.jsyn.*;
/**
 * Display percent CPU utilization.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class UsageDisplay extends Panel
{
	Button  updateButton;
	Label   usageLabel;

	public UsageDisplay()
	{
		add( updateButton = new Button( "Usage" ) );
		add( usageLabel = new Label( "????" ) );
		updateButton.addActionListener(	new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{ updateDisplay(); } } );
	}

	void updateDisplay()
	{
		double usage = Synth.getUsage();
		int percent = (int) (usage * 100.0); /* Chop trailing digits. */
		usageLabel.setText( Integer.toString(percent) + "%");
	}
}
