package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
/**
 * Test SynthSound or SynthCircuit by
 * putting PortFaders on all SynthInputs.
 * Also allows user to setStage() by clicking radio buttons.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SoundTester extends InternalSoundTester
{
	public SoundTester( SynthSound sound ) throws SynthException
	{
		
		super( sound );
	}

	protected void addInput( SynthVariable input )
	{
		add( new com.softsynth.jsyn.view102.PortFader( input, input.get(), input.getMin(), input.getMax()) ); // AWT 1.0.2
	}
	
	public boolean action(Event evt, Object what)
	{
		try
		{
			for( int i=0; i<NUM_STAGES; i++ )
			{
				if(cbox[i] == evt.target)
				{
					sound.setStage(i);
					return true;
				}
			}

			if( evt.target == hitButton )
			{
				sound.setStage(0);
				return true;
			}
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
			return true;
		}
		return false;
    }

}
