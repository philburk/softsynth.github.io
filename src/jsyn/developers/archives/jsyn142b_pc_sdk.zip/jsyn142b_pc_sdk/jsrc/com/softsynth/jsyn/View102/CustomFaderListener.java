package com.softsynth.jsyn.view102;

/** Interface to get values back from a CustomFader.  Any class
that uses a CustomFader will be notified of its value being changed 
by implementing this interface. <br>
@author Nick Didkovsky and Phil Burk
*/
public interface CustomFaderListener
{
  /** Handle a value change from a CustomFader.
   * We have to pass back the fader as a class object because we are trying to support
   * both AWT 1.0.2 and AWT 1.1 and InternalCustomFader only knows 1.0.2.
   */
  	public void customFaderValueChanged(Object fader, int value);
}
