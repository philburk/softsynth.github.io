package com.softsynth.jsyn;
import java.util.*;

/**
 * ImpulseOscillator unit.
 *
 * Band limited impulse. This will sound better than the ImpulseOscillator
 * at higher frequencies, but is uses more CPU time. Note that this waveform
 * is not a single sample wide.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see SawtoothOscillator
 * @see StateVariableFilter
 */

public class ImpulseOscillatorBL extends SynthOscillator 
{
 	public ImpulseOscillatorBL( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Osc_ImpulseBL", calculationRate, 0 );
	}
/**
 *	Create a ImpulseOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public ImpulseOscillatorBL( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public ImpulseOscillatorBL( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
