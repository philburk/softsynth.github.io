package com.softsynth.jsyn;
import java.util.*;

/**
 * SineOscillator unit.
 * Uses optimized Taylor expansion to generate the sine value.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Engine
 * @see TriangleOscillator
 */

public class SineOscillator extends SynthOscillator
{

 	public SineOscillator( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Osc_Sine", calculationRate, 0 );
	}
/**
 *	Create a SineOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SineOscillator( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SineOscillator( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
