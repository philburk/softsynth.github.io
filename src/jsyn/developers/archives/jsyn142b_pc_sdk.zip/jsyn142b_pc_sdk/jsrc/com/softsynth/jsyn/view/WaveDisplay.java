package com.softsynth.jsyn.view;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;

/**
 * This class draws an associated short array as a waveform.
 * Waveforms are added in the form of a WaveTrace object.
 * The left and right indices can be set to provide zoom and pan.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class WaveDisplay extends Canvas
{
	Vector   traces;
	int      leftIndex = 0;
	int      rightIndex = 512;
	int      maxIndex;  /* maximum index of rightmost point. */
/**
 * Create WaveDisplay.
 */
	public WaveDisplay( )
	{
		traces = new Vector();
	}

	void calcMaxIndex()
	{
		maxIndex = 0;
		for( int j=0; j<traces.size(); j++)
		{
			WaveTrace trace = (WaveTrace) traces.elementAt(j);
			short[] data = trace.data;
			if( data.length-1 > maxIndex ) maxIndex = data.length-1;
		}
	}

	public void setLeftIndex( int left )
	{
		leftIndex = ( left < 0 ) ? 0 : left;
	}
	public void setRightIndex( int right )
	{
		rightIndex = ( right > maxIndex ) ? maxIndex : right;
	}

	public void panLeft()
	{
		int delta = (rightIndex - leftIndex)/2;
		if( (leftIndex - delta) < 0 ) delta = leftIndex;
		leftIndex -= delta;
		rightIndex -= delta;
	}

	public void panRight()
	{
		int delta = (rightIndex - leftIndex)/2;
		if( (rightIndex + delta) > maxIndex ) delta = maxIndex - rightIndex;
		leftIndex += delta;
		rightIndex += delta;
	}
	public void zoomIn()
	{
		int delta = (rightIndex - leftIndex)/4;
		leftIndex += delta;
		rightIndex -= delta;
	}

	void clipIndices()
	{
		if( leftIndex < 0 ) leftIndex = 0;
		if( rightIndex > maxIndex ) rightIndex = maxIndex;
	}

	public void zoomOut()
	{
		int delta = (rightIndex - leftIndex)/2;
		leftIndex -= delta;
		rightIndex += delta;
		clipIndices();
	}

	public void addTrace( WaveTrace trace )
	{
		traces.addElement( trace );
		calcMaxIndex();
	}
	public void removeTrace( WaveTrace trace )
	{
		traces.removeElement( trace );
		calcMaxIndex();
	}

	private int shortToY( short s, int h, double scaleFactor )
	{
		return (int) (h * ((1<<15) - (int)(scaleFactor * s))) >> 16;
	}
/**
 * Draw WaveTraces in their specified colors and using the specified scaleFactors.
 */
   public void paint(Graphics g)
	{
        int w = size().width;
        int h = size().height;
		int lastX, lastY;

/* Clear drawing space. */
//        g.setColor(Color.black);
//        g.fillRect(0, 0, w, h);

/* Draw X axis. */
        g.setColor(Color.white);
		g.drawLine( 0, h/2, w, h/2 );

/* Draw waveforms. */
		for( int j=0; j<traces.size(); j++)
		{
			WaveTrace trace = (WaveTrace) traces.elementAt(j);
			double scaleFactor = trace.scaleFactor;
	        g.setColor(trace.color);
			short[] data = trace.data;
			if( data.length-1 > leftIndex )
			{
				lastX = 0;
				lastY = shortToY( data[leftIndex], h, scaleFactor );
				int right = (data.length-1 < rightIndex) ? data.length-1 : rightIndex ;
				for( int i=leftIndex+1; i<=right; i++ )
				{
					int x = ((i-leftIndex)*w)/(right - leftIndex);
					int y = shortToY( data[i], h, scaleFactor );

					g.drawLine( lastX, lastY, x,y );
					lastX = x;
					lastY = y;
				}
			}
		}
/* Draw Horizontal Scale. */
        g.setColor(Color.white);
		g.drawString( Integer.toString( leftIndex ), 5, h-20 );
		g.drawString( Integer.toString( rightIndex ), w-40, h-20 );

    }
}
