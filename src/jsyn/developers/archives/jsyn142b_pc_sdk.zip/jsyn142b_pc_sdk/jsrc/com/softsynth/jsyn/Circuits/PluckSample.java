package com.softsynth.jsyn.circuits;
import java.util.*;
import com.softsynth.jsyn.*;
/**
 * PluckSample class for Java Audio Synthesis
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */


public class PluckSample extends SynthSample
{

	public PluckSample( int numFrames ) throws SynthException
	{
		super( numFrames );
	}

	public void fill()  throws SynthException
	{
		int numFrames = getNumFrames();
		short[] data = new short[numFrames];

/* Fill with decreasing noise. */
		for( int i=0; i<numFrames; i++ )
		{
			double env = ((double)numFrames - i - 1) / (double)numFrames;  /* Envelope ramps to zero. */
			data[i] = (short) (env * ((Math.random() * (2<<16)) - (2<<15)));
		}

		write( 0, data, 0, numFrames );
	}
}
