// Search for PLUGIN and APPLICATION to see what code needs to be switched.
package com.softsynth.jsyn;
import java.util.*;
import com.softsynth.util.*;

/* The JRI used for Netscape is not reentrant so methods must be declared synchronized
 * for the plugin. But the JDirect interface does not support synchronized methods so
 * we turn it off for applications.
 */
/*    /*synchronized/**/ // PLUGIN natives should be synchronized 1/3

/**
 *	This class provides access to the 'C' based audio synthesis
 *  engine through the Java native method interface.
 *  It also provides methods for starting and stopping the JSyn synthesis engine,
 * getting timing information, and for sleeping.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see SynthUnit
 * @see SynthSample
 * @see SynthEnvelope
 * @see SynthTable
 */
public class Synth  // APPLICATION 2/2
//public class Synth  extends netscape.plugin.Plugin  // PLUGIN 2/3
{
/** The isPlugin variable is used to prevent maliscious developers from using
 * the microphone without permission in an Applet.
 */
	public final static boolean isPlugin = false; // PLUGIN 3/3
	public final static int VERSION = 142;  /* Update this to match "cs_shared.h" */
	public final static String copyright = "Copyright 2000 Phil Burk, All Rights Reserved";

	static  // Static loader only loads native code if initial call to getVersion fails.
	{
		try
		{
			int vsn = getVersion(); // This will work when using JDirect or Netscape Plugin.
			System.out.println("JSyn via Netscape Plugin or JDirect - V" + vsn );  
			System.out.println("Methods are /*synchronized/**/." );
		} catch (UnsatisfiedLinkError e1) {
// Looks like we need to explicitly load the library.
			String libName = "JSynV" + VERSION;  // Native library for PC
			try
			{
				System.loadLibrary(libName);
				System.out.println("JSyn using native library " + libName );
			}
			catch (UnsatisfiedLinkError e2)
			{
				libName = "JSynNative";  // Native library for Macintosh
				try
				{
					System.loadLibrary(libName);
					System.out.println("JSyn V" + VERSION + " using native library " + libName );
				}
				catch (UnsatisfiedLinkError e3)
				{
					System.err.println("Could not load native library for JSyn V" + VERSION);
					throw e3;
				}
			}
		}
	}
	
	private static SynthContext sharedContext;
	
/** Set Synth.verbosity to Synth.SILENT, TERSE, or VERBOSE for increasing levels 
 * of debug output.
 * @deprecated Use setTrace() instead.
 */
	public       static int verbosity = 0;
/** Is engine started? */
	public       static int openCount = 0;

/** Value for verbosity, no debug output. */
	public final static int SILENT = 0;
/** Value for verbosity, sparse debug output. */
	public final static int TERSE = 1;
/** Value for verbosity, full debug output. */
	public final static int VERBOSE = 2;

	public final static int RATE_AUDIO = 0;
//	public final static int RATE_CONTROL = 1;
/** Priority for SynthUnit execution. */
	public final static int PRIORITY_LOW = 0;
	public final static int PRIORITY_MEDIUM = 1;
	public final static int PRIORITY_HIGH = 2;
/** Signed signal in the range of -1.0 to +1.0 */	
	public final static int SIGNAL_TYPE_RAW_SIGNED = 0;
/** UNSigned signal in the range of 0.0 to +2.0 */	
	public final static int SIGNAL_TYPE_RAW_UNSIGNED = 1;
/** Oscillator frequency in Hertz in the range of +/- Samplerate/2 */	
	public final static int SIGNAL_TYPE_OSC_FREQ = 2;
/** Sample reader rate in the range of 0.0 to Samplerate*2 */	
	public final static int SIGNAL_TYPE_SAMPLE_RATE = 3;
/** Halflife in seconds. */	
	public final static int SIGNAL_TYPE_HALF_LIFE = 4;
/** Time in seconds. */	
	public final static int SIGNAL_TYPE_TIME = 5;
/** Frequency for StateVariableFilter in Hertz. */	
	public final static int SIGNAL_TYPE_SVF_FREQ = 6;
/** General signal type for full range scalars. */	
	public final static int SIGNAL_TYPE_FULL_RANGE = 7;
/** Number of signal types supported. */	
	public final static int NUM_SIGNAL_TYPES = 8; // Should be one more than previous type!
	
/** Request that the synthesis occur as fast as possible, which may be slower
 * or faster than real-time. Actual synthesis will occur during calls to sleepUntilTick();
 */
	public final static int FLAG_NON_REAL_TIME = (1<<2);
/**
 * FLAG_LOOP_IF_LAST is used with SynthEnvelopeQueue and SynthSampleQueue to
 * request that the last block of data queued be looped until another block is queued.
 * This is useful for sustained waveforms, or LFOs made from envelope sections.
 */
	public final static int FLAG_LOOP_IF_LAST = (1<<3);
/**
 * FLAG_AUTO_STOP is used with SynthEnvelopeQueue and SynthSampleQueue to
 * make an instrument stop automatically when the data is finished.
 */
	public final static int FLAG_AUTO_STOP =    (1<<4);
/**
 * FLAG_ENABLE_INPUT turns on the audio capture feature.
 */
	public final static int FLAG_ENABLE_INPUT =    (1<<5);
/**
 * FLAG_DISABLE_OUTPUT turns off the audio output feature for machines that do not support full duplex recording.
 */
	public final static int FLAG_DISABLE_OUTPUT =    (1<<6);
	
	final static int JS_ERR_BASE = -200;  /* 'C' base in SynGen.h starts at -100 */
	final static int JS_ERR_CIRCUIT_CLOSED = JS_ERR_BASE - 0;
	final static int JS_ERR_OBSOLETE = JS_ERR_BASE - 1;
	final static int JS_ERR_EXPIRED = JS_ERR_BASE - 2;
	final static int JS_ERR_OUT_OF_RANGE = JS_ERR_BASE - 3;
	final static int JS_ERR_USER = JS_ERR_BASE - 4; // update this when adding new errors
	public final static int DEBUG_REPORT = 1;  /* Pass to debug() - MUST MATCH CSyn.h */
	public final static int DEBUG_THREAD = 2;  /* Pass to debug() - MUST MATCH CSyn.h */
	public final static int DEBUG_GET_ALLOCS = 5;  /* Pass to debug() - MUST MATCH CSyn.h */
/** Variable that can be used by applications to schedule algorithmically generated events
 * a minimum time in the future. Is not used internally by JSyn.
 */
	public static int timeAdvance = 100;
	public final static double DEFAULT_FRAME_RATE = 44100.0;

	/** @dll.import("JSynV142",entrypoint="CSyn_CreateContext") */
	native /*synchronized/**/ static int CreateContext();  /* Create context structure. */
	/** @dll.import("JSynV142",entrypoint="CSyn_DeleteContext") */
	native /*synchronized/**/ static void DeleteContext( int context );

	/** @dll.import("JSynV142",entrypoint="CSyn_StartEngine") */
	native /*synchronized/**/ static int StartEngine( int context, int flags, double frameRate );  /* Opens connection to SynGen. */
	/** @dll.import("JSynV142",entrypoint="CSyn_StopEngine") */
	native /*synchronized/**/ static int StopEngine( int context );

	/** @dll.import("JSynV142",entrypoint="CSyn_Start") */
	native /*synchronized/**/ static int Start( int context, int flags, double frameRate );  /* Starts synthesis process. */
	/** @dll.import("JSynV142",entrypoint="CSyn_Stop") */
	native /*synchronized/**/ static int Stop( int context );

	/** @dll.import("JSynV142",entrypoint="CSyn_Initialize") */
	native /*synchronized/**/ static int Initialize( int context );  /* Initialize synthesis library. */
	/** @dll.import("JSynV142",entrypoint="CSyn_Terminate") */
	native /*synchronized/**/ static int Terminate( int context );

	/** @dll.import("JSynV142",entrypoint="CSyn_GetUsage") */
	native /*synchronized/**/ static double GetUsage( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetObjectCount") */
	native /*synchronized/**/ static int GetObjectCount( int context );
	
	/** @dll.import("JSynV142",entrypoint="CSyn_GetFrameCount") */
	native /*synchronized/**/ static int GetFrameCount( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetTickCount") */
	native /*synchronized/**/ static int GetTickCount( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_CheckEngineErrors") */
	native /*synchronized/**/ static  int CheckEngineErrors( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetFramesPerTick") */
	native /*synchronized/**/ static int GetFramesPerTick( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetFrameRate") */
	native /*synchronized/**/ static double GetFrameRate( int context );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetTickRate") */
	native /*synchronized/**/ static double GetTickRate( int context );
	
/**
 * @return Version number of native synth library.
 */
	/** @dll.import("JSynV142",entrypoint="CSyn_GetVersion") */
	public native /*synchronized/**/ static int getVersion( );
	/** @dll.import("JSynV142",entrypoint="CSyn_CreateUnit") */
	native /*synchronized/**/ static int CreateUnit( int context, int unitHash, int rate, int param );  /* Make a unit generator. */
	/** @dll.import("JSynV142",entrypoint="CSyn_CreateCircuit") */
	native /*synchronized/**/ static int CreateCircuit( int context, int[] unitArray, int numUnits, int flags );
	/** @dll.import("JSynV142",entrypoint="CSyn_Delete") */
	native /*synchronized/**/ static int Delete( int context, int token );  /* Delete a synth object. */
	/** @dll.import("JSynV142",entrypoint="CSyn_StopUnit") */
	native /*synchronized/**/ static int StopUnit( int context, int unit );
	/** @dll.import("JSynV142",entrypoint="CSyn_StartUnit") */
	native /*synchronized/**/ static int StartUnit( int context, int unit );
	/** @dll.import("JSynV142",entrypoint="CSyn_StopUnitAt") */
	native /*synchronized/**/ static int StopUnitAt( int context, int time, int unit );
	/** @dll.import("JSynV142",entrypoint="CSyn_StartUnitAt") */
	native /*synchronized/**/ static int StartUnitAt( int context, int time, int unit );
	/** @dll.import("JSynV142",entrypoint="CSyn_ConnectUnits") */
	native /*synchronized/**/ static int ConnectUnits( int context, int srcUnit, int srcPortHash, int srcPartNum,
                              int dstUnit, int dstPortHash, int dstPartNum );
	/** @dll.import("JSynV142",entrypoint="CSyn_DisconnectUnits") */
	native /*synchronized/**/ static int DisconnectUnits( int context, int dstUnit, int dstPortHash, int partNum );
	/** @dll.import("JSynV142",entrypoint="CSyn_SetPriority") */
	native /*synchronized/**/ static int SetPriority( int context, int token, int priority );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetPriority") */
	native /*synchronized/**/ static int GetPriority( int context, int token );
	/** @dll.import("JSynV142",entrypoint="CSyn_SetPort") */
	native /*synchronized/**/ static int SetPort( int context, int token, int portHash, int partNum, double value );
	/** @dll.import("JSynV142",entrypoint="CSyn_SetPortAt") */
	native /*synchronized/**/ static int SetPortAt( int context, int time, int token, int portHash, int partNum, double value );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetPort") */
	native /*synchronized/**/ static double GetPort( int context, int token, int portHash, int partNum );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetPortFrames") */
	native /*synchronized/**/ static int GetPortFrames( int context, int token, int portHash, int partNum );
	/** @dll.import("JSynV142",entrypoint="CSyn_SetPortSignalType") */
	native /*synchronized/**/ static int SetPortSignalType( int context, int token, int portHash, int partNum, int signalType );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetPortSignalType") */
	native /*synchronized/**/ static int GetPortSignalType( int context, int token, int portHash, int partNum );
	/** @dll.import("JSynV142",entrypoint="CSyn_CreateSample") */
	native /*synchronized/**/ static int CreateSample( int context, int numBytes, int flags );
	/** @dll.import("JSynV142",entrypoint="CSyn_WriteSampleJava") */
	native /*synchronized/**/ static int WriteSample( int context, int sample, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_ReadSampleJava") */
	native /*synchronized/**/ static int ReadSample( int context, int sample, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_CreateEnvelope") */
	native /*synchronized/**/ static int CreateEnvelope( int context, int numFrames );
	/** @dll.import("JSynV142",entrypoint="CSyn_WriteEnvelopeJava") */
	native /*synchronized/**/ static int WriteEnvelope( int context, int envel, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_ReadEnvelopeJava") */
	native /*synchronized/**/ static int ReadEnvelope( int context, int envel, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_ClearDataQueue") */
	native /*synchronized/**/ static int ClearDataQueue( int context, int unit, int portHash );
	/** @dll.import("JSynV142",entrypoint="CSyn_ClearDataQueueAt") */
	native /*synchronized/**/ static int ClearDataQueueAt( int context, int time, int unit, int portHash );
	/** @dll.import("JSynV142",entrypoint="CSyn_QueueData") */
	native /*synchronized/**/ static int QueueData( int context, int unit, int portHash, int token, int startFrame, int numFrames, int flags );
	/** @dll.import("JSynV142",entrypoint="CSyn_QueueDataAt") */
	native /*synchronized/**/ static int QueueDataAt( int context, int time, int unit, int portHash, int token, int startFrame, int numFrames, int flags );
	/** @dll.import("JSynV142",entrypoint="CSyn_CreateTable") */
	native /*synchronized/**/ static int CreateTable( int context, int numValues );
	/** @dll.import("JSynV142",entrypoint="CSyn_WriteTableJava") */
	native /*synchronized/**/ static int WriteTable( int context, int table, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_WriteTableDoublesJava") */
	native /*synchronized/**/ static int WriteTableDoubles( int context, int table, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV142",entrypoint="CSyn_UseTable") */
	native /*synchronized/**/ static int UseTable( int context, int unit, int portHash, int partNum, int table );
	/** @dll.import("JSynV142",entrypoint="CSyn_SetTrace") */
	native /*synchronized/**/ static void SetTrace( int context, int mask );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetTrace") */
	native /*synchronized/**/ static int GetTrace(int context);
	/** @dll.import("JSynV142",entrypoint="CSyn_SleepUntilTick") */
	native static int SleepUntilTick( int context, int tick );
	/** @dll.import("JSynV142",entrypoint="CSyn_GetNumParts") */
	native /*synchronized/**/ static int GetNumParts( int context, int token, int portHash );
	
	/** @dll.import("JSynV142",entrypoint="CSyn_Debug") */
	public native /*synchronized/**/ static int Debug( int context, int id, int data );
// Begin public native methods ======================================================
	
/**
 *	Returns the expiration date for this version of JSyn.
 *  Licensed copies will return 0 for NO expiration.
 *  Date is a single integer in the format (((Y*100)+M*100)+D), eg. 19970831
 *
 *	@return expiration date
 */
	/** @dll.import("JSynV142",entrypoint="CSyn_GetExpirationDate") */
	public native /*synchronized/**/ static int getExpirationDate( );

	public static SynthContext getSharedContext()
	{
		return sharedContext;
	}
// Begin public non-native methods ======================================================
	
	public static int debug( )
	{
		return sharedContext.debug();
	}

	public static int debug( int command, int data )
	{
		return sharedContext.debug( command, data );
	}

/**
 *	Returns the fraction of critical resources used by synthesis engine.
 *  A value of 0.5 would be 50%.
 *
 *	@return fraction of resources used.
 */
	public static double getUsage()
	{
		return sharedContext.getUsage();
	}

/**
 *	@return Number of units, samples, tables and other objects allocated.
 */
	public static int getObjectCount()
	{
		return sharedContext.getObjectCount();
	}
	
/**
 *	Returns index of last calculated frame.
 *	The frame index will tend to jump upwards because frames are calculated in 
 *	large blocks by a high priority process.
 *
 *	@return Index of last calculated frame.
 */
	
	public static int getFrameCount()
	{
		return sharedContext.getFrameCount();
	}
	
/** Get current time in ticks. This is the basic clock use for scheduling in JSyn.
 *	@return Count of synthesis ticks.
 */
	public static int getTickCount()
	{
		return sharedContext.getTickCount();
	}

/**
 *	@return Number of audio frames per clock tick.
 */
	public static int getFramesPerTick()
	{
		return sharedContext.getFramesPerTick();
	}
	
/** Rate that frames are generated, typically 44100.0.
 *	@return Number of audio frames per second.
 */
	public static double getFrameRate( )
	{
		return sharedContext.getFrameRate();
	}
	
/**
 *	@return Number of clock ticks per second.
 */
	public static double getTickRate( )
	{
		return sharedContext.getTickRate();
	}
	
 /**
 * Sleep until the specified tick is reached.
 * @exception SynthException	 If timer not running.
 */
	public static void sleepUntilTick( int tick )
	throws SynthException
//	throws InterruptedException
	{
		sharedContext.sleepUntilTick( tick );
	}
		
/**
 * Used by sleep routines to keep FIFOs clear.
 *	@return errors from Synth engine running in background.
 */
	public static void checkEngineErrors() 
	throws SynthException
	{
		sharedContext.checkEngineErrors();
	}
	
/**
 * Sleep for the specified number of ticks.
 * @exception SynthException	 If timer not running.
 */
	public static void sleepForTicks( int ticks )
	throws SynthException
//	throws InterruptedException
	{
		sharedContext.sleepForTicks( ticks );
	}
/**
 *	Calls initialize() and start( flags, frameRate ).
 *
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized static void startEngine( int flags, double frameRate )
	throws SynthException
	{
		initialize();
		start( flags, frameRate );
	}
	
/**
 * Starts execution of process that performs synthesis.
 * This must be called before performing any synthesis.
 * If the flag Synth.FLAG_ENABLE_INPUT is set, and JSyn is running
 * as a plugin, then a dialog will appear asking for permission to
 * record from the microphone. If granted, then AudioInputPermission
 * will be set true. If not then the process will abort.
 * 
 * @param flags used to select options. Legal flags are Synth.FLAG_NON_REAL_TIME, Synth.FLAG_ENABLE_INPUT, Synth.FLAG_DISABLE_OUTPUT.
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized static void start( int flags, double frameRate )
	throws SynthException
	{
		sharedContext.start( flags, frameRate );
	}
	
	public synchronized static void start( int flags )
	throws SynthException
	{
		start( flags, DEFAULT_FRAME_RATE );
	}

/**
 *	Starts execution of process using default frameRate.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public static void startEngine( int flags )
	throws SynthException
	{
		startEngine( flags, DEFAULT_FRAME_RATE );
	}
/**
 *	Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void stopEngine( )
	throws SynthException
	{
		stop();
		terminate();
	}
/**
 *	Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void stop( )
	throws SynthException
	{
		sharedContext.stop();
	}
/** If the existing version is earlier than the 
 * requested version, then the user will be instructed to
 * upgrade to the latest version of JSyn.
 */
	public static void requestVersion( int requestedVersion )
	{
		String upgradeMessage = 
			"This Java Applet or application requires JSyn version \"" + (((double)requestedVersion)/10) + "\".\n" +
			"You have version \"" + (((double)VERSION)/10) + "\" installed on your computer\n" +
			"As a result, it may not work properly.\n\n" +
			"Please download a free upgrade to the new version\n" +
			"of the JSyn plugin at:\n\n" +
			"    http://www.softsynth.com/jsyn/plugins/";
		if( requestedVersion > VERSION )
		{
			SynthAlert.showError( upgradeMessage );
		// Wait for SynthAlert window to be completely closed so
		// that DirectSound doesn't get confused about GetFrontWindow() under startEngine().
			try
			{
				Thread.sleep(200);
			} catch( InterruptedException e ) {}
		}
	}
	
/**
 *	Initialize Library.
 *	This must be called before any other synthesis functions.
 *  Resets AudioInputPermission.
 *  This allocates a shared SynthContext if one does not already exist.
 *
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized static void initialize()
	throws SynthException
	{
		if( sharedContext == null )
		{
			sharedContext = new SynthContext();
		}
		sharedContext.setTrace( verbosity );
		sharedContext.initialize();
		openCount = sharedContext.openCount;
	}

/**
 *	Terminate library.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void terminate( )
	throws SynthException
	{
		//System.out.println("Synth.terminate()");
		sharedContext.terminate(); 
		openCount = sharedContext.openCount;
/************
 * NOTE - for compatibility, keep the context because Applets
 * with threads may call Synth mathods after Synth.stopEngine()
		if( openCount <= 0 )
		{
			sharedContext.delete();
			sharedContext = null;
		}
****************/
	}

/* Internal native method that fills a byte array. */
	/** @dll.import("JSynV142",entrypoint="CSyn_ErrorCodeToTextJava") */
	native /*synchronized/**/ static int ErrorCodeToText( int errorCode, byte[] text, int textSize );
	public static String errorCodeToString( int errorCode )
	{
//		if( openCount <= 0 ) return "JSyn error text unavailable because engine not started.";
		
		if( errorCode <= JS_ERR_BASE )
		{
			switch( errorCode )
			{
			case JS_ERR_CIRCUIT_CLOSED: return "SynthCircuit already compiled.";
			case JS_ERR_OBSOLETE: return "JSyn version mismatch. Download new version from www.softsynth.com.";
			case JS_ERR_EXPIRED: return "JSyn version EXPIRED! Download new version from www.softsynth.com.";
			case JS_ERR_OUT_OF_RANGE: return "JSyn value out of range.";
			case JS_ERR_USER: return "JSyn user code detected error.";
			}
			return "Unrecognized JSyn error.";
		}
		else
		{
			byte[] text = new byte[128];
			try
			{
				int len = ErrorCodeToText( errorCode, text, 128 );
				return new String( text, 0, 0, len );
			} catch( UnsatisfiedLinkError e ) {
				return "JSyn error text unavailable because link failed.";
			}
		}
	}
	
/**
 * Convert a String to a hash value that is used internally in CSyn for fast
 * name lookup. This must match the algorith used in "gen_hash.c".
 */
	public static int hashName( String name )
	{
		int   len = name.length();
		int   hash = 0;
		int   shiftBy = 0;
		char  c;
		for( int i=0; i<len; i++ )
		{
			c = name.charAt(i);
			hash += c << shiftBy;
			shiftBy += 3;
			if( shiftBy > 19 ) shiftBy -= 20;
		}
	
		return hash;
	}
	
/** Set trace flags for debugging. */
	public static void setTrace( int mask )
	{
		verbosity = mask;
		if( sharedContext != null ) sharedContext.setTrace( mask );
	}
	public static int getTrace()
	{
		return sharedContext.getTrace();
	}
}


