package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthScalarPort are ports that have a simple scalar signal value.
 * It is the root class for SynthVariable, SynthInput, SynthOutput
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthScalarPort extends SynthPort
{
	SynthScalarPort( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	
/**
 * @return current instantaneous value of port.
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public double get( int partIndex )
	throws SynthException
	{
		double value = Synth.GetPort( sound.context, peerToken, portHash, partIndex);
/* Check for error return indicator disguised as a big negative number. */
		if( value < -1000000.0)
		{
			throw new SynthException( (int)(value + 999999.9), peerToken, partIndex );
		}
		return value;
	}

	public double get()
	throws SynthException
	{
		return get( 0 );
	}
}
