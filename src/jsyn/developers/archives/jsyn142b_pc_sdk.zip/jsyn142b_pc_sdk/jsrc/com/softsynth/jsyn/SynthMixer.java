package com.softsynth.jsyn;
import java.util.*;
/**
 * SynthMixer class for Java Audio Synthesis.
 * <P>
 * Constructs an NxM array of gain elements using MultiPlyAddUnits.
 * Extra outputs can be created and used for "effect sends".
 * <br>
 * Connect the output of the mixer to a LineOut to hear the mixed results,
 * or send some output channels to effects processors.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 007
 * @see Synth
 * @see BusReader
 * @see MultiplyAddUnit
 * @see LineOut
 */

public class SynthMixer extends SynthCircuit
{
	int   numInputs;
	int   numOutputs;

	MultiplyAddUnit[][]  nodes;

/**
Construct a mixer with numInputs and numOutputs.  The mixer consists of a two-dimensional
array of MultiplyAddUnits. The amount that each input contributes to each output
can be controlled individually.
@exception SynthException If allocation fails.
*/
	public SynthMixer( int   numInputs, int   numOutputs )
	throws SynthException
	{
		this.numInputs = numInputs;
		this.numOutputs = numOutputs;
		nodes = new MultiplyAddUnit[numInputs][numOutputs];

		for( int j=0; j<numOutputs; j++ )
		{
			for( int i=0; i<numInputs; i++ )
			{
				add( nodes[i][j] = new MultiplyAddUnit() );
				/* Daisy chain MACs */
				if( i>0 )
				{
					nodes[i-1][j].output.connect( nodes[i][j].inputC );
				}
			}
		}
	}

/**
 Connect a SynthOutput port to an input of the mixer.
 @exception SynthException If index or partNum are out of range.
*/
	public void connectInput( int inputIndex, SynthOutput port, int partNum )
	throws SynthException
	{
		for( int i=0; i<numOutputs; i++ )
		{
			MultiplyAddUnit node = nodes[inputIndex][i];
			port.connect( partNum, node.inputA, 0 );
		}
	}

/**
 * Get the output port associated with the given index.
 */
	public SynthOutput getOutput( int outputIndex )
	{
		return nodes[numInputs-1][outputIndex].output;
	}
	
/**
 Connect an output of the mixer to a SynthInput port.
 @exception SynthException If index or partNum are out of range.
*/
	public void connectOutput( int outputIndex, SynthInput port, int partNum )
	throws SynthException
	{
		MultiplyAddUnit node = nodes[numInputs-1][outputIndex];
		node.output.connect( 0, port, partNum );
	}

/**
Specify the amount of the indexed input that is added to
the indexed output.
@exception SynthException If index or partNum are out of range.
*/
	public void setGain( int inputIndex, int outputIndex, double gain )
	throws SynthException
	{
		MultiplyAddUnit node = nodes[inputIndex][outputIndex];
		node.inputB.set( gain );
	}
/**
Specify the amount of the indexed input that is added to
the indexed output at the specified time.
@exception SynthException If index or partNum are out of range.
*/
	public void setGain( int time, int inputIndex, int outputIndex, double gain )
	throws SynthException
	{
		MultiplyAddUnit node = nodes[inputIndex][outputIndex];
		node.inputB.set( time, gain );
	}

}
