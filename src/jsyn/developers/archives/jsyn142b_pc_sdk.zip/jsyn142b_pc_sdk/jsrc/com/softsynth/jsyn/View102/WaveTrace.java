package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;

/**
 * WaveTrace is a wrapper for the information needed to draw a trace in a WaveDisplay.
 * @see WaveDisplay
 */
public class WaveTrace
{
	public  short[]  data;
	public  Color    color;
	public  double   scaleFactor;

	public WaveTrace( short[] data, Color color, double scaleFactor )
	{
		this.data = data;
		this.color = color;
		this.scaleFactor = scaleFactor;
	}
}
