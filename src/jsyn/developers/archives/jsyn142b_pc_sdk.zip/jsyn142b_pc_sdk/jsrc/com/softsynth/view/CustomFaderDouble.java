package com.softsynth.view;
import java.util.*;

/************************************************************************
 * Custom Fader that generates floating point values.
 */
public class CustomFaderDouble extends com.softsynth.view.CustomFader  implements ValueController
{
	double     min,max;
	protected final static int RANGE = 2000;
	Vector      valueListeners;
	ValueEvent  event;

	public CustomFaderDouble( int orientation, double initialValue, double min, double max )
	{
		super( orientation, 0, RANGE/20, 0, RANGE );
		valueListeners = new Vector();
		event = new ValueEvent( this );
		this.min = min;
		this.max = max;
		setValue( initialValue );
		setUnitIncrement( RANGE/100 );
	}

/** Send ValueChanged event to every subscribed listener. */
	void tellListeners()
	{
		super.tellListeners();
		if( valueListeners == null ) return;
		Enumeration e = valueListeners.elements();
		event.setValue( getDoubleValue() );
		while( e.hasMoreElements() )
		{
			ValueListener listener = (ValueListener) e.nextElement();
	 		listener.valueChanged( event );
		}
	}
	
	public void addValueListener( ValueListener listener )
	{
		valueListeners.addElement( listener );
	}
	public void removeValueListener( ValueListener listener )
	{
		valueListeners.removeElement( listener );
	}

	public double faderToDouble( int val )
	{
			return ((val*(max-min))/RANGE) + min;
	}
	
	public int doubleToFader( double fval )
	{
			return (int)(((fval - min)*RANGE)/(max-min));
	}

	public double getMinimum() { return min; }
	public double getMaximum() { return max; }
	
/** Set minimum value corresponding to the leftmost fader position. */
	public void setMinimum( double min )
	{
		this.min = min;
	}
/** Set maximum value corresponding to the rightmost fader position. */
	public void setMaximum( double max )
	{
		this.max = max;
	}
	
	public void setValue( double fval )
	{
		int ival = doubleToFader( fval );
		super.setValue( ival );
	}
	
	public double getDoubleValue()
	{
		return faderToDouble( getValue() );
	}
}
