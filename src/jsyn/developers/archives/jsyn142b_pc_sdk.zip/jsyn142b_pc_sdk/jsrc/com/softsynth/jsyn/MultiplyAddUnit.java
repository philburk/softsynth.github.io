package com.softsynth.jsyn;
import java.util.*;

/**
 *	MultiplyAddUnit unit.<br><pre>
 *      output = (inputA * inputB) + inputC;</pre><br>
 *	This is often used to scale a control signal and add an offset.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see MultiplyAddUnsignedUnit
 */

public class MultiplyAddUnit extends SynthUnit 
{
/** SIGNAL_TYPE_RAW_SIGNED, -1.0 to +1.0 */
	public SynthInput inputA;
/** SIGNAL_TYPE_RAW_SIGNED, -1.0 to +1.0 */
	public SynthInput inputB;
/** SIGNAL_TYPE_RAW_SIGNED, -1.0 to +1.0 */
	public SynthInput inputC;
/** SIGNAL_TYPE_RAW_SIGNED, -1.0 to +1.0 */
	public SynthOutput output;

 	public MultiplyAddUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_MultiplyAdd", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		inputC = new SynthInput( this, "InputC" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public MultiplyAddUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public MultiplyAddUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
