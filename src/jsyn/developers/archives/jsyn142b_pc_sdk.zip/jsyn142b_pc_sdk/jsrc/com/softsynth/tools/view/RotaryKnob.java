package com.softsynth.tools.view;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.*;
import com.softsynth.util.*;
import com.softsynth.view.*;

/**
 * RotaryKnob like on a synthesizer.
 * 
@author Phil Burk, SoftSynth.com, All Rights Reserved
*/
public class RotaryKnob extends Canvas implements MouseListener, MouseMotionListener, ValueController
{
	public final static int    LINEAR = 0;
	public final static int    EXPONENTIAL = 1;
	int         taper = LINEAR;
	Vector      listeners;
	ValueEvent  event;
	double minAngle = -0.9 * Math.PI;
	double maxAngle = 0.9 * Math.PI;
	double minVal;
	double maxVal;
	double logMax;
	double logMin;
	double fraction; // ranges from 0.0 to 1.0 for min to max
	double value;
	double unitIncrement = 0.01;
	int    lastY;
	int    diameter;
	int    radius;
	int    x0, y0;

 /** Constructor with initial value, visible, min value, max value.  LineIncrement defaults to 1, PageIncrement defaults to 10 (see setUnitIncrement() and setBlockIncrement() below) */
	public RotaryKnob( double val, double min, double max )
	{
		listeners = new Vector();
		event = new ValueEvent( this );
		setValues( val, min, max );
		addMouseListener(this);
  		addMouseMotionListener(this);
	}


/** Add a listener to receive value change events.
 */
	public void addValueListener( ValueListener listener )
	{
		listeners.addElement( listener );
	}
	public void removeValueListener( ValueListener listener )
	{
		listeners.removeElement( listener );
	}
/** Set taper to LINEAR or EXPONENTIAL
 */
	public void setTaper( int taper )
	{
		this.taper = taper;
		setValue( value );
	}
	public int getTaper()
	{
		return taper;
	}
	
	private void internalSetValue(double v)
	{
		value = v;
		tellListeners();
		repaint();
	}
	
	public void setValue(double v)
	{
		if (v < minVal) v = minVal;
		else if (v > maxVal) v = maxVal;
		fraction = valueToFraction( v );
		internalSetValue( v ) ;
	}
	
/** @return current value */	 
	public double getValue()
	{
		return value;
	}
/** @return current value */	 
	public double getDoubleValue()
	{
		return value;
	}
	
	void setFraction(double frac)
	{
		fraction = (frac < 0.0) ? 0.0 : ((frac > 1.0) ? 1.0 : frac);
		internalSetValue( fractionToValue( fraction ) );
	}

	/** Set current value, minimum value, maximum value of fader */
	public void setValues(double val, double min, double max)
	{
		value = val;
		setMinimum( min );
		setMaximum( max );	
	}

/** Set maximum for value.
 */
	public void setMaximum( double maximum )
	{
		maxVal = maximum;
		logMax = Math.log(maximum);
		setValue( value );
	}
/** Get maximum value.
 */
	public double getMaximum()
	{
		return maxVal;
	}

/** Set minimum for value.
 */
	public void setMinimum( double minimum )
	{
		minVal = minimum;
		logMin = Math.log(minimum);
		setValue( value );
	}
/** Get minimum value.
 */
	public double getMinimum()
	{
		return minVal;
	}
	
/** Set nominal increment value as a fraction from 0.0 to 1.0. */
	public void setUnitIncrement(double v) {
		unitIncrement = v;
	}

	public double getUnitIncrement() {
		return unitIncrement;
	}
		
// **************************************************************************
// ************ Private Internal Implementation Methods *********************
// **************************************************************************

	
/** Send ValueChanged event to every subscribed listener. */
	private void tellListeners()
	{
		Enumeration e = listeners.elements();
		event.setValue( value );
		while( e.hasMoreElements() )
		{
			ValueListener listener = (ValueListener) e.nextElement();
	 		listener.valueChanged( event );
		}
	}
	
	double valueToFraction( double val )
	{
		double result = 0.0;
		switch( taper )
		{
		case LINEAR:
			result = (val - minVal) / (maxVal - minVal);
			break;
		case EXPONENTIAL:
			result = (Math.log(val) - logMin) / (logMax - logMin);
			break;
		}
		return result;
	}
	
	double fractionToValue( double frac )
	{
		double result = 0.0;
		switch( taper )
		{
		case LINEAR:
			result = (frac * (maxVal - minVal)) + minVal;
			break;
		case EXPONENTIAL:
			double range = Math.log(maxVal / minVal);
			double exp = fraction * range;
			result = minVal * Math.exp( exp );
			break;
		}
		return result;
	}
	
	protected void setKnobByXY( int x, int y)
	{
	// Scale increment by X position.
		int xdiff = x0 - x; // More to left causes bigger increments.
		double power = (double) xdiff / (double) radius;
		double perPixel = unitIncrement * Math.pow( 2.0, power );
		
		int ydiff = lastY - y;
		setFraction( fraction + (ydiff * perPixel) );
		lastY = y;
	}
   
	protected void handleMousePressed( boolean isShiftDown, int x, int y)
	{
		lastY = y;
		setKnobByXY( x, y );
//		System.out.println("handleMousePressed: " + this + x + ", " + y );
	}
	
	protected void handleMouseDragged( int x, int y)
	{
		setKnobByXY( x, y );		
	}
	
	protected void handleMouseReleased(int x, int y)
	{
		setKnobByXY( x, y );
	}
	
	private double fractionToAngle( double fraction )
	{
		return (fraction * (maxAngle - minAngle)) + minAngle;;
	}
  
  /* flicker killer */
	public void update(Graphics g)
	{
		g.setColor( Color.lightGray  );
		g.fillOval( x0 - radius, y0 - radius, diameter, diameter );
		// drawLineIndicator(g);
		drawPolyIndicator(g);
	}
	
	void drawLineIndicator(Graphics g)
	{
		double angle = fractionToAngle( fraction );
		double arrowSize = radius * 0.95;
		int arrowX = (int) (arrowSize * Math.sin( angle ));
		int arrowY = (int) (arrowSize * Math.cos( angle ));
		g.setColor( Color.red );
		g.drawLine( x0, y0, x0 + arrowX, y0 - arrowY );
	// draw little dot at end
		double dotScale = 0.1;
		int dotRadius = (int)(dotScale * arrowSize);
		if( dotRadius > 1 )
		{
			int dotX = x0 + (int)((0.99 - dotScale) * arrowX) - dotRadius;
			int dotY = y0 - (int)((0.99 - dotScale) * arrowY) - dotRadius;
			g.fillOval( dotX, dotY, dotRadius*2, dotRadius*2 );
		}
	}
	
	void drawPolyIndicator(Graphics g)
	{
		int arrowSize = (int) (radius * 0.95);
		int arrowWidth = (int) (radius * 0.2);
		int xp[] = { 0, arrowWidth, 0, -arrowWidth };
		int yp[] = { arrowSize, -arrowSize/2, 0, -arrowSize/2 };
		double angle =  fractionToAngle( fraction );
		double sa = Math.sin( angle );
		double ca = Math.cos( angle );
		for( int i=0; i<xp.length; i++ )
		{
			int x = xp[i];
			int y = yp[i];
			xp[i] = x0 - (int) ((x*ca) - (y*sa));
			yp[i] = y0 - (int) ((x*sa) + (y*ca));
		}
		g.setColor( isEnabled() ? Color.red : Color.red.darker() );
		g.fillPolygon( xp, yp, xp.length );
	}
   
	public void paint(Graphics g)
	{
		int width = bounds().width;
		int height = bounds().height;
		x0 = width/2;
		y0 = height/2;
		diameter = (width < height) ? width : height;
		diameter -= 4;
		radius = diameter/2;
		
		g.setColor( Color.darkGray  );
		g.fillOval( x0 - radius + 2, y0 - radius + 2, diameter, diameter );
		update( g );
	}

// placate the MouseMotionListener interface for AWT 1.1
	public void mouseDragged(MouseEvent e)
	{
//		System.out.println("AWT1.1 - dragged " + e.getX() + ", " + e.getY() );
		handleMouseDragged( e.getX(), e.getY());
	}
	public void mouseMoved(MouseEvent e) { }
	
	// placate the MouseListener interface
	public void mousePressed(MouseEvent e)
	{
		handleMousePressed( e.isShiftDown(), e.getX(), e.getY());
//		System.out.println("AWT1.1 - pressed " + isShiftDown + ", " + e.getX() + ", " + e.getY() );
	}
	  
	public void mouseClicked(MouseEvent e) { }
	
	public void mouseReleased(MouseEvent e)
	{
//		System.out.println("AWT1.1 - released " + e.getX() + ", " + e.getY() );
		handleMouseReleased( e.getX(), e.getY());
	}
	public void mouseEntered(MouseEvent e)
	{
	}
	public void mouseExited(MouseEvent e)
	{
	}
}
