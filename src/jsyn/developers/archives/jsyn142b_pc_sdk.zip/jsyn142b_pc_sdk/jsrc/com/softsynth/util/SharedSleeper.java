package com.softsynth.util;
import  java.util.*;

/**
 * Allow multiple threads to sleep on a single resource 
 * such as a non-real-time software synthesizer.
 * 
 * @author (C) 2000 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SharedSleeper
{
	int        currentIndex = 0;
	Vector     threads;
	int        numWaiting = 0;
	
	public SharedSleeper()
	{
		threads = new Vector();
	}

/** Add thread to list of Threads that share this sleeper.
 * Adding a thread can prevent the other threads from advancing and
 * leaving this one behind.
 * If a thread has already been added, nothing happens.
 */
	public synchronized void addThread( Thread thread )
	{
		if( !threads.contains( thread ) )
		{
			System.out.println("SharedSleeper.addThread: thread = " + thread );
			threads.addElement( thread );
		}
	}
/** Add current thread to list of Threads that share this sleeper.
 */
	public synchronized void addThread()
	{
		addThread( Thread.currentThread() );
	}
	
	public synchronized void removeThread()
	{
		Thread current = Thread.currentThread();
		threads.removeElement( current );
		notifyAll();
	}
	
	public void setIndex( int index )
	{
		currentIndex = index;
	}
	public int getIndex()
	{
		return currentIndex;
	}
	
/** Overridden by clients to perform work.
 */
	public int bumpIndex()
	{
		int nextIndex = currentIndex + 1;
		//System.out.println("SharedSleeper.bumpIndex: index = " + nextIndex );
		return nextIndex;
	}
	
	private synchronized boolean addWaiter()
	{
	/* Strip dead threads from list. */
		for (Enumeration e = threads.elements() ; e.hasMoreElements() ;)
		{
			Thread t = (Thread) e.nextElement();
			if( !t.isAlive() )
			{
				threads.removeElement( t );
				System.out.println("SharedSleeper.addWaiter: remove dead thread = " + t );
			}
		}
		numWaiting += 1;
		return ( numWaiting >= threads.size() ); // are we last thread to call sleep?
	}
	
	private synchronized void removeWaiter()
	{
		numWaiting -= 1;
	}
	
	private synchronized int waitForBump() throws InterruptedException
	{
		boolean lastWaiter = addWaiter();
		try
		{
			if( lastWaiter )
			{
			// We are the last one to addWaiter so we have the honor of bumping the index!
				currentIndex = bumpIndex();
				this.notifyAll();
			}
			else
			{
			// Other threads are still running, so wait for them to sleep.
				this.wait( 100 );		
			}
		} finally {
			removeWaiter();
			return currentIndex;
		}
	}
	
/** Sleep until the given index is reached.
 * Index can wrap around as long as we don't wait for more than half a circle.
 */
	public int sleepUntilIndex( int desiredIndex ) throws InterruptedException
	{
		int thisIndex = currentIndex;
	//System.out.println("SharedSleeper.sleep: ENTER desired = " + desiredIndex +
	//				   ", current = " + currentIndex );
		
	// Set priority to lowest so that other threads can get their
	// sleep requests in while we spin.
		Thread thread = Thread.currentThread();
		int oldPriority = thread.getPriority();
		thread.setPriority( Thread.MIN_PRIORITY );
		
		try
		{
		// Are we there yet?
			thisIndex = currentIndex;
			while( (desiredIndex - currentIndex) > 0 )
			{
		// give other threads a chance to run
				Thread.yield();
				thisIndex = waitForBump();
				// System.out.println("SharedSleeper.sleep: loop desired = " + desiredIndex + ", thisIndex = " + thisIndex );
			}
		} finally {
			thread.setPriority( oldPriority );
	//System.out.println("SharedSleeper.sleep: EXIT desired = " + desiredIndex + ", thisIndex = " + thisIndex );
			return thisIndex;
		}
	}
}
