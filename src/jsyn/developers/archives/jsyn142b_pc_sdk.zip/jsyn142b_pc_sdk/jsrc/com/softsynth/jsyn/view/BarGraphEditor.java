package com.softsynth.jsyn.view;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/**
 * Edit an array of double values using a bar-graph style display.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class BarGraphEditor extends XYController
{
	double       data[];
	int          numValues;
	int          previousHighlightIndex = -1;	
		
	public BarGraphEditor( double data[] )
	{
		setArray( data );
	}
/** Specify array to be edited by this controller. */
	public void setArray( double data[] )
	{
		this.data = data;
		numValues = data.length;
		setMaxWorldX( (double) numValues );
	}
	
/* Draw one value in highlight mode (XOR). */
	void drawHighlight( Graphics g, int idx )
	{
		int x;
		int width = bounds().width;
		int height = bounds().height;
		int barWidth = width / numValues;

		x = convertWXtoGX( (double)idx );
		g.setXORMode( Color.orange );
		g.fillRect( x, 0, barWidth, height );
		g.setPaintMode();
	}

/** Unhighlight previous value, highlight new one.
 * @param idx index of value to be highlighted
 */
	public void highlight( int idx )
	{
		Graphics g = getGraphics();
		if( g == null ) return;
		if( previousHighlightIndex >= 0 )
		{
			drawHighlight( g, previousHighlightIndex ); /* Unhighlight previous. */
		}
		drawHighlight( g, idx );
		previousHighlightIndex = idx;	
	}
	
	void updateDrawing( int idx, double oldVal, double val )
	{
		Graphics g = getGraphics();
		if( g == null ) return;
		
		int x,y1,y2;
		int width = bounds().width;
		int height = bounds().height;

		int barWidth = (width / numValues) - 4;
		if( barWidth < 3 ) barWidth = 3;

		y1 = convertWYtoGY( oldVal );
		y2 = convertWYtoGY( val );
		if( y1 > y2 )  // sort
		{
			x = y1;
			y1 = y2;
			y2 = x;
		}
/* Draw new value by XORing difference. */
		if( y1 != y2 )
		{
			x = convertWXtoGX( (double)idx ) + 2;
			g.setXORMode( getBackground() );
			g.fillRect( x, y1, barWidth, y2-y1 );
			g.setPaintMode();
		}
	}
	
	void convertMouse( Event evt, int x, int y )
	{		
		double val;
// Determine array index from X position.
		int idx = (int)convertGXtoWX(x);
		if( idx < 0 ) idx = 0;
		else if ( idx >= numValues ) idx = numValues - 1;
		
// If SHIFT key held down, generate random Y value in range.
		if( evt.shiftDown() )
		{
			val = minWorldY + (Math.random() * (maxWorldY - minWorldY));
		}
		else
		{
			val = clipWorldY( convertGYtoWY(y) );
		}
// update array
		double oldVal = data[ idx ];
		data[ idx ] = val;
		if( oldVal != val ) updateDrawing( idx, oldVal, val );
	}
	
/* Respond to 1.0.2 style AWT mouse actions. */
	public boolean mouseDown( Event evt, int x, int y )
	{
		convertMouse( evt, x, y );
		return true;
	}
	public boolean mouseDrag( Event evt, int x, int y )
	{
		convertMouse( evt, x, y );
		return true;
	}
	public boolean mouseUp( Event evt, int x, int y )
	{
		return true;
	}

/* Override default paint action. */
	public void paint( Graphics g )
	{
		int x,y;
		int width = bounds().width;
		int height = bounds().height;
		
		int barWidth = (width / numValues) - 4;
		if( barWidth < 3 ) barWidth = 3;

// draw background and erase all values
		g.setColor( getBackground() );
		g.fillRect(0, 0, width, height );
		
// draw each value as a bar in foreground color
		g.setColor( getForeground() );
		for( int i=0; i<numValues; i++ )
		{
			x = convertWXtoGX( (double)i ) + 2;
			y = convertWYtoGY( data[i] );
			g.fillRect( x, y, barWidth, height - y );
		}
		
		previousHighlightIndex = -1;	
	}
}
