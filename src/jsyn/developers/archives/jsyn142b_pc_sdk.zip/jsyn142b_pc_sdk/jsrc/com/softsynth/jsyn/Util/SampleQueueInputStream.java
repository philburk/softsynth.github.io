
package com.softsynth.jsyn.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** 
 * Adds streaming read capabilities to a SynthSampleQueue.
 * The queue must be on a unit that will write data to the queue
 * such as a SampleWriter_16F1. The SampleWriter will write data to the sample that is then
 * read by this stream via the queue.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see StreamRecorder
 */
public class SampleQueueInputStream extends SampleQueueStream
{
	
	public SampleQueueInputStream( SynthSampleQueue queue, int bufferSizeInFrames, int channelsPerFrame )
	{
		super( queue,  bufferSizeInFrames, channelsPerFrame );
	}
	
	public void start( int time )
	{
		super.start( time );
	// Queue entire sample because it is empty
	// and so that we will have something to read later.
		queue.clear( time );
		queue.queue( time, sample );
	}
	
/** Return true if the buffer has overflowed and data has been lost.
 * To prevent this, use a larger buffer, or read the data more often.
 */
	public boolean getOverflowed()
	{
		available();
		return flowError;
	}
	
/** Read an array of short data from sample.
* If there is not enough data available, block until all of the data can be read.
* To avoid blocking, call available() first to see how much can be read without blocking.
* @param data Array of shorts containing PCM sample data
* @param offset index of array to start reading data from
* @param numFrames number of frames to read from sample
* @return number of frames read
*/
	public int read( short data[], int offset, int numFrames )
	{
		return move( data, offset, numFrames );
	}

	
/** Return the number of frames when this stream has been drained.
 */
	int getNumWhenSatisfied()
	{
		return 0;
	}

	void moveDirect( int moveIndex, short data[], int offset, int numFrames )
	{ 
		sample.read( moveIndex, data, offset, numFrames );
	}
	
}
