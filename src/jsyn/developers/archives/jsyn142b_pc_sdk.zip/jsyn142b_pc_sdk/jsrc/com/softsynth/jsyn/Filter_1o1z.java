package com.softsynth.jsyn;
import java.util.*;

/**
 *	Filter_1o1z unit.
 First Order, One Zero filter. <P>
First Order, One Zero filter using the following formula: <P>
     y(n) = A0*x(n) + A1*x(n-1)<P>

where y(n) is Output, x(n) is Input and x(n-1) is Input at the prior sample tick.
<P>
Setting A1 positive gives a low-pass response; setting A1 negative gives a high-pass response. The bandwidth of
this filter is fairly high, so it often serves a building block by being cascaded with other filters.
<P>
If A0 and A1 are both 0.5, then this filter is a simple averaging lowpass filter, with a zero at SR/2 = 22050 Hz.
<P>
If A0 is 0.5 and A1 is -0.5, then this filter is a high pass filter, with a zero at 0.0 Hz.
<P>
A thorough description of the digital filter theory needed to fully describe this filter is beyond the scope of this
document.
Calculating coefficients is non-intuitive; the interested user is referred to one of the standard texts on filter theory
(e.g., Moore, "Elements of Computer Music", section 2.4).

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 * @see Filter_1o1p
 * @see StateVariableFilter
*/

public class Filter_1o1z extends SynthFilter
{
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.5. */
	public SynthInput A0;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.5. */
	public SynthInput A1;

 	public Filter_1o1z( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Filter_1o1z", calculationRate, 0 );
		A0 = new SynthInput( this, "A0" );
		A1 = new SynthInput( this, "A1" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public Filter_1o1z( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public Filter_1o1z( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
