package com.softsynth.jsyn;
import java.util.*;

/**
 *	SawtoothOscillator unit.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SawtoothOscillator extends SynthOscillator 
{
 	public SawtoothOscillator( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Osc_Sawtooth", calculationRate, 0 );
	}
/**
 *	Create a SawtoothOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SawtoothOscillator( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SawtoothOscillator( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
