package com.softsynth.view;

/**
 * Interface for CustomFaderDouble, etc.
 * 
@author Phil Burk, SoftSynth.com, All Rights Reserved
*/
public interface ValueController
{
	
	public void addValueListener( ValueListener listener );
	
	public void removeValueListener( ValueListener listener );
	
	public void setValue(double v);
	
	public double getDoubleValue();
/** Set maximum for value.
 */
	public void setMaximum( double maximum );
/** Get maximum value.
 */
	public double getMaximum();
/** Set minimum for value.
 */
	public void setMinimum( double minimum );
/** Get minimum value.
 */
	public double getMinimum();
}
