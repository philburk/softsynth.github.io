package com.softsynth.jsyn.view102;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/**
 * Panel with insets that can be used to border a centered component.
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class InsetPanel extends Panel
{
	int          border;  /* Pixels in border. */
	static final int default_border = 6;
	
	public InsetPanel( Component borderMe )
	{
		this( borderMe, Color.blue, default_border );
	}
	public InsetPanel( Component borderMe, Color borderColor )
	{
		this( borderMe, borderColor, default_border );
	}
	public InsetPanel( Component borderMe, int border )
	{
		this( borderMe, Color.blue, border );
	}
	
/** 
 * @param borderMe component to be centerred in this panel. Typically another Panel, or null.
 * @param borderColor color to paint the border.
 * @param border width in pixels of border.
 */
	public InsetPanel( Component borderMe, Color borderColor, int border )
	{
		this.border = border;
		setLayout( new BorderLayout() );
/* Force a background for the component so the border shows up. */
		if( borderMe != null )
		{
			add("Center", borderMe );
			if( borderMe.getBackground() == null ) borderMe.setBackground( Color.white );
		}
		if( borderColor != null ) setBackground( borderColor );
	}
	
	public Insets insets()
	{
		return new Insets( border, border, border, border );
	}
	
/** @param border width in pixels of border. */
	public void setBorder( int borderWidth )
	{
		border = borderWidth;
		repaint();
	}
	public int getBorder( )
	{
		return border;
	}
}
