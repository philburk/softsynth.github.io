package com.softsynth.math;

/** 
 * ChebyshevPolynomial<br>
 * Used to generate data for waveshaping table oscillators.
 * @author Nick Didkovsky (C) 1997 Phil Burk and Nick Didkovsky, All Rights Reserved
 */

public class ChebyshevPolynomial
{
	static final Polynomial twoX = new Polynomial(2, 0);
	static final Polynomial one = new Polynomial(1);
	static final Polynomial oneX = new Polynomial(1, 0);
	
/** Calculates Chebyshev polynomial of specified integer order.  Recursively generated using relation Tk+1(x) = 2xTk(x) - Tk-1(x)
 @return Chebyshev polynomial of specified order */
	public static Polynomial T(int order) {
		if (order == 0) 
			return one;
		else 
			if (order == 1) 
				return oneX;
			else 
				return Polynomial.minus(Polynomial.mult(T(order-1), (twoX)), T(order-2));		
	}
}
