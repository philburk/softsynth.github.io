package com.softsynth.jsyn.view102;
/**
 * Tweakable Interface
 * Used with LabelledFader and other editing components.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see LabelledFader
 */

public interface Tweakable
{
	void tweak( int index, double val );
}
