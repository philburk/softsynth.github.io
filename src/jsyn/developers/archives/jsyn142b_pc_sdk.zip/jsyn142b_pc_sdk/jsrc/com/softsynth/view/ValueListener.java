package com.softsynth.view;

/** Interface to get values back from a DoubleController, eg. RotaryKnob.  Any class
 * that uses a DoubleController will be notified of its value being changed 
 * by implementing this interface. <br>
 * @author Nick Didkovsky and Phil Burk
*/
public interface ValueListener
{
  /** Handle a value change.
   */
  	public void valueChanged( ValueEvent e );
}

