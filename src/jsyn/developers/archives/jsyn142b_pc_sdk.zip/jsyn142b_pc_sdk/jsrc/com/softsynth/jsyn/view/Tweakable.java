/**
 * Tweakable Interface
 * Used with LabelledFader and other editing components.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;

public interface Tweakable
{
	void tweak( int index, double val );
}
