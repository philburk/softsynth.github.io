package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;

/**
 * Display a generic message and ask for a response.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class MessageDialog extends Dialog
{
	TextArea textArea;
	Button   button0;
	Button   button1;
	Button   button2;
	int      response;
	
/** Create a dialog that will display the message in a textArea.
 */
	public MessageDialog( int numLines, int numColumns, String buttonText0, String buttonText1, String buttonText2 )
	{
		super( new Frame(), "MessageDialog", true );
		setLayout( new BorderLayout() );
		resize( 600, 300 );
		textArea = new TextArea( "", numLines, numColumns );
		add( "Center", textArea );
		Panel panel = new Panel();
		add( "South", panel );
		panel.add( button0 = new Button(buttonText0) );
		if( buttonText1 != null ) panel.add( button1 = new Button(buttonText1) );
		if( buttonText2 != null ) panel.add( button2 = new Button(buttonText2) );
	}
	
/** Set the default size to 6x80 and setText().
 */
	public MessageDialog( String text, String buttonText0, String buttonText1, String buttonText2 )
	{
		this( 6, 80, buttonText0, buttonText1, buttonText2 );
		setText( text );
	}
	
/** Change message to be displayed.
 */
	void setText( String text )
	{
		textArea.setText( text );
	}
	
	public MessageDialog( String message, String buttonText0, String buttonText1 )
	{
		this( message, buttonText0, buttonText1, null );
	}
	public MessageDialog( String message, String buttonText0 )
	{
		this( message, buttonText0, null, null );
	}
	
/** Show the dialog and return 0,1 or 2 depending on which button was pressed.
 */
	public int ask()
	{
		response = -1;
		show();
		return response;
	}

	public boolean action(Event evt, Object arg)
	{
		if( evt.target == button0 )
		{
			response = 0;
			dispose();
			return true;
		}
		else if( evt.target == button1 )
		{
			response = 1;
			dispose();
			return true;
		}
		else if( evt.target == button2 )
		{
			response = 2;
			dispose();
			return true;
		}

		return false;
	}

}