package com.softsynth.jsyn;
import java.util.*;

/**
 *	MultiplyUnit.
 * Multiply two signals together.
 * Can be used to control the amplitude of a signal.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see MultiplyAddUnit
 * @see MultiplyUnsignedUnit
 */

public class MultiplyUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public MultiplyUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_Multiply", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public MultiplyUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public MultiplyUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
