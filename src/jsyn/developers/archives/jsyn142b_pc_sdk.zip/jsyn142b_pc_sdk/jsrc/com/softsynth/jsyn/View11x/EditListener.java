package com.softsynth.jsyn.view11x;

/* Interface for listener for EnvelopeEditor and other editors.
 *
 * @author Phil Burk (C) Copyright 1997 - All Rights Reserved
 */

public interface EditListener
{
	public void objectEdited( Object editor, Object edited );
}
