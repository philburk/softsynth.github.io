
package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Filtered WhiteNoise amplitude modulated by a LinearLag
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class LagFilteredNoise extends SynthNote
{
	WhiteNoise   myNoise;
	StateVariableFilter myFilter;
	LinearLag  ampLag;
	LinearLag  freqLag;
	
/* Declare port. */
	public SynthVariable amplitudeTarget;
	public SynthVariable frequency;
	public SynthVariable amplitudeTime;
	public SynthVariable frequencyTime;
	public SynthVariable resonance;

/*
 * Setup synthesis.
 */
	public LagFilteredNoise()  throws SynthException
	{
/* Create various unit generators and add them to circuit. */
		add( myNoise = new WhiteNoise() );
		add( myFilter = new StateVariableFilter() );
		add( ampLag = new LinearLag() );
		add( freqLag = new LinearLag() );

/* Connect SynthUnits to make control signal path. */
		freqLag.output.connect( myFilter.frequency );
		ampLag.output.connect( myFilter.amplitude );
		myNoise.output.connect( myFilter.input );
		myNoise.amplitude.set( 0.3 );

/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( frequency = freqLag.input, "targetFrequency" );
		addPort( amplitude = myNoise.amplitude );
		addPort( output = myFilter.output );
		
		addPort( resonance = myFilter.resonance );
		addPort( amplitudeTarget = ampLag.input, "targetAmplitude" );
		addPort( amplitudeTime = ampLag.time, "amplitudeTime" );
		addPort( frequencyTime = freqLag.time, "frequencyTime" );
		
		freqLag.input.setSignalType( Synth.SIGNAL_TYPE_SVF_FREQ );
	}
	
/* Define a behavior for setStage() */
	public void setStage( int time, int stage )
	throws SynthException
	{
		if( stage == 0 )
		{
			start( time );
		}
		else
		{
			stop( time );
		}
	}
}

