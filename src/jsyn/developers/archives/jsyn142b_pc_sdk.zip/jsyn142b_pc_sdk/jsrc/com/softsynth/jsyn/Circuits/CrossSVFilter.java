package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Cross Coupled State Variable Filters
 *
 *   Each filter frequency modulates the other.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class CrossSVFilter extends SynthNote
{
	WhiteNoise          myNoise;
	StateVariableFilter myFilter1;
	StateVariableFilter myFilter2;
	MultiplyUnit        myModIndex;
	MultiplyAddUnit     myCtlMix1;
	MultiplyAddUnit     myCtlMix2;
	
/* Declare port. */
	public SynthInput         noiseAmp;
	public SynthInput         modIndex;
	public SynthDistributor   resonance;
	public SynthDistributor   modDepth;

/*
 * Setup synthesis.
 */
	public CrossSVFilter()  throws SynthException
	{
		super();

/* Create various unit generators and add them to circuit. */
		add( myNoise = new WhiteNoise() );
		add( myFilter1 = new StateVariableFilter() );
		add( myFilter2 = new StateVariableFilter() );
		add( myModIndex = new MultiplyUnit() );
		add( myCtlMix1 = new MultiplyAddUnit() );
		add( myCtlMix2 = new MultiplyAddUnit() );
		
/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( noiseAmp = myNoise.amplitude, "noiseAmp" );
		addPort( modIndex = myModIndex.inputB, "modIndex" );
		addPort( amplitude = myFilter1.amplitude );
		addPort( output = myFilter1.output );

/* Create SynthDistributors for signals which fan-out inside circuit. */
		frequency = new SynthDistributor( this, "frequency", Synth.SIGNAL_TYPE_SVF_FREQ  );
		modDepth = new SynthDistributor( this, "modDepth", Synth.SIGNAL_TYPE_SVF_FREQ );
		resonance = new SynthDistributor( this, "resonance" );

/* Distributed connections. */
		modDepth.connect( myCtlMix1.inputB );
		modDepth.connect( myCtlMix2.inputB );
		frequency.connect( myCtlMix1.inputC );
		frequency.connect( myModIndex.inputA );
		resonance.connect( myFilter1.resonance );
		resonance.connect( myFilter2.resonance );
/* Connect SynthUnits. */
		myNoise.output.connect( myFilter1.input );
		myNoise.output.connect( myFilter2.input );
/* cross connect 1-2, 2-1 */
		myFilter1.lowPass.connect( myCtlMix2.inputA );
		myFilter2.lowPass.connect( myCtlMix1.inputA );
		myModIndex.output.connect( myCtlMix2.inputC );
		myCtlMix1.output.connect( myFilter1.frequency );
		myCtlMix2.output.connect( myFilter2.frequency );

/* Set ports (min, initial, max). */
		noiseAmp.setup( 0.0, 0.1, 0.8 );
		modIndex.setup( 0.0, 0.6, 1.0 );
		amplitude.setup( 0.0, 0.5, 1.0 );
		frequency.setup( 0.0, 700.0, 1000.0 );
		modDepth.setup( 0.0, 8000.0, 10000.0 );
		resonance.setup( 0.0, 0.05, 0.3 );
	}
	
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0:
			stop( time );
			start( time );
			break;
		}
	}
}

