/**
 * Display percent CPU utilization.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;
import java.util.*;
import java.awt.*;
import java.applet.*;
import com.softsynth.jsyn.*;

public class UsageDisplay extends Panel
{
	Button  updateButton;
	Label   usageLabel;

	public UsageDisplay()
	{
		add( updateButton = new Button( "Usage" ) );
		add( usageLabel = new Label( "????" ) );
	}

	public boolean action(Event evt, Object what)
	{
//		try
//		{
			if( evt.target == updateButton )
			{
				double usage = Synth.getUsage();
				int percent = (int) (usage * 100.0); /* Chop trailing digits. */
				usageLabel.setText( Integer.toString(percent) + "%");
				return true;
			}
//		} catch (SynthException e) {
//			SynthAlert.showError(this,e);
//			return true;
//		}
		return false;
    }
}

