package com.softsynth.jsyn.view102;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/**
 * Edit an array of double values using a bar-graph style display.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class BarGraphEditor extends InternalBarGraphEditor
{
	public BarGraphEditor( double data[] )
	{
		super( data );
	}
	
/* Respond to 1.0.2 style AWT mouse actions. */
	public boolean mouseDown( Event evt, int x, int y )
	{
		convertMouse( evt.shiftDown(), x, y );
		return true;
	}
	public boolean mouseDrag( Event evt, int x, int y )
	{
		convertMouse( evt.shiftDown(), x, y );
		return true;
	}
	public boolean mouseUp( Event evt, int x, int y )
	{
		return true;
	}

}
