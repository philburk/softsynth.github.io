package com.softsynth.jsyn;
import java.util.*;

/**
 *	This unit performs a signed addition on its two inputs.
 <br><pre>
 output = inputA + inputB
 </pre><br>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see MultiplyAddUnit
 * @see SubtractUnit
 * @see DivideUnit
 */

public class AddUnit extends SynthUnit
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public AddUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_Add", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public AddUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public AddUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
