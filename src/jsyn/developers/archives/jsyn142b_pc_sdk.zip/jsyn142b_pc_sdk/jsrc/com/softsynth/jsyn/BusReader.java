package com.softsynth.jsyn;
import java.util.*;

/**
 * BusReader unit.
 * This unit can be used to mix multiple signals together.
 * It has a SynthBusInput that can be connected to multiple
 * SynthBusOutputs.  All the inputs are summed and then passed to the
 * output port.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 * @see BusReader
 * @see SynthMixer
 */

public class BusReader extends SynthUnit 
{
	public SynthBusInput busInput;
	public SynthInput amplitude;
	public SynthOutput output;

 	public BusReader( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Bus_Read", calculationRate, 0 );
		busInput = new SynthBusInput( this, "BusInput" );
		amplitude = new SynthInput( this, "Amplitude" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
 	public BusReader( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public BusReader( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
