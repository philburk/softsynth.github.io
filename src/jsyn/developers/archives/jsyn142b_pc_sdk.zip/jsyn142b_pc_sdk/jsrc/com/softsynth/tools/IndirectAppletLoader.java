/**
 * This Applet class will load and run another Applet only if another class exists.
 * This can be used to check for the existence of a plugin before running an Applet.
 * An error message can then be displayed instead of just crashing silently.
 * <P>
 * To use this in a web page, use the APPLET tag to launch the
 * "com.softsynth.tools.IndirectAppletLoader.class".<BR>
 * Then pass parameters to the Applet using the \<PARAM\> tag.
 * The recognized parameters are:<BR>
 * <PRE>
 *     NAME       VALUE
 *     other     name of other Applet to run, for example "mystuff.MyApplet"
 *     testfor   name of class to test for, default is "com.softsynth.jsyn.Synth"
 *     message   message to display if test for not found
 * </PRE>
 * 
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package com.softsynth.tools;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class IndirectAppletLoader extends Applet
{
	String       testClassName = null;
	final static String DEFAULT_TEST_CLASS = "com.softsynth.jsyn.Synth";
	boolean      testClassPresent = false;	
	String       otherAppletName = null;
	Applet       otherApplet = null;
	IndirectApplet indirectApplet = null;
	String       testFailedMessage;
	final static String DEFAULT_MESSAGE = "Could not load Applet because JSyn plugin not installed!";

/* Can be run as either an application or as an applet. */
	public static void main(String args[])
	{
		IndirectAppletLoader applet = new IndirectAppletLoader();
		Frame f = new Frame("Applet Frame");
		f.add("Center", applet);
		f.setSize(600,350);
		f.show();
		applet.testClassName = args[0];
		applet.otherAppletName = args[1];
		applet.testFailedMessage = args[2];
		applet.init();
		applet.start();
	}
	
	void reportMessage( String message )
	{
		MessageReporter mr = new MessageReporter( (Frame) getParent(), message );
		mr.show();
	}
	
	public String[][] getParameterInfo()
	{
		String pinfo[][] = {
                   {"other",   "applet", "name of other Applet to run"},
                   {"testfor", "class",  "name of class to test for"},
                   {"message", "string", "message to display if testfor not found"}
           };
		return pinfo;
	}
	
	public String getAppletInfo()
	{
		return "IndirectAppletLoader - (C) 2000, Phil Burk and SoftSynth.com";
	}

	void debug( String message )
	{
		System.out.println("IndirectAppletLoader: " + message);
	}
	public void init()
	{		
/* If a name was not passed on the command line, look for an Applet parameter. */
		if( otherAppletName == null )
		{
			otherAppletName = getParameter("other");
			if( otherAppletName == null )
			{
				reportMessage("Other Applet not specified!");
				return;
			}
		}
		debug("otherAppletName = " + otherAppletName);
		
		if( testClassName == null )
		{
			testClassName = getParameter("testfor");
			if( testClassName == null )
			{
				testClassName = DEFAULT_TEST_CLASS;
			}
		}
		debug("testClassName = " + testClassName);
		
		if( testFailedMessage == null )
		{
			testFailedMessage = getParameter("message");
			if( testFailedMessage == null )
			{
				testFailedMessage = DEFAULT_MESSAGE;
			}
		}
		debug("testFailedMessage = " + testFailedMessage);
		
		try
		{
			Class cl = Class.forName( testClassName );
			testClassPresent = true;
		} catch (Exception e) {
			reportMessage(testFailedMessage);
			return;
		} catch (Error e) {
			reportMessage(testFailedMessage);
			return;
		}
		debug("loaded test class.");
		
		try
		{
			Class cl = Class.forName( otherAppletName );
			Object obj = cl.newInstance();
			if( obj instanceof IndirectApplet) indirectApplet = (IndirectApplet) obj;
			else if( obj instanceof Applet) otherApplet = (Applet) obj;
		} catch (Exception e) {
			reportMessage("Failed to load Applet. Error = " + e );
			return;
		} catch (Error e) {
			reportMessage("Failed to load Applet. Error = " + e );
			return;
		}
		debug("loaded applet class.");
		
		setLayout( new BorderLayout() );
		if( indirectApplet != null )
		{
			indirectApplet.setApplet( this );
			add( "Center", indirectApplet );
			indirectApplet.init();
		}
		else if( otherApplet != null )
		{
			add( "Center", otherApplet );
			otherApplet.init();
		}
	}
	
	public void start()
	{
		if( indirectApplet != null )
		{
			indirectApplet.start();
		}
		else if( otherApplet != null )
		{
			otherApplet.start();
		}
	}
	public void stop()
	{
		if( indirectApplet != null )
		{
			indirectApplet.stop();
		}
		else if( otherApplet != null )
		{
			otherApplet.stop();
		}
	}
	public void destroy()
	{
		if( indirectApplet != null )
		{
			indirectApplet.destroy();
		}
		else if( otherApplet != null )
		{
			otherApplet.destroy();
		}
	}
	
public class MessageReporter extends Dialog
{
	TextArea textArea;
	Button   okButton;
	
	public MessageReporter(  Frame frame, String message )
	{
		super( frame, "IndirectAppletLoader report", true );
		setLayout( new BorderLayout() );
		setSize( 620, 200 );
		textArea = new TextArea( "", 6, 80, TextArea.SCROLLBARS_BOTH  );
		add( "Center", textArea );
		
		Panel panel = new Panel();
		add( "South", panel );
		
		panel.add( okButton = new Button("Acknowledge") );
		okButton.addActionListener(	new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				hide();
			} } );
		
		textArea.setText( message );
		validate();
	}

}
}

