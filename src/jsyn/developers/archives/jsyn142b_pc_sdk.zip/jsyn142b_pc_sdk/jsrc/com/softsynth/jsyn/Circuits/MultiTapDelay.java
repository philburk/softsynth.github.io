package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/*
 * MultiTapDelay
 * Can be used for modelling early reflections for reverberation.
 * Define a circuit that creates a long echo with multiple taps.
 * In this circuit, a signal is written to a sample,
 * and then read back at a later time.
 * Feedback with an averaging low pass filter is built in.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class MultiTapDelay extends SynthCircuit
{
	SynthSample       delayLine;
	SampleReader_16F1 unitReaders[];
	BusWriter         busWriters[];
	BusReader         busReader;
	SampleWriter_16F1 unitWriter;
	Filter_1o1z       averager;
	MultiplyAddUnit   feedbackMixer;

	int               numSamples;
	int               numTaps;
	
	public SynthInput  input;
/** Determines the amount of low pass filtered output that is fed back into the input.
 * This can cause the sound to decay more slowly. Feedback may cause clipping if
 * set too high. Ranges from -1.0 to 1.0.
 */
	public SynthInput  feedback;
	public SynthOutput output;

	double findLargestDouble( double vals[] )
	{
		double largest = vals[0];
		for( int i=1; i<vals.length; i++ )
		{
			if( largest < vals[i] ) largest = vals[i];
		}
		return largest;
	}

/**
 * Multitap delays are constructed by passing an array of delay times and gains.
 * A tap will be built for each element of the delay array.
 * The taps amplitude will be set to the valus in the gain array.
 * For example, to set up a delay with 5 taps:
 <P>
 <PRE>
		double[] delays = { 0.457, 0.719, 0.901, 1.0, 1.17 };
		double[] gains = {0.1, -0.3, -0.2, 0.1, 0.3};
		myReverb = new MultiTapDelay( delays, gains );
</PRE>
 * When sound reflects off of a wall, the waveforms are inverted.
 * So you can think of taps with negative gains as signals that have reflected
 * an odd number of times.
 * <P>
 * In order to prevent a DC (zero frequency) offset from building up in the circuit,
 * the gains should add up to zero.
 * <P>
 * In order to prevent clipping, the absolute value of the gains should add up
 * to a number less than 1.0.
 */
	public MultiTapDelay( double tapDelays[], double tapGains[] )  throws SynthException
	{
/* Call SynthSound constructor to make room for subUnits. */
		super();

		numTaps = tapDelays.length;

		double delayTime = findLargestDouble( tapDelays ) + 0.01;

/* Calculate how many sample correspond to a given delay time. */
		numSamples = (int) (delayTime * Synth.getFrameRate());

/* Create an empty sample. */
		delayLine = new SynthSample( numSamples );

/* Create synthesis units. */
		add( unitWriter = new SampleWriter_16F1() );
		add( feedbackMixer = new MultiplyAddUnit() );
		add( busReader = new BusReader() );
		add( averager = new Filter_1o1z() );

		unitReaders = new SampleReader_16F1[ numTaps ];
		busWriters = new BusWriter[ numTaps ];

		for( int i=0; i<tapDelays.length; i++ )
		{
			add( unitReaders[i] = new SampleReader_16F1() );
			add( busWriters[i] = new BusWriter() );
			unitReaders[i].output.connect( busWriters[i].input );
			unitReaders[i].amplitude.set( tapGains[i] );
			busWriters[i].busOutput.connect( busReader.busInput );

			int frameDelay = (int) (tapDelays[i] * Synth.getFrameRate());
			unitReaders[i].samplePort.queue( delayLine, numSamples - frameDelay, frameDelay );
			unitReaders[i].samplePort.queueLoop( delayLine, 0, numSamples );
		}

		unitWriter.samplePort.queueLoop( delayLine, 0, numSamples );

		busReader.output.connect( averager.input );
		averager.output.connect( feedbackMixer.inputA );
		feedbackMixer.output.connect( unitWriter.input );

/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( input = feedbackMixer.inputC, "input" );
		addPort( feedback = feedbackMixer.inputB, "feedback" );
		addPort( output = busReader.output );
	}
}

