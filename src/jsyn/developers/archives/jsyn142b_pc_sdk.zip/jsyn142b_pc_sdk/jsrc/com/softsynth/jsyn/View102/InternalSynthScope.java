package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import java.applet.*;
import com.softsynth.jsyn.*;

/**
 * Oscilloscope
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see TJ_SeeOsc
 */

public class InternalSynthScope  extends Panel implements Runnable
{

	SynthProbeCircuit  probeCircuit; /* Put all probes in circuit for synchronized start. */
	WaveDisplay      waveDisplay;
	protected Button captureButton;
	protected Checkbox autoBox;
	protected Button zoomInButton;
	protected Button zoomOutButton;
	protected Button panLeftButton;
	protected Button panRightButton;
	Panel            probeGroup;
	Panel            controlPanel;
	Thread           autoThread;
	boolean          runAuto = false;
	int              sampleSize;
	boolean          autoEnable;
	SynthContext     synthContext;
	
	public InternalSynthScope( SynthContext synthContext, int sampleSize )
	{
		this.sampleSize = sampleSize;
		this.synthContext = synthContext;

/* Use GridBagLayout to get reasonable sized components. */
        GridBagLayout  gridbag  =  new  GridBagLayout();
        GridBagConstraints  constraint  =  new  GridBagConstraints();
        setLayout(gridbag);
        constraint.gridwidth  =  GridBagConstraints.REMAINDER; 
        constraint.fill  =  GridBagConstraints.BOTH;
        constraint.weightx  =  1.0;

		add( waveDisplay = new WaveDisplay() );
		waveDisplay.setBackground( Color.black );

/* Make waveDisplay fill available vertical space for scope. */
        constraint.gridheight  = GridBagConstraints.RELATIVE;  
        constraint.weighty  =  1.0;
		gridbag.setConstraints(waveDisplay,  constraint);
        constraint.weighty  =  0.0;

		add( probeGroup = new Panel() );

        constraint.gridheight  =  GridBagConstraints.REMAINDER;  
		gridbag.setConstraints(probeGroup,  constraint);

		probeGroup.setLayout( new GridLayout(0,1) );
		probeGroup.add( controlPanel = new Panel() );
		controlPanel.add( captureButton = new Button("Capture") );
		controlPanel.add( autoBox = new Checkbox("Auto") );
/* Auto feature should start OFF to prevent race between circuit
 * compilation and adding more probes. */
		autoBox.setState(false);
		controlPanel.add( zoomInButton = new Button("Zoom In") );
		controlPanel.add( zoomOutButton = new Button("Zoom Out") );
		controlPanel.add( panLeftButton = new Button("<<<") );
		controlPanel.add( panRightButton = new Button(">>>") );
		controlPanel.add( new UsageDisplay(synthContext) );

		probeCircuit = new SynthProbeCircuit( synthContext, sampleSize );
	}
	
/** Call this after your last call to createProbe().
 * This will compile the scopes circuit and enable the auto capture feature.
 */
	public void finish()
	{
/* This method is part of a fix for a race condition where probes were added
 * after the scope was compiled by the autoThread.
 */
		probeCircuit.compile();
		autoBox.setState(true);
		autoBox.repaint();
		handleAutoBox();
	}

	public void run()
	{
		while(true)
		{
			try
			{
				if( autoEnable ) capture();
				Thread.sleep( 1000 );
			}
			catch( InterruptedException e )
			{
				return;
			}
			catch( SynthException e )
			{
			//	System.out.println("SynthScope caught " + e );
				return;
			}
		}
	}

/**
 *	Display a panel for this probe on the scope. 
 *
 * @exception SynthException   If an error occurs.
 */
	public void addProbe( SynthScopeProbePanel probePanel )
	throws SynthException
	{
		probePanel.useDisplay( waveDisplay );
		probeGroup.add( probePanel );
		repaint();
	}
/**
 *	Remove the probe from the scope. 
 *
 * @exception SynthException	 If an error occurs.
 */
	public void removeProbe( SynthScopeProbePanel probePanel )
	throws SynthException
	{

		probePanel.useDisplay( null );
		probeGroup.remove( probePanel );
		repaint();
	}

/**
 *	Conveniance call that creates a SynthProbe and adds it to scope.
 * After the last call to createProbe(), you should call finish().
 */
	public SynthScopeProbePanel createProbe( SynthOutput outPort, int partNum, String name, Color color )
	{
		SynthProbe probe = probeCircuit.addProbe( outPort, partNum );
	// System.out.println("createProbe(" + outPort + ", " + name + ")");
		WaveTrace  trace = new WaveTrace( probe.data, color, 1.0 );
		SynthScopeProbePanel probePanel = new SynthScopeProbePanel( trace, name );
		addProbe( probePanel );
		return probePanel;
	}
	public SynthScopeProbePanel createProbe( SynthOutput outPort, String name, Color color )
	{
		return createProbe( outPort, 0, name, color );
	}

/**
 * Acquire fresh data then update the display.
 */
	public synchronized void capture()
	{
		probeCircuit.trigger();
		synthContext.sleepForTicks( (sampleSize / synthContext.getFramesPerTick()) + 1 ); /* FIXME - use sample completion notification when implemented. */
		probeCircuit.readData();
		waveDisplay.repaint();
	}

/* Process autoBox event which controls periodic capture thread. */
	protected void handleAutoBox()
	{
		if (autoBox.getState())
		{
			autoEnable = true;
			if( autoThread ==  null)
			{
				autoThread = new Thread( this );
				autoThread.start();
			}
		}
		else
		{
			autoEnable = false;
		}
	}

	protected boolean handleButtonAction( Component source )
	{
		if( source == captureButton )
		{
			capture();
			return true;
		}
		else if( source == autoBox )
		{
			handleAutoBox();
			return true;
		}
		else if( source == zoomInButton )
		{
			waveDisplay.zoomIn();
			waveDisplay.repaint();
			return true;
		}
		else if( source == zoomOutButton )
		{
			waveDisplay.zoomOut();
			waveDisplay.repaint();
			return true;
		}
		else if( source == panLeftButton )
		{
			waveDisplay.panLeft();
			waveDisplay.repaint();
			return true;
		}
		else if( source == panRightButton )
		{
			waveDisplay.panRight();
			waveDisplay.repaint();
			return true;
		}
		return false;
	}
}

class SynthProbe extends SampleWriter_16F1
{
	SynthSample         mySamp;
	public short[]      data;

	public SynthProbe( SynthContext synthContext, SynthOutput outPort, int partNum, int size ) throws SynthException
	{
		super(synthContext);
		data = new short[ size ];
		outPort.connect( partNum, input, 0 );
		mySamp = new SynthSample( synthContext, size, 1 );
	}
	
	void trigger() throws SynthException
	{
		samplePort.clear();
		samplePort.queue( mySamp, 0, mySamp.getNumFrames(), Synth.FLAG_AUTO_STOP );
	}

	void readData()  throws SynthException
	{
		mySamp.read( 0, data, 0, mySamp.getNumFrames() );
	}
}

class SynthProbeCircuit  extends SynthCircuit
{
	Vector       probes;
	int          sampleSize;

/* Create a circuit with N probes that can be started in sync. */
	public SynthProbeCircuit( SynthContext synthContext, int sampleSize ) throws SynthException
	{
		super( synthContext );
		probes = new Vector();
		this.sampleSize = sampleSize;
	}

	public SynthProbe addProbe( SynthOutput outPort, int partNum )  throws SynthException
	{
		SynthProbe probe = new SynthProbe( getSynthContext(), outPort, partNum, sampleSize );
		probes.addElement( probe );
		add( probe );
		return probe;
	}

	void trigger() throws SynthException
	{
		stop();
		for( int j=0; j<probes.size(); j++)
		{
			SynthProbe probe = (SynthProbe) probes.elementAt(j);
			probe.trigger();
		}
		start();
	}
	void readData() throws SynthException
	{
		for( int j=0; j<probes.size(); j++)
		{
			SynthProbe probe = (SynthProbe) probes.elementAt(j);
			probe.readData();
		}
	}

}

class SynthScopeProbePanel extends Panel
{
	Button           VSupButton;
	Button           VSdownButton;
	Checkbox         showButton;
	WaveDisplay      display;
	Label            label;
	Label            scaleLabel;
	WaveTrace        trace;

	public SynthScopeProbePanel( WaveTrace trace, String name ) throws SynthException
	{
		this.trace = trace;

		setLayout( new GridLayout( 1,3 ) );

		add( label = new Label( name ) );

		Panel midPanel = new Panel();
		midPanel.add( showButton = new Checkbox("Show") );
		midPanel.add( VSupButton = new Button("V*2") );
		midPanel.add( VSdownButton = new Button("V/2") );
		add( midPanel );

		add( scaleLabel = new Label( "1.0" ) );
		label.setForeground( trace.color );
		label.setBackground( Color.black );

		showButton.setState( true );
	}

	public void setLabel( String name )
	{
		label.setText( name );
		repaint();
	}

	void useDisplay( WaveDisplay display )
	{
		if( display == null )
		{
			this.display.removeTrace( trace );
		}
		else
		{
			display.addTrace( trace );
		}
		this.display = display;
	}

	public void setColor( Color color )
	{
		trace.color = color;
		label.setForeground( color );
	}
	public Color getColor( )
	{
		return trace.color;
	}
	
	public boolean action(Event evt, Object what)
	{
		if( evt.target == VSupButton )
		{
			trace.scaleFactor = 2.0 * trace.scaleFactor;
			display.repaint();
			scaleLabel.setText( Double.toString( trace.scaleFactor ) );
			repaint();
			return true;
		}
		else if( evt.target == VSdownButton )
		{
			trace.scaleFactor = 0.5 * trace.scaleFactor;
			display.repaint();
			scaleLabel.setText( Double.toString( trace.scaleFactor ) );
			repaint();
			return true;
		}
		else if( evt.target == showButton )
		{
			if( showButton.getState() )
			{
				display.addTrace( trace );
			}
			else
			{
				display.removeTrace( trace );
			}
			display.repaint();
			return true;
		}
		return false;
    }

}


