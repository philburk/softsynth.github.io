package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthTablePort is used for attaching a SynthTable to a unit generator that
 * uses tables.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see SynthTable
 * @see TableOscillator
 */

public class SynthTablePort extends SynthPort
{
	SynthTable    table;
	
	SynthTablePort( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	SynthTablePort( SynthSound sound ) throws SynthException
	{
		super( sound, "Table" );
	}

/**
 * Use this table on this TablePort.
 *
 * @exception SynthException	 If partNumber out of range or table invalid.
 */
	public void setTable( int partNumber, SynthTable table ) throws SynthException
	{
		int tableToken = ( table == null ) ? 0 : table.getPeer();
		int nativeError = Synth.UseTable( sound.context, peerToken, portHash, partNumber, tableToken );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken, tableToken );
		this.table = table;
	}
	public void setTable( SynthTable table ) throws SynthException
	{
		setTable( 0, table );
	}
	
	public SynthTable getTable()
	{
		return table;
	}
	
/** @deprecated useTable() has been replaced by setTable().
 * @exception SynthException	 If partNumber out of range or table invalid.
 * @see #setTable
 */
	public void useTable( int partNumber, SynthTable table ) throws SynthException
	{
		setTable( partNumber, table );
	}
/** @deprecated useTable() has been replaced by setTable().
 * @exception SynthException	 If partNumber out of range or table invalid.
 * @see #setTable
 */
	public void useTable( SynthTable table )
	throws SynthException
	{
		setTable( 0, table );
	}

}
