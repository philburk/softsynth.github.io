package com.softsynth.jsyn;
import java.util.*;

/**
 *	DelayUnit unit.
 <P>
 DelayUnit provides a simple time delay with an input and output.
 The internal data format is the same resolution as a SynthTable which is
 floating point if the sound processor supports it.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 * @see SampleWriter_16F1
 */

public class DelayUnit extends SynthFilter
{
 	public DelayUnit( SynthContext synthContext, int calculationRate, double delayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		super( synthContext, "Delay_Basic", calculationRate, (int) (0.5 + (delayTime * synthContext.getFrameRate())) );
	}
 	public DelayUnit(  int calculationRate, double delayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		this( Synth.getSharedContext(), calculationRate, delayTime );
	}
/**
 *	Create a DelayUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If delayTime negative or exceeds memory.
 */
 	public DelayUnit(  SynthContext synthContext, double delayTime ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO, delayTime );
	}
 	public DelayUnit( double delayTime ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO, delayTime );
	}
}
