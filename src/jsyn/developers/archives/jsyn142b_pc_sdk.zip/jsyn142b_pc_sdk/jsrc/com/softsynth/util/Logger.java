package com.softsynth.util;
import java.io.*;
import java.util.*;

/**
 * Logger logs output to a file if enabled.
 * @author Phil Burk (C) 1999 SoftSynth.com
 */
public class Logger
{
	FileOutputStream  stream = null;
	int               column = 0;
	boolean           enabled;
	String            lineTerminator;
	
	public Logger()
	{
		lineTerminator = System.getProperty( "line.separator", "\n" );
//		System.out.println("lineTerminator.length = " + lineTerminator.length() );
//		for( int i=0; i<lineTerminator.length(); i++ )
//		{
//			System.out.println("lineTerminator[" + i + "] = " + ((int)lineTerminator.charAt(i)) );
//		}	
	}
	
	public void setEnable( boolean enabled )
	{
		this.enabled = enabled;
	}
	public boolean getEnable()
	{
		return enabled;
	}
	
	public void log( String msg )
	{
		if( !enabled ) return;
		
		if( stream == null ) System.out.print( msg );
		else
		{
			try
			{
				stream.write( msg.getBytes() );
			} catch( IOException e )
			{
				TextOutput.error("Log File: " + e);
			}
		}
		column += msg.length();
	}
	
	public void logln( String msg )
	{
		log( msg );
		logln();
	}
	
	public void logln()
	{
		log( lineTerminator );
		column = 0;
	}

/** Output spaces if needed to position output at desired column.
 * Nothing will be output if already past that column.
 */
	public void advanceToColumn( int toColumn )
	{
		if( !enabled ) return;

		try
		{
			for( ; column < toColumn; column++ )
			{
				stream.write( ' ' );
			}
		} catch( IOException e )
		{
			TextOutput.error("Log File: " + e);
		}
	}
/** Start a new line if there is already text on current line.
 */
	public void newLine()
	{
		if( column > 0 ) logln( "" );
	}
	
/** Open a log file.
 */
	public void open( String logFileName ) throws IOException, SecurityException
	{
	// Close any existing log file.
		if( stream != null ) stream.close();
	// Open a new log file.
		stream = new FileOutputStream( logFileName );
		column = 0;
	}
	
	public void close() throws IOException
	{
		if( stream != null ) stream.close();
		stream = null;
	}
}
