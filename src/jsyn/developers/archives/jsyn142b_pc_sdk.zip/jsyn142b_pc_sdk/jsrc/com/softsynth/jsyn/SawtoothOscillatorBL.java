package com.softsynth.jsyn;
import java.util.*;

/**
 *	SawtoothOscillator unit that is bandlimited to prevent aliasing artifacts.
 * This will sound better then SawtoothOscillator, particularly at higher frequencies.
 * It will also take more CPU power to calculate.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 014
 * @see Synth
 * @see SynthChannelData
 */

public class SawtoothOscillatorBL extends SynthOscillator 
{
 	public SawtoothOscillatorBL( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Osc_SawtoothBL", calculationRate, 0 );
	}
/**
 *	Create a SawtoothOscillatorBL that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SawtoothOscillatorBL( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SawtoothOscillatorBL( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
