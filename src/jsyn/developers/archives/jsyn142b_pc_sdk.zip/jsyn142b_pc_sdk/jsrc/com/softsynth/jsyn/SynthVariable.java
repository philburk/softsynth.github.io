package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthVariables are ports that can be set but not connected.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthVariable extends SynthScalarPort
{
	double min, max;
	double lastValue = 0.0;

	static double[] mins;
	static double[] maxs;

	static
	{
		mins = new double[Synth.NUM_SIGNAL_TYPES];
		maxs = new double[Synth.NUM_SIGNAL_TYPES];

		mins[Synth.SIGNAL_TYPE_RAW_SIGNED] = -1.0;
		maxs[Synth.SIGNAL_TYPE_RAW_SIGNED] = 1.0;
		mins[Synth.SIGNAL_TYPE_RAW_UNSIGNED] = 0.0;
		maxs[Synth.SIGNAL_TYPE_RAW_UNSIGNED] = 2.0;
		mins[Synth.SIGNAL_TYPE_OSC_FREQ] = 0.0;
		maxs[Synth.SIGNAL_TYPE_OSC_FREQ] = 10000.0;
		mins[Synth.SIGNAL_TYPE_SAMPLE_RATE] = 0.0;
		maxs[Synth.SIGNAL_TYPE_SAMPLE_RATE] = 88200.0;
		mins[Synth.SIGNAL_TYPE_HALF_LIFE] = 0.001;
		maxs[Synth.SIGNAL_TYPE_HALF_LIFE] = 10.0;
		mins[Synth.SIGNAL_TYPE_TIME] = 0.0;
		maxs[Synth.SIGNAL_TYPE_TIME] = 20.0;
		mins[Synth.SIGNAL_TYPE_SVF_FREQ] = 0.0;
		maxs[Synth.SIGNAL_TYPE_SVF_FREQ] = 10000.0;
		mins[Synth.SIGNAL_TYPE_FULL_RANGE] = -100000.0; // reasonable defaults, can be set bigger
		maxs[Synth.SIGNAL_TYPE_FULL_RANGE] =  100000.0;
	}

	SynthVariable( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
		setMinMaxByType( getSignalType() );
	}

/**
 * Set type for conversion when set() called.
 * @exception SynthException	 If partIndex out of range or illegal signalType.
 */
	public void setSignalType( int signalType, int partIndex )
	throws SynthException
	{
		super.setSignalType( signalType, partIndex );
	}

	void setMinMaxByType( int signalType )
	{
		min = mins[signalType];
		max = maxs[signalType];
	}
	
/** @deprecated Set now has a selector with time as first parameter.
 * @exception SynthException	 If partIndex out of range.
 * @see #set
 */
 	public void setAt( int time, int partIndex, double value )
	throws SynthException
	{
		set(time, value, partIndex );
	}

/** @deprecated Set now has a selector with time as first parameter.
 * @exception SynthException	 If internal error occured.
 * @see #set
 */
	public  void setAt( int time, double value )
	throws SynthException
	{
		set( time, value, 0 );
	}

/**
 *	Set the value of a port that controls the instrument. For example: 
<pre>
        sawtooth.amplitude.set( 0.5 );
        sawtooth.frequency.set( Synth.getCurrentTicks() + 100, 220.0 );
</pre>
 *
 * @param time Time in ticks for setting to occur.
 * @param value Floating point value to set port. Must be in units that
 *              correspond to signal type of port.
 * @param partIndex Index of part of multi-part port. Typically zero.
 * @exception SynthException	 If partIndex out of range,
 *            or port already connected, or port not settable.
 */
 	public void set( int time, double value, int partIndex )
	throws SynthException
	{
		if( Synth.verbosity >= Synth.VERBOSE )
		{
			System.out.println("SynthVariable.set(" + time + ", " + Integer.toHexString(peerToken) +
				", " + name +
				", " + partIndex +
				", " + value + ")"
				);
		}
		int nativeError = Synth.SetPortAt( sound.context, time, peerToken, portHash, partIndex, value );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken, partIndex );
		lastValue = value;
	}

	public void set( int time, double value )
	throws SynthException
	{
		set( time, value, 0 );
	}

	public void set( double value, int partIndex )
	throws SynthException
	{
		if( Synth.verbosity >= Synth.VERBOSE )
		{
			System.out.println("SynthVariable.set(" + Integer.toHexString(peerToken) +
				", " + name +
				", " + partIndex +
				", " + value +
				")"
				);
		}
		int nativeError = Synth.SetPort( sound.context, peerToken, portHash, partIndex, value );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken, partIndex );
		lastValue = value;
	}

	public void set( double value )
	throws SynthException
	{
		set( value, 0 );
	}
	
/**
 * @return last value set() on port.
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public double get( int partIndex )	throws SynthException
	{
		return lastValue;
	}
	
/**
 * @return current value of port.
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public double getCurrent( int partIndex )	throws SynthException
	{
		return super.get( partIndex );
	}
	public double getCurrent()
	{
		return getCurrent(0);
	}

/**
 * Set minimum preferred value.
 */
	public void setMin( double min )
	{
		this.min = min;
	}
/**
 * @return minimum preferred value.
 */
	public double getMin()
	{
		return min;
	}
/**
 * Set maximum preferred value.
 */
	public void setMax( double max )
	{
		this.max = max;
	}
/**
 * @return maximum preferred value.
 */
	public double getMax()
	{
		return max;
	}

/**
 * Conveniance method for setting minimum, current, and maximum values.
 * @exception SynthException If call to set() fails.
 */
	public void setup( double min, double value, double max )
	throws SynthException
	{
		setMin( min );
		set( value );
		setMax( max );
	}
}
