
package com.softsynth.jsyn.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** Record audio data to a Java Output stream.
 * This class uses an audio SampleWriter and a SampleQueueInputStream
 * to collect the data.
 * A thread periodically grabs data and writes it to the stream.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see SampleQueueInputStream
*/
public class StreamRecorder extends FilterOutputStream  implements Runnable
{
/** Connect your audio output to this input.
 */
	public SynthInput input;
	
	SampleWriter  sampler;
	SampleQueueInputStream audioStream;
	boolean       isLittleEndian = true;
	byte          buffer[];
	short         samples[];
	Thread        thread;
	boolean       go = false;
	int           channelsPerFrame = 1;
	int           framesPerBuffer;
	
	public StreamRecorder( OutputStream outStream,
						   int framesPerBuffer,
						   int numBuffers,
						   int channelsPerFrame ) 
	{
		this( Synth.getSharedContext(), outStream,
						   framesPerBuffer,
						   numBuffers,
						   channelsPerFrame );
	}
	
/** Create a recorder that will write an input signal to the outStream.
 * @param framesPerBuffer Number of audio frames in a block to be written to outStream.
 * @param numBuffers Number of buffers to use. Should be at least 2.
 * @param channelsPerFrame is 1 for mono, 2 for stereo
 */
	public StreamRecorder( SynthContext synthContext,
						   OutputStream outStream,
						   int framesPerBuffer,
						   int numBuffers,
						   int channelsPerFrame )
	{
		super( outStream );
		if( channelsPerFrame == 1 )
		{
			sampler = new SampleWriter_16F1(synthContext);
		}
		else if( channelsPerFrame == 2 )
		{
			sampler = new SampleWriter_16F2(synthContext);
		}
		else
		{
			throw new RuntimeException("channelsPerFrame must be 1 or 2");
		}
		input = sampler.input;
		if( numBuffers < 2 ) numBuffers = 2;
		audioStream = new SampleQueueInputStream( sampler.samplePort, framesPerBuffer * numBuffers, channelsPerFrame );
		int bytesPerBuffer = framesPerBuffer * channelsPerFrame * 2;
		buffer = new byte[ bytesPerBuffer ];
		samples = new short[ bytesPerBuffer/2 ];
		this.channelsPerFrame = channelsPerFrame;
		this.framesPerBuffer = framesPerBuffer;
	}
	
/** Set endianness of the byte stream. This will determine how shorts are converted to bytes.
 * Use false for AIFF files.
 * Use true for WAV files. The default is true.
 */
	public void setLittleEndianness( boolean isLittleEndian )
	{
		this.isLittleEndian = isLittleEndian;
	}
	
	public boolean getLittleEndianness()
	{
		return isLittleEndian;
	}
	public boolean isLittleEndian()
	{
		return isLittleEndian;
	}
	
	public void transfer() throws IOException
	{
		audioStream.read( samples, 0, framesPerBuffer );
		int bindex = 0;
		if( isLittleEndian )
		{
			for( int i = 0; i< samples.length; i++ )
			{
				buffer[bindex++] = (byte) samples[i];  // little end first
				buffer[bindex++] = (byte) (samples[i] >> 8);
			}
		}
		else
		{
			for( int i = 0; i< samples.length; i++ )
			{
				buffer[bindex++] = (byte) (samples[i] >> 8); // big end first
				buffer[bindex++] = (byte) samples[i];
			}
		}
		write( buffer );
	}
	
	public void run()
	{
		try
		{
			while( go )
			{
				transfer();
			}
			flush();
		}
		catch( IOException e )
		{
			System.out.println("run() caught " + e );
		}
		catch( SynthException e )
		{
			System.out.println("run() caught " + e );
		}
	}

/** Start recording to the outStream.
 */
	public void start( int time )
	{
		if( thread != null ) stop( time );
		audioStream.start( time );
		sampler.start( time );
	// launch a thread to keep stream supplied with data
		thread = new Thread( this );
		go = true;
		thread.start();
	}
	
/** Stop the recording thread.
 * This will join() with the thread which may take a moment.
 */
	public void stop( int time )
	{
		go = false;
	// WARNING: interrupt() and join() are broken in Netscape V4.7 and earlier Java VMs
		thread.interrupt();
		try
		{
			thread.join(1000);
		} catch( InterruptedException e ) {
			System.err.println("StreamRecorder.stop() interrupted!");
		}
		audioStream.stop( time );
		sampler.stop( time );
		thread = null;
	}
}

