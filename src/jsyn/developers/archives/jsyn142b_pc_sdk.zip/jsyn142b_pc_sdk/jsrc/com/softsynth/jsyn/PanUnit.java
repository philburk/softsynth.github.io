package com.softsynth.jsyn;
import java.util.*;

/**
 *	Pan unit.
 <P>
  Takes an input and pans it between two outputs based on value
  of pan.
  When pan is -1, output[0] is input, and output[1] is zero.
  When pan is 0, output[0] and output[1] are both input/2.
  When pan is +1, output[0] is zero, and output[1] is input.
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see SelectUnit
 */

public class PanUnit extends SynthUnit 
{
	public SynthInput input;
/** Smoothly pans input between output[0] and output[1]. */
	public SynthInput pan;
/** This port has two parts, 0 and 1. */
	public SynthOutput output;

 	public PanUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_Pan", calculationRate );
		input = new SynthInput( this, "Input" );
		pan = new SynthInput( this, "Pan" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
 	public PanUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public PanUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
