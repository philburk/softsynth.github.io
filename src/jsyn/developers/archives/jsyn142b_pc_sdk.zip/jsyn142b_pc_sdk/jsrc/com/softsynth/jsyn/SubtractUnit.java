package com.softsynth.jsyn;
import java.util.*;

/**
 *	SubtractUnit unit.
 <P>
 output = inputA - inputB
 <P>
 output is clipped to the SIGNED range -1.0 to +1.0
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see AddUnit
 */

public class SubtractUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public SubtractUnit( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Math_Subtract", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public SubtractUnit( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public SubtractUnit( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
