package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
/**
 * Test SynthSound or SynthCircuit by
 * putting PortFaders on all SynthInputs.
 * Also allows user to setStage() by clicking radio buttons.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

abstract public class InternalSoundTester extends Panel
{
	protected Checkbox[] cbox;
	protected SynthSound sound;
	protected Button     hitButton;
	protected final static int NUM_STAGES = 8;

	public InternalSoundTester( SynthSound sound ) throws SynthException
	{
		super();
		this.sound = sound;

		setLayout( new GridLayout(0,1) );

		SynthPort  newPort;
/* Query for the number of ports. */
		int numPorts = sound.getNumPorts();

/* Get each port.  Attach a PortFader to each SynthInput. */
		for(int i=0; i<numPorts; i++ )
		{
			newPort = sound.getPortAt( i );
//			System.out.println("Add " + newPort );
			
			if( (newPort instanceof SynthVariable) ) addInput( (SynthVariable) newPort );
		}

/* Add a radio grid to trigger states in sound. */
		Panel stageSetter = new Panel();
		CheckboxGroup cbg = new CheckboxGroup();
		cbox = new Checkbox[NUM_STAGES];
		stageSetter.add( new Label("Stage:") );
		for( int i=0; i<NUM_STAGES; i++ )
		{
			stageSetter.add(cbox[i] = new Checkbox(Integer.toString(i), cbg, (i==0) ));
		}
		add( stageSetter );

		add( hitButton = new Button("Hit") );

/* Add a button that polls and displays the current CPU usage. */
		add( new UsageDisplay() );
	}
	
	abstract protected void addInput( SynthVariable input );
}
