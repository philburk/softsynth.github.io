package com.softsynth.jsyn.view11x;

/**
 * A 2 dimensional X,Y controller for wave editors, Theremins, etc.
 * Maps pixel coordinates into "world" coordinates.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class XYController extends com.softsynth.jsyn.view102.XYController
{
}
