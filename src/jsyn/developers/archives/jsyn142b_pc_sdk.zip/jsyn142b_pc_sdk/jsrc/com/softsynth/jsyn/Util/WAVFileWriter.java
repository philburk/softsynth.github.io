package com.softsynth.jsyn.util;
import com.softsynth.util.RandomOutputStream;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** Writes audio data to a random access file in WAV format.
 * Note that if you are overwriting a RandomAccessFile then you should clear it before you start.
 * This will prevent having the remainder of a longer file stuck at the end of
 * a short file. In Java 1.2 you can call setLength(0).
 */
public class WAVFileWriter extends RandomOutputStream
{
	static final short WAVE_FORMAT_PCM = 1;
	long   riffSizePosition = 0;
	long   dataSizePosition = 0;
	int    bytesPerSample = 2;
	
	public WAVFileWriter( RandomAccessFile file )  throws IOException
	{
		super( file );
	}
	
/** Write a 32 bit intgeer to the stream in Little Endian format.
 */
	public void writeIntLittle( int n ) throws IOException
	{
		write( n & 0xFF );
		write( (n>>8) & 0xFF );
		write( (n>>16) & 0xFF );
		write( (n>>24) & 0xFF );
	}
/** Write a 16 bit intgeer to the stream in Little Endian format.
 */
	public void writeShortLittle( short n ) throws IOException
	{
		write( n & 0xFF );
		write( (n>>8) & 0xFF );
	}
	
/** Write an 'fmt ' chunk to the WAV file containing the given information.
 */
	public void writeFormatChunk( int bitsPerSample, int channelsPerFrame, int sampleRate ) throws IOException
	{
		bytesPerSample = (bitsPerSample + 7) / 8;
		
		write('f'); write('m'); write('t'); write(' ');
		writeIntLittle( 16 ); // size
		writeShortLittle( WAVE_FORMAT_PCM );
		writeShortLittle( (short) channelsPerFrame );
		writeIntLittle( sampleRate );
		writeIntLittle( sampleRate*channelsPerFrame*bytesPerSample ); /* bytes/second */
		writeShortLittle( (short) (channelsPerFrame*bytesPerSample) ); /* block align */
		writeShortLittle( (short) bitsPerSample ); /* bits per sample */
	}
	
/** Write a data chunk to the WAV file containing the given short array.
 * Multi-channel data should be interleaved.
 */
	public void writeDataChunk( short samples[] ) throws IOException
	{
		writeDataChunkHeader( samples.length*2 );
		for( int i=0; i<samples.length; i++ )
		{
			writeShortLittle( samples[i] );
		}
	}
	
/** Write a 'data' chunk header to the WAV file.
 * This should be followed by call to writeShortLittle()
 * to write the data to the chunk.
 * If you do not know the length of the data chunk when calling this method,
 * then pass zero for the size. Then when you finish writing the data call 
 * fixSizes().
 */
	public void writeDataChunkHeader( int size ) throws IOException
	{
		write('d'); write('a'); write('t'); write('a');
		dataSizePosition = getFilePointer();
		writeIntLittle( size ); // size
	}
	
	
/** Write a 'RIFF' file header and a 'WAVE' ID to the WAV file.
 * If you do not know the length of the file when calling this method,
 * then pass zero for the size. Then when you finish writing the data chunk call 
 * fixSizes().
 */
	public void writeHeader( int size ) throws IOException
	{
		write('R'); write('I'); write('F'); write('F');
		riffSizePosition = getFilePointer();
		writeIntLittle( size );
		write('W'); write('A'); write('V'); write('E');
	}
	
/** Write a simple WAV header for 16 bit PCM data.
 * Set file and data sizes to zero.
 */
	public void writeHeader( int channelsPerFrame, int sampleRate ) throws IOException
	{
/* write RIFF header */
		writeHeader( 0 );
/* write Format and data chunks */
		writeFormatChunk( 16, channelsPerFrame, sampleRate );
		writeDataChunkHeader( 0 );
	}

/** Fix RIFF and data chunk sizes based on final size.
 * Assume data chunk is the last chunk.
 */
	public void fixSizes()  throws IOException
	{
	// adjust RIFF size
		long end = getFilePointer();
		int riffSize = (int) (end - riffSizePosition) - 4;
		seek( riffSizePosition );
		writeIntLittle( riffSize );
	// adjust data size
		int dataSize = (int) (end - dataSizePosition) - 4;
		seek( dataSizePosition );
		writeIntLittle( dataSize );
		// System.out.println("riffSize = " + riffSize + ", dataSize = " + dataSize );
	}
		
/** Write a complete WAV file containing the array of short samples.
 */
	public void write( short samples[], int channelsPerFrame, int sampleRate ) throws IOException
	{
		int formSize = 4 + (8+(samples.length*2)) + (8+16); /* RIFF+wave+fmt*/
/* write RIFF header */
		writeHeader( formSize );
/* write Format and data chunks */
		writeFormatChunk( 16, channelsPerFrame, sampleRate );
		writeDataChunk( samples );
	}
	
	void test1()  throws IOException
	{
		final int FRAME_RATE = 44100;
		final int NUM_SAMPLES = (int) (FRAME_RATE * 10.0);
		short data[] = new short[NUM_SAMPLES];
		short phase = 0;
		for( int i=0; i<NUM_SAMPLES; i++ )
		{
			data[i] = phase;
			phase += 456;
		}
		write( data, 1, FRAME_RATE );
	}
	
	void test2()  throws IOException
	{
		final int FRAME_RATE = 44100;
		final int NUM_SAMPLES = 1000;
		short data[] = new short[NUM_SAMPLES];
		short phase = 0;
		for( int i=0; i<NUM_SAMPLES; i++ )
		{
			data[i] = phase;
			phase += 0x200;
		}
		writeHeader( 1, FRAME_RATE );
		for( int i=0; i<1; i++ )
		{
			for( int k=0; k<NUM_SAMPLES; k++ )
			{
				write( (byte) data[k] );
				write( (byte) (data[k]>>8) );
			}
		}
	// go back and fix up the sizes
		fixSizes();
	}
		
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		try
		{
			RandomAccessFile rfile = new RandomAccessFile( "testout.wav", "rw" );
			WAVFileWriter app = new WAVFileWriter( rfile );
			// app.setLength(0); // only supported in Java 1.2 !!!
			app.test2();
			app.close();
			System.out.println("Wrote testout.wav");
		} catch( IOException e ) {
			System.err.println( e );
		}
		System.exit(0);
	}
	
}
