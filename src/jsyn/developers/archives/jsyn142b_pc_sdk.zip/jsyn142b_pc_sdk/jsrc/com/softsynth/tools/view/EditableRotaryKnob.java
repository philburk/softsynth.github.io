package com.softsynth.tools.view;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import com.softsynth.util.*;
import com.softsynth.view.*;

public class EditableRotaryKnob extends Panel implements ValueListener, ActionListener, ValueController
{
	RotaryKnob   knob;
	TextField    field;
	Label        label;
	boolean      fieldModified;
	
	public EditableRotaryKnob( String text, double val, double min, double max, int numCharacters )
	{
		setLayout( new BorderLayout() );
		
		if( text != null )
		{
			setText( text );
		}
		
		add( "Center", knob = new RotaryKnob( val, min, max ) );
		Panel fieldPanel = new Panel();
		knob.addValueListener( this );
		
		add( "South", fieldPanel );
		fieldPanel.add( field = new TextField( Double.toString( val ), numCharacters ) );
		field.addActionListener( this );
		field.addKeyListener( new KeyAdapter()
			{
				public void keyPressed(KeyEvent e)
				{
					fieldModified = true;
					field.setBackground( Color.pink );
					repaint();
				}
			} );
	}
	
	public EditableRotaryKnob( double val, double min, double max )
	{
		this( null, val, min, max, 8 );
	}
	
	public RotaryKnob getKnob()
	{
		return knob;
	}
	public TextField getTextField()
	{
		return field;
	}
		
	public void setText( String text )
	{
		if( label == null )
		{
			add( "North", label = new Label( text, Label.CENTER ) );
		}
		else
		{
			label.setText( text );
		}
	}
	public String getText()
	{
		return label.getText();
	}
	
	public void actionPerformed( ActionEvent e)
	{
		try
		{
			double val = Double.valueOf( field.getText() ).doubleValue();
			knob.setValue( val );
			fieldModified = false;
			field.setBackground( Color.white );
			repaint();
		} catch( NumberFormatException exp ) {
			field.setText("ERROR");
			field.selectAll();
		}
	}
	
  	public void valueChanged( ValueEvent e )
	{
		setValueText( e.getValue() );
	}
	
  	public void setValueText( double value)
	{
		String s = NumericOutput.doubleToString( value, 1, 4 ); // FIXME - user settable places
		field.setText( s );
	}
	
	public void setValue( double value )
	{
		knob.setValue( value );
	}
	
	public double getValue()
	{
		return knob.getValue();
	}
	public double getDoubleValue()
	{
		return knob.getDoubleValue();
	}
	
/** Set maximum for value.
 */
	public void setMaximum( double maximum )
	{
		knob.setMaximum( maximum );
	}
/** Get maximum value.
 */
	public double getMaximum()
	{
		return knob.getMaximum();
	}
/** Set minimum for value.
 */
	public void setMinimum( double minimum )
	{
		knob.setMinimum( minimum );
	}
/** Get minimum value.
 */
	public double getMinimum()	
	{
		return knob.getMinimum();
	}
	
	public void addValueListener( ValueListener listener )
	{
		knob.addValueListener( listener );
	}
	public void removeValueListener( ValueListener listener )
	{
		knob.removeValueListener( listener );
	}
}
