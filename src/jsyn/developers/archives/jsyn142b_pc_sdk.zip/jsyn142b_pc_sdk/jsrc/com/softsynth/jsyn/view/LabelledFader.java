/**
 * Fader with Label and value display.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
public class LabelledFader extends Panel implements Tweakable
{
	Tweakable  target;
	int        targetIndex;
	String     faderName;
	Scrollbar  fader;
	Label      nameLabel;
	Label      valueLabel;
	double     min,max;
	final static int RANGE = 200;
/**
 * Create a LabelledFader.
 * @param target Object that implements tweakable interface. If null, then this objects tweak method() will be called.
 * @param targetIndex Index that will be passed to tweak() method.
 * @param faderName Name of fader displayed on left of fader..
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public LabelledFader( Tweakable target, int targetIndex, String faderName, double startValue, double min, double max )
	{
		if( target == null ) this.target = this;
		else this.target = target;
		
		this.targetIndex = targetIndex;
		this.faderName = faderName;
		this.min = min;
		this.max = max;
		setLayout( new GridLayout(0,3) );
/* Add space to label so it doesn't come too close to Scrollbar. */
		nameLabel = new Label( faderName + " ", Label.RIGHT );
		add(nameLabel);
		int visible = RANGE/10;
		fader = new Scrollbar( Scrollbar.HORIZONTAL, doubleToFader(startValue), visible, 0, RANGE + visible);
		add(fader);
		valueLabel = new Label();
		showValue( startValue );
		add(valueLabel);
	}
	double faderToDouble( int val )
	{
			return ((val*(max-min))/RANGE) + min;
	}
	
	int doubleToFader( double fval )
	{
			return (int)(((fval - min)*RANGE)/(max-min));
	}
	void showValue( double fval )
	{
/* Prevent size of label from fluctuating wildly. */
		String fvalString = Double.toString( fval );
		int maxchars = fvalString.indexOf( '.' ) + 5;
		String actualString = (fvalString.length() > maxchars) ? fvalString.substring(0,maxchars) : fvalString;
		valueLabel.setText( actualString );
	}
/** This can be overridden in subclasses. */
	public void tweak( int idx, double fval )
	{
	}
	
	public boolean handleEvent(Event evt)
	{
		if( evt.target == fader )
		{
			switch( evt.id )
			{
			case Event.SCROLL_ABSOLUTE:
			case Event.SCROLL_LINE_DOWN:
			case Event.SCROLL_LINE_UP:
			case Event.SCROLL_PAGE_DOWN:
			case Event.SCROLL_PAGE_UP:
				int val = fader.getValue();
				double fval = faderToDouble(val);
				target.tweak( targetIndex, fval );
				showValue( fval );
				repaint();
				break;
			}
			return true;
		}
		return super.handleEvent(evt);
    }
}
