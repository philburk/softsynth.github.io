package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Cheezy Analog Snare sound.
 *
 *    Lag------*--*
 *             |  |
 *    Noise-->Filter---\
 *                      + --> Output
 *    FMPair-----------/
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class AnalogSnare extends SynthNote
{
	WhiteNoise          myNoise;
	StateVariableFilter myFilter;
	ExponentialLag      myLag;
// FIXME - FM not used!	FMPair              myFM;
	MultiplyUnit        scaleLagToFreq;
	MultiplyUnit        scaleLagToAmpl;
	AddUnit             myMixer;
	
/* Declare port. */
	public SynthInput noiseAmp;
	public SynthInput cutoff;
	public SynthInput resonance;

/*
 * Setup synthesis.
 */
	public AnalogSnare()  throws SynthException
	{
/* Create various unit generators and add them to circuit. */
		add( myNoise = new WhiteNoise() );
		add( myFilter = new StateVariableFilter() );
		add( myLag = new ExponentialLag() );
// FIXME - FM not used!		add( myFM = new FMPair() ); 
		add( myMixer = new AddUnit() );
		add( scaleLagToFreq = new MultiplyUnit() );
		add( scaleLagToAmpl = new MultiplyUnit() );

/* Connect SynthUnits to make control signal path. */
		myLag.output.connect( scaleLagToFreq.inputA );
		myLag.output.connect( scaleLagToAmpl.inputA );
		scaleLagToFreq.inputB.setSignalType( Synth.SIGNAL_TYPE_SVF_FREQ ); /* So we can use Hz */
		myLag.halfLife.set( 0.1 );

		scaleLagToFreq.output.connect( myFilter.frequency );
		scaleLagToAmpl.output.connect( myFilter.amplitude );
/* Connect SynthUnits to make audio signal path. */
		myNoise.output.connect( myFilter.input );
		myFilter.output.connect( myMixer.inputA );

/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( noiseAmp = myNoise.amplitude, "NoiseAmp" );
		addPort( resonance = myFilter.resonance );
		addPort( frequency = scaleLagToFreq.inputB, "frequency" );
		addPort( amplitude = scaleLagToAmpl.inputB, "amplitude" );
		addPort( output = myMixer.output );

/* Set ports to useful values and ranges. */
		noiseAmp.setup( 0.0, 0.3, 0.4 );
		frequency.setup(  0.0, 800.0, 1200.0 );
		resonance.setup(  0.0, 0.1, 0.2 );
		amplitude.setup(   0.0, 0.9, 0.999 );
	}
	
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0:
			stop( time );
			myLag.current.set( time, 1.0 );
			start( time );
			break;
		}
	}
}

