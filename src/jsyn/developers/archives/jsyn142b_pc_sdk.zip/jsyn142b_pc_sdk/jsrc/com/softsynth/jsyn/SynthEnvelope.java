package com.softsynth.jsyn;
import java.util.*;

/**
 *	The SynthEnvelope contains a set of duration value pairs that describe a contour,
 * or a function in time. It can be used to shape the amplitude of notes or provide
 * complex modulation of any parameter.
 * <br>
 * The actual data may need to reside in memory that is accessible to 
 *	DMA or to a DSP so we cannot assume that it is in main memory.  We also need to maintain cache coherence if the data is 
 *	going to be read or written by hardware other than the CPU.  For this reason, Envelopes cannot use memory allocated by, or 
 *	accessable to, the application.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see EnvelopePlayer
 * @see SynthEnvelopeQueue
 * @see SynthSample
 */

public class SynthEnvelope extends SynthChannelData
{

/**
 * Create an Envelope with the specified number of frames. 
 * @exception SynthException	 If memory allocation fails.
 */
	public SynthEnvelope( int maxFrames )
	throws SynthException
	{
		this( Synth.getSharedContext(), maxFrames );
	}
	public SynthEnvelope( SynthContext synthContext, int maxFrames )
	throws SynthException
	{
		super( synthContext, maxFrames );
		peerToken = Synth.CreateEnvelope( context, maxFrames );
		if( peerToken < 0 ) throw new SynthException( peerToken, maxFrames );
	}
/**
 * Create an Envelope that will contain the contents of the double array. 
 * @exception SynthException	 If memory allocation fails.
 */
	public SynthEnvelope(  SynthContext synthContext, double[] data )
	throws SynthException
	{
		this( synthContext, data.length/2 );
		write( 0, data, 0, maxFrames );
	}
	public SynthEnvelope( double[] data )
	throws SynthException
	{
		this( Synth.getSharedContext(), data );
	}

/**
 * <P>Write data from an array of doubles to the Envelopes internal storage area.
 * The internal storage may be in main memory or it could be located on the
 * sound card and only accessable by DMA. 
 * @param firstEnvelopeFrame = Index of first frame of envelope to be written to. A frame consists of two double numbers,a duration and a value.
 * @param data = array of doubles containing duration and value pairs.
 * @param firstDataFrame = index of first frame in data array to write from. Note that because a frame is two values, the firstDataFrame is half the the array index.
 * @param numFrames = number of frames to write.
 * @exception SynthException	 If frames are out of range.
 */
	public void write( int firstEnvelopeFrame, double[] data, int firstDataFrame, int numFrames )
	throws SynthException
	{
		int result = Synth.WriteEnvelope( context, peerToken, firstEnvelopeFrame, numFrames, data, firstDataFrame, data.length );
		if( result < 0 ) throw new SynthException( result, peerToken, firstEnvelopeFrame );
	}
	public void write( double[] data )
	throws SynthException
	{
		write( 0, data, 0, data.length/2 );
	}

/**
 * Read from the Envelope into an array of doubles.
 * @param firstEnvelopeFrame = Index of first frame of envelope to be read from. A frame consists of two double numbers,a duration and a value.
 * @param data = array of doubles duration and value pairs.
 * @param firstDataFrame = index of first frame in data array to read in to. Note that because a frame is two values, the firstDataFrame is half the the array index.
 * @param numFrames = number of frames to read.
 * @exception SynthException	 If frames are out of range.
 */
	public void read( int firstEnvelopeFrame, double[] data, int firstDataFrame, int numFrames )
	throws SynthException
	{
		int result = Synth.ReadEnvelope( context, peerToken, firstEnvelopeFrame, numFrames, data, firstDataFrame, data.length );
		if( result < 0 ) throw new SynthException( result, peerToken, firstEnvelopeFrame );
	}
	
	public void read( double[] data )
	throws SynthException
	{
		read( 0, data, 0, data.length/2 );
	}

}
