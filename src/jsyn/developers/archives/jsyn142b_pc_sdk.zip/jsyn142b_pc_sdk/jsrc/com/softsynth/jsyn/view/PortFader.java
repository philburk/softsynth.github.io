/**
 * Fader for controlling a Java Synthesis Unit's Port.
 * Displays Port name and Value.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
public class PortFader extends LabelledFader implements Tweakable
{
	SynthVariable inPort;
	String     portName;
/**
 * Create a PortFader that will provide user control over a SynthPort.
 * @param inPort The port to be controlled using the ScrollBar.
 * @param aliasName Overrides the actual name of the port with a more meaningful name.
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public PortFader( SynthVariable inPort, String aliasName, double startValue, double min, double max )
	{
		super( null, 0, aliasName, startValue, min, max );
		this.inPort = inPort;
		tweak( 0, startValue);
	}
	public PortFader( SynthVariable inPort, double startValue, double min, double max )
    {
		this( inPort, inPort.getAlias(), startValue, min, max );
	}
	public void tweak( int idx, double fval )
	{
		try
		{
			inPort.set(fval);
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
}
