package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;

/**
 * Panel with insets that can be used to border a centered component.
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class InsetPanel extends com.softsynth.jsyn.view102.InsetPanel
{
	
	public InsetPanel( Component borderMe )
	{
		super( borderMe );
	}
	public InsetPanel( Component borderMe, Color borderColor )
	{
		super( borderMe, borderColor );
	}
	public InsetPanel( Component borderMe, int border )
	{
		super( borderMe, border );
	}

/** 
 * @param borderMe component to be centerred in this panel. Typically another Panel.
 * @param borderColor color to paint the border.
 * @param border width in pixels of border.
 */
	public InsetPanel( Component borderMe, Color borderColor, int border )
	{
		super( borderMe, borderColor, border );
	}
}
