package com.softsynth.jsyn;
import java.util.*;

/**
 *	State Variable Filter
This filter is based on the State Variable Filter described in Hal Chamberlain's
"Musical Applications of MicroProcessors".  It is convenient because its frequency
and resonance can each be controlled by a single value.
<P>
The "output" port of this filter is the "lowPass" output multiplied by the "amplitude".
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 * @see Filter_101z
 */

public class StateVariableFilter extends SynthFilter
{
/** Frequency of filter cutoff in Hertz. SIGNAL_TYPE_SVF_FREQ */
	public SynthInput frequency;

/** Controls feedback that causes self oscillation.
 * Actually 1/Q - SIGNAL_TYPE_RAW_SIGNED
 * in the range of 0.0 to 1.0. Defaults to 0.125.
 */
	public SynthInput resonance;
/**
 * Amplitude of Output in the range of 0.0 to 1.0.
 * SIGNAL_TYPE_RAW_SIGNED Defaults to 1.0 <P>
 * Note that the amplitude only affects the "output" port and not
 * the lowPass, bandPass or highPass signals. Use a MultiplyUnit if
 * you need to scale those signals.
 */
	public SynthInput amplitude;

/** Low pass filtered signal. SIGNAL_TYPE_RAW_SIGNED <P>
 * Note that this signal is not affected by the amplitude port.
 * */
	public SynthOutput lowPass;
/** Band pass filtered signal. SIGNAL_TYPE_RAW_SIGNED <P>
 * Note that this signal is not affected by the amplitude port. */
	public SynthOutput bandPass;
/** High pass filtered signal. SIGNAL_TYPE_RAW_SIGNED <P>
 * Note that this signal is not affected by the amplitude port. */
	public SynthOutput highPass;

 	public StateVariableFilter( SynthContext synthContext, int calculationRate ) throws SynthException
	{
		super( synthContext, "Filter_StateVariable", calculationRate, 0 );
		resonance = new SynthInput( this, "Resonance" );
		frequency = new SynthInput( this, "Frequency" );
		amplitude = new SynthInput( this, "Amplitude" );
		lowPass   = new SynthOutput( this, "LowPass" );
		bandPass  = new SynthOutput( this, "BandPass" );
		highPass  = new SynthOutput( this, "HighPass" );
	}
/**
 *	Create a StateVariableFilter that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public StateVariableFilter( SynthContext synthContext ) throws SynthException
	{
		this( synthContext, Synth.RATE_AUDIO );
	}
	public StateVariableFilter( ) throws SynthException
	{
		this( Synth.getSharedContext(), Synth.RATE_AUDIO );
	}
}
