package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthBusInput port that can connect to multiple SynthBusOutputs
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see SynthBusOutput
 * @see BusWriter
 */

public class SynthBusInput extends SynthPort
{
	
	SynthBusInput( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	
/**	
 *	Connect named output port to an input port of another instrument.
 *  Each port can have multiple indexed parts.
 *  A stereo sample reader would, for example, have an "Output" with two parts. 
 *
 * @exception SynthException	If port name is not recognized, or index out of range,
 *            or destPort already connected.
 */
	public void connect( int inIndex, SynthBusOutput outPort, int outIndex ) throws SynthException
	{
		super.connectUnits( outPort, outIndex, this, inIndex );
	}
	
	public void connect( SynthBusOutput outPort ) throws SynthException
	{
		connect( 0, outPort, 0 );
	}

/**
 *	Disconnects all the connections made to this port.
 * @exception SynthException	If index out of range.
 */
	public void disconnect( int index )
	throws SynthException
	{
		super.disconnectUnits( this, index );
	}
	public void disconnect( ) throws SynthException
	{
		disconnect( 0 );
	}

}
