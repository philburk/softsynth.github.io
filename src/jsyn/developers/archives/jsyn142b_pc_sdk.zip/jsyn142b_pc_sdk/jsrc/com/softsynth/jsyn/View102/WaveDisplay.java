package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;

/**
 * This class draws an associated short array as a waveform.
 * Waveforms are added in the form of a WaveTrace object.
 * The left and right indices can be set to provide zoom and pan.
 *
 * @see WaveTrace
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class WaveDisplay extends Canvas
{
	Vector   traces;
	int      leftIndex = 0;
	int      rightIndex = 512;
	int      maxIndex;  /* maximum index of rightmost point. */
/**
 * Create WaveDisplay.
 */
	public WaveDisplay( )
	{
		traces = new Vector();
	}

	void calcMaxIndex()
	{
		maxIndex = 0;
		for( int j=0; j<traces.size(); j++)
		{
			WaveTrace trace = (WaveTrace) traces.elementAt(j);
			short[] data = trace.data;
			if( data.length-1 > maxIndex ) maxIndex = data.length-1;
		}
		clipIndices();
	}

/** Set index of leftmost displayed point in traces.
 */
	public void setLeftIndex( int left )
	{
		leftIndex = ( left < 0 ) ? 0 : left;
		repaint();
	}
	public int getLeftIndex()
	{
		return leftIndex;
	}
	
/** Set index of rightmost displayed point in traces.
 */
	public void setRightIndex( int right )
	{
		rightIndex = ( right > maxIndex ) ? maxIndex : right;
		repaint();
	}
	public int getRightIndex()
	{
		return leftIndex;
	}


/** Pan the display to the left by delta. */
	public void panLeft( int delta )
	{
		if( (leftIndex - delta) < 0 ) delta = leftIndex;
		leftIndex -= delta;
		rightIndex -= delta;
		repaint();
	}
	
/** Pan the display to the left by half the currently displayed amount. */
	public void panLeft()
	{
		int delta = (rightIndex - leftIndex)/2;
		panLeft( delta );
	}

/** Pan the display to the right by delta. */
	public void panRight( int delta )
	{
		if( (rightIndex + delta) > maxIndex ) delta = maxIndex - rightIndex;
		leftIndex += delta;
		rightIndex += delta;
		repaint();
	}
	
/** Pan the display to the right by half the currently displayed amount. */
	public void panRight()
	{
		int delta = (rightIndex - leftIndex)/2;
		panRight( delta );
	}
	
	public void zoomIn()
	{
		int delta = (rightIndex - leftIndex)/4;
		leftIndex += delta;
		rightIndex -= delta;
		repaint();
	}

	void clipIndices()
	{
		if( rightIndex > maxIndex ) rightIndex = maxIndex;
		if( leftIndex > rightIndex ) leftIndex = rightIndex - 1;
		if( leftIndex < 0 ) leftIndex = 0;
	}

	public void zoomOut()
	{
		int delta = (rightIndex - leftIndex)/2;
		if( delta < 1 ) delta = 1;
		leftIndex -= delta;
		rightIndex += delta;
		clipIndices();
		repaint();
	}
	
/** Add another trace to be displayed when this component is drawn.
 * Multiple traces can be displayed simultaneously.
 * You can set the traces' colors to distinguish them.
 */
	public synchronized void addTrace( WaveTrace trace )
	{
		if( traces.size() == 0 )
		{
			leftIndex = 0;
			rightIndex = 512;
		}
		traces.addElement( trace );
		calcMaxIndex();
	}
	
	public synchronized void removeTrace( WaveTrace trace )
	{
		traces.removeElement( trace );
		calcMaxIndex();
	}

	private int shortToY( short s, int h, double scaleFactor )
	{
		return (int) (h * ((1<<15) - (int)(scaleFactor * s))) >> 16;
	}
	
/**
 * Draw WaveTraces in their specified colors and using the specified scaleFactors.
 * This function is normally only called by the Java graphics system.
 * If you want to redraw the display because a trace has changed, then
 * call repaint().
 */
   public void paint(Graphics g)
	{
        int w = size().width;
        int h = size().height;
		int lastX, lastY;

/* Draw X axis. */
        g.setColor(Color.white);
		g.drawLine( 0, h/2, w, h/2 );

/* Draw waveforms. */
		for( int j=0; j<traces.size(); j++)
		{
			WaveTrace trace = (WaveTrace) traces.elementAt(j);
			double scaleFactor = trace.scaleFactor;
	        g.setColor(trace.color);
			short[] data = trace.data;
			if( data.length-1 > leftIndex )
			{
				lastX = 0;
				lastY = shortToY( data[leftIndex], h, scaleFactor );
				int right = (data.length-1 < rightIndex) ? data.length-1 : rightIndex ;
				for( int i=leftIndex+1; i<=right; i++ )
				{
					int x = ((i-leftIndex)*w)/(right - leftIndex);
					int y = shortToY( data[i], h, scaleFactor );

					g.drawLine( lastX, lastY, x,y );
					lastX = x;
					lastY = y;
				}
			}
		}
		
/* Draw Horizontal Scale. */
        g.setColor(Color.white);
		g.drawString( Integer.toString( leftIndex ), 5, h-20 );
		g.drawString( Integer.toString( rightIndex ), w-40, h-20 );
    }
}
