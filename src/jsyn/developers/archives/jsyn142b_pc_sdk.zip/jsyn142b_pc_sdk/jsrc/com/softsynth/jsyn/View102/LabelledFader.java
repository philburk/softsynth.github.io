package com.softsynth.jsyn.view102;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
/**
 * Fader with Label and value display.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class LabelledFader extends InternalLabelledFader
{
/**
 * Create a LabelledFader.
 * @param target Object that implements tweakable interface. If null, then this objects tweak method() will be called.
 * @param targetIndex Index that will be passed to tweak() method.
 * @param faderName Name of fader displayed on left of fader..
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public LabelledFader( Tweakable target, int targetIndex, String faderName, double startValue, double min, double max )
	{
		super( target, targetIndex, faderName, startValue, min, max );
	}

	protected void makeFader( int initial )
	{
		int visible = RANGE/10;
		fader = new CustomFader( CustomFader.HORIZONTAL, initial, visible, 0, RANGE );
	}
	
/** Return CustomFader used internally by LabelledFader.
 */
	public CustomFader getFader()
	{
		return (CustomFader) fader;
	}


}
