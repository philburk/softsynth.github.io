package com.softsynth.jsyn;
import java.util.*;

/**
 *	WaveShaper unit.
 *
 * Lookup a value by interpolating between values in a Table. When Input is
 * -1.0, the value from the table is Table[0]. When Input is +1.0, then the
 * value from the table is Table[NumValues-1]. The output is the interpolated
 * table value times the Amplitude.
 * 
 * The name "wave shaping" refers to the synthesis technique that involves connecting
 * an oscillator such as a SineOscillator or SawtoothOscillator to the input of
 * this unit. By modifying the contents of the table, and the amplitude of the input,
 * interesting output waveforms can be created.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class WaveShaper extends SynthUnit 
{
	public SynthInput input;
	public SynthInput amplitude;
	public SynthTablePort tablePort;
	public SynthOutput output;

 	public WaveShaper( int calculationRate ) throws SynthException
	{
		super( "Table_Lookup", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		amplitude = new SynthInput( this, "Amplitude" );
		tablePort = new SynthTablePort( this, "Table" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a WaveShaper that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public WaveShaper( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
