package com.softsynth.jsyn;
import java.util.*;
import java.net.URL;
import java.io.*;

/**
 * SynthSample that can load itself from a standard AIFF format file stream.
 *
 * @see ParseIFF
 * @see SynthSampleWAV
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthSampleAIFF extends SynthSample implements ChunkHandler
{
	static final int AIFF_ID = ('A'<<24) | ('I'<<16) | ('F'<<8) | 'F';
	static final int AIFC_ID = ('A'<<24) | ('I'<<16) | ('F'<<8) | 'C';
	static final int COMM_ID = ('C'<<24) | ('O'<<16) | ('M'<<8) | 'M';
	static final int SSND_ID = ('S'<<24) | ('S'<<16) | ('N'<<8) | 'D';
	static final int MARK_ID = ('M'<<24) | ('A'<<16) | ('R'<<8) | 'K';
	static final int INST_ID = ('I'<<24) | ('N'<<16) | ('S'<<8) | 'T';
	static final int NONE_ID = ('N'<<24) | ('O'<<16) | ('N'<<8) | 'E';

	ParseIFF       parser;
	
/** Create a sample by loading it from an AIFF file..
 * @param stream A stream that may come from a file or in memory byte array.
 * @exception SynthException	 If parsing fails, or there is insufficient memory.
* @exception IOException If parsing fails, or IO error occurs.
  */
	public SynthSampleAIFF( InputStream stream ) throws SynthException, IOException
	{
		load(stream);
	}
	public SynthSampleAIFF(  )
	{
		super();
	}
	
/** Load the sample data from the given stream and return it in an array of shorts.
 * 
 * @param stream May be any stream from a file, a URL, a byte array, etc.
 * @param ifLoadData If true, sample data will be loaded into memory.
 * @exception SynthException	 If parsing fails, or there is insufficient memory.
 * @exception IOException If parsing fails, or IO error occurs.
 */
	public short[] loadShorts( InputStream stream, boolean ifLoadData ) throws SynthException, IOException
	{
		short[] shortData = null;
		this.ifLoadData = ifLoadData;
		parser = new ParseIFF( stream );
		parser.parse( this );  // parser will call back to handleChunk() and handleForm()
		if( ifLoadData && (numFrames > 0) )
		{
			shortData = convertBigBytesToShorts();
		}
		parser = null;
		return shortData;
	}
	
	double read80BitFloat()  throws IOException
	{
/* This is not a full decoding of the 80 bit number but
 * it should suffice for the range we expect.
 */
		byte[] bytes = new byte[10];
		int numRead = parser.read( bytes );
		int exp = ((bytes[0] & 0x3F)<<8) | (bytes[1] & 0xFF);
		int mant = ((bytes[2]&0xFF)<<16) | ((bytes[3]&0xFF)<<8) | (bytes[4]&0xFF);
//		System.out.println( "exp = " + exp + ", mant = " + mant );
		return mant / (double) (1<<(22-exp));;
	}
	
	void parseCOMMChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		channelsPerFrame = parser.readShortBig();
		numFrames = parser.readIntBig();
		
		int bitsPerSample = parser.readShortBig();
		if( bitsPerSample != 16 )
				throw new IOException("Only 16 bit samples supported.");
		
		setSampleRate( read80BitFloat() );
		if( ckSize > 18 )
		{
			int format = parser.readIntBig();
			if( format != NONE_ID )
				throw new IOException("Compression not supported, format " + parser.IDToString(format) );
// FIXME Java1.1		throw new UnsupportedEncodingException("Compression not supported, format " + IDtoString(format) );
		}
	}
	
/* parse tuning and multi-sample info */
	void parseINSTChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		int pitch        = parser.readByte();
		int detune       = parser.readByte();
		setBaseFrequency( EqualTemperedTuning.getMIDIFrequency( pitch, detune) );
		pitch            = parser.readByte();
		setLowFrequency( EqualTemperedTuning.getMIDIFrequency( pitch ) );
		pitch            = parser.readByte();
		setHighFrequency( EqualTemperedTuning.getMIDIFrequency( pitch ) );
		parser.skip(2); /* lo,hi velocity */
		int gain         = parser.readShortBig();
		int playMode     = parser.readShortBig();  /* sustain */
		int beginID      = parser.readShortBig();
		int endID        = parser.readShortBig();
		setSustainLoop( findCuePosition( beginID ), findCuePosition( endID ) );
		playMode         = parser.readShortBig();  /* release */
		beginID          = parser.readShortBig();
		endID            = parser.readShortBig();
		setReleaseLoop( findCuePosition( beginID ), findCuePosition( endID ) );
	}
	
	void parseSSNDChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		long numRead;
//		System.out.println("parseSSNDChunk()");
		int offset = parser.readIntBig();
		parser.readIntBig(); /* blocksize */
		parser.skip( offset );
		dataPosition = parser.getOffset();
		int numBytes = ckSize - 8 - offset;
		if( ifLoadData )
		{
			byteData = new byte[numBytes];
			numRead = parser.read( byteData );
		}
		else
		{
			numRead = parser.skip( numBytes );
		}
		if( numRead != numBytes )
			throw new EOFException("AIFF data chunk too short!");
	}

	void parseMARKChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		int numCuePoints = parser.readShortBig();
		for( int i=0; i<numCuePoints; i++ )
		{
			int uniqueID = parser.readShortBig();
			int position = parser.readIntBig();
//			System.out.println("parseCueChunk: " + i + " : " + position + ", " + uniqueID );
			int len = parser.read();
			if( (len & 1) == 0 ) len++; /* pad so len plus chars is even */
			parser.skip(len);
			insertSortedCue( new CuePoint( position, uniqueID ) );
		}
	}
	
/** Called by parse() method to handle FORM chunks in an AIFF specific manner.
 * @param ckID four byte chunk ID such as 'data'
 * @param ckSize size of chunk in bytes
 * @exception IOException If parsing fails, or IO error occurs.
 */
	public void handleForm( ParseIFF parser, int ckID, int ckSize, int type )  throws IOException
	{
		if( (ckID == ParseIFF.FORM_ID) && (type != AIFF_ID) && (type != AIFC_ID) )
			throw new IOException("Bad AIFF form type = " + parser.IDToString(type) );
	}
	
/** Called by parse() method to handle chunks in an AIFF specific manner.
 * @param ckID four byte chunk ID such as 'data'
 * @param ckSize size of chunk in bytes
 * @exception IOException If parsing fails, or IO error occurs.
 */
	public void handleChunk( ParseIFF parser, int ckID, int ckSize )  throws IOException
	{
		switch( ckID )
		{
		case COMM_ID:
			parseCOMMChunk( parser, ckSize );
			break;
		case SSND_ID:
			parseSSNDChunk( parser, ckSize );
			break;
		case MARK_ID:
			parseMARKChunk( parser, ckSize );
			break;
		case INST_ID:
			parseINSTChunk( parser, ckSize );
			break;
		default:
			break;
		}
	}

}
