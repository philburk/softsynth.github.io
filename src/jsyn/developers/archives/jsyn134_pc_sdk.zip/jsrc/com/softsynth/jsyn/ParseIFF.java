
package com.softsynth.jsyn;
import java.util.*;
import java.io.*;
/**
 * Parse EA style IFF File
 * IFF is a file format that allows "chunks" of data to be placed
 * in a hierarchical file. It was designed by Jerry Morrison at
 * Electronic Arts for the Amiga computer and is now used extensively
 * by Apple Computer and other companies.
 *
 * @see ParseRIFF
 * @see SynthSampleAIFF
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
 
 public class ParseIFF
{
	InputStream stream;
	long  offset = 0;
	
	public static final int LIST_ID = ('L'<<24) | ('I'<<16) | ('S'<<8) | 'T';
	public static final int FORM_ID = ('F'<<24) | ('O'<<16) | ('R'<<8) | 'M';
	
	public ParseIFF( InputStream stream )
	{
		this.stream = stream;
		offset = 0;
	}
/** Since IFF files use chunks with explicit size, it is important to keep track
 * of how many bytes have been read from the file.
 * @return Number of bytes read from stream, or skipped.
 */
	long getOffset()
	{
		return offset;
	}
/** @return Next byte from stream. Increment offset by 1. */
	public int read()  throws IOException
	{
		offset++;
		return stream.read();
	}
/** @return Next byte array from stream. Increment offset by bar.length. */
	public int read( byte[] bar)  throws IOException
	{
		offset += bar.length;
		return stream.read( bar );
	}
	
/** @return Skip forward in stream and add numBytes to offset. */
	public  long skip( long numBytes )  throws IOException
	{
		offset += numBytes;
		return stream.skip( numBytes );
	}
	
/** Read 32 bit signed integer assuming Big Endian byte order. */
	public int readIntBig()  throws IOException
	{
		int result = read() & 0xFF;
		result = (result<<8) | (read()&0xFF);
		result = (result<<8) | (read()&0xFF);
		int data = read();
		if( data == -1 ) throw new EOFException();
		result = (result<<8) | (data&0xFF);
		return result;
	}
	
/** Read 16 bit signed short assuming Big Endian byte order. */
	public short readShortBig()  throws IOException
	{
		short result = (short) ((read() << 8));
		int data = read();
		if( data == -1 ) throw new EOFException();
		result |= data & 0xFF;
		return result;
	}
/** Read 32 bit signed integer assuming Little Endian byte order. */
	public int readIntLittle()  throws IOException
	{
		int result = read() & 0xFF;
		result |= ((read()&0xFF)<<8);
		result |= ((read()&0xFF)<<16);
		int data = read();
		if( data == -1 ) throw new EOFException();
		result |= (data<<24);
		return result;
	}
	
/** Read 16 bit signed short assuming Little Endian byte order. */
	public short readShortLittle()  throws IOException
	{
		short result = (short) (read() & 0xFF);
		int data = read();
		if( data == -1 ) throw new EOFException();
		result |= data<<8;
		return result;
	}
	
/** Read 8 bit signed byte. */
	public byte readByte()  throws IOException
	{
		return (byte) read();
	}
	
/** Read 32 bit signed int assuming IFF order. */
	public int readChunkSize()  throws IOException
	{
		return readIntBig();
	}
/** Convert a 4 character IFF ID to a String */
	public static String IDToString( int ID )
	{
		byte bar[] = new byte[4];
		bar[0] = (byte)(ID>>24);
		bar[1] = (byte)(ID>>16);
		bar[2] = (byte)(ID>>8);
		bar[3] = (byte) ID;
		return new String(bar, 0);
	}
	
/** Parse the stream and pass the forms and chunks to the ChunkHandler */
	public void parse( ChunkHandler handler )   throws IOException
	{
		int ID = readIntBig();
		int numBytes = readChunkSize();
		parseChunk( handler, ID, numBytes );
	}
	
/** Parse the FORM and pass the chunks to the ChunkHandler
 * The cursor should be positioned right after the type field.
 */
	void parseForm( ChunkHandler handler, int ID, int numBytes, int type )   throws IOException
	{
		while( numBytes > 0 )
		{
			int ckid = readIntBig();
			int size = readChunkSize();
			numBytes -= 8;
			if( size <= 0 )
				throw new IOException("Bad IFF format. " + IDToString(ckid) + ", Size = " + size);
			parseChunk( handler, ckid, size );
			if( (size & 1) == 1) size++;  // even-up
			numBytes -= size;
//			System.out.println("parseForm: numBytes = " + numBytes );
		}
	}
	
/** Does the following chunk ID correspond to a container type like FORM?
 */
	public boolean isForm( int ckid )   throws IOException
	{
		switch(ckid)
		{
		case LIST_ID:
		case FORM_ID:
			return true;
		default:
			return false;
		}
	}
	
/* Parse one chunk from IFF file. After calling handler, make sure stream is positioned
 * at end of chunk.
 */
	void parseChunk( ChunkHandler handler, int ckid, int numBytes )   throws IOException
	{
		long startOffset, endOffset;
		int numRead;
//		System.out.println("parseChunk( " + IDToString(ckid) + ", " + numBytes + " )");
		startOffset = getOffset();
		if( isForm( ckid ) )
		{
			int type = readIntBig();
//			System.out.println("parseChunk: form = " + IDToString(ckid) + ", " + numBytes + ", " + IDToString(type));
			handler.handleForm( this, ckid, numBytes - 4, type );
			endOffset = getOffset();
			numRead = (int)(endOffset - startOffset);
			if( numRead < numBytes ) parseForm( handler, ckid, (numBytes-numRead), type );
		}
		else
		{
			handler.handleChunk( this, ckid, numBytes );
		}
		endOffset = getOffset();
		numRead = (int)(endOffset - startOffset);
		if( (numBytes & 1) == 1) numBytes++;  // even-up
		if( numRead < numBytes ) skip( numBytes-numRead );
	}
		
}
