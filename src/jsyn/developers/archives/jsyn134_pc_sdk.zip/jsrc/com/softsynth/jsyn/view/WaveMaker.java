/**
 * Panel for harmonic synthesis of a wave table for JavaSynth
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
package com.softsynth.jsyn.view;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.util.*;

class HarmonicFader extends Panel
{
	Scrollbar    fader;
	Label        label;
	int          index;
	HarmonicTable    table;
	final static int range = 100;
	final static int halfRange = range/2;

	public HarmonicFader( HarmonicTable table, int index )
	{
		this.index = index;
		this.table = table;
		setLayout( new BorderLayout() );
		fader = new Scrollbar( Scrollbar.VERTICAL, range, 10, 0, range+10);
		add("Center",fader);
		label = new Label(Integer.toString(index + 1)); /* Zero is first harmonic. */
		add("South",label);
	}

/* Value can range from -1.0 to 1.0 which map to range and 0 respectively. */
	public void setValue( double val )
	{
		int ival = (int) ((double)halfRange - (val * (double)halfRange));
		fader.setValue(ival);
	}

	public boolean handleEvent(Event evt)
	{
		if( evt.target == fader )
		{
			int val = fader.getValue();
			table.setPartial( index, (double) (halfRange-val) / (double)halfRange );
			return true;
		}
		return super.handleEvent(evt);
    }
}

public class WaveMaker extends Panel
{
	HarmonicTable   table;
	HarmonicFader[] faders;
	int             numSamples;
	int             numPartials;
	public short[]  data;
	Button          buildButton;
	Button          sawButton;
	Button          squareButton;
	Button          clearButton;
	double          minVal = 0.0;
	double          maxVal = 0.0;
	WaveDisplay     display;

	public WaveMaker( HarmonicTable table, WaveDisplay display )
	{
		this.table = table;
		this.display = display;
		numSamples = table.length(); /* Assume includes guard point. */
		numPartials = table.getNumPartials();
		data       = new short[numSamples];
		faders     = new HarmonicFader[numPartials];

		setLayout( new GridLayout(1,0) );

		for( int i=0; i<numPartials; i++ )
		{
			faders[i] = new HarmonicFader( table, i );
			add( faders[i] );
		}

		add( buildButton = new Button("Build"));
		add( sawButton = new Button("Saw"));
		add( squareButton = new Button("Square"));
		add( clearButton = new Button("Clear"));
		table.clear();
		updateFaders();
	}

	void updateFaders()
	{
		for( int h=0; h<numPartials; h++ )
		{
			faders[h].setValue( table.getPartial(h) );
		}
	}

	public boolean action(Event evt, Object what)
	{
		if( evt.target == buildButton )
		{
			table.build();
			display.repaint();
			return true;
		}
		else if( evt.target == sawButton )
		{
			table.sawtooth();
			updateFaders();
			display.repaint();
			return true;
		}
		else if( evt.target == squareButton )
		{
			table.square();
			updateFaders();
			display.repaint();
			return true;
		}
		else if( evt.target == clearButton )
		{
			table.clear();
			updateFaders();
			display.repaint();
			return true;
		}
		return false;
    }
}
