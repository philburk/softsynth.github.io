package com.softsynth.jsyn;
import java.util.*;

/**
 *	Super class for other Filter, Delays, and other processing units.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 012
 * @see Synth
 * @see SynthUnit
 * @see Filter_1o1z
 * @see Filter_1o1p1z
 * @see Filter_2o2p
 * @see Filter_2o2p2z
 * @see StateVariableFilter
 */

public class SynthFilter extends SynthUnit 
{
/** Signal to be filtered. SIGNAL_TYPE_RAW_SIGNED */
	public SynthInput input;
/** Filtered signal. SIGNAL_TYPE_RAW_SIGNED */
	public SynthOutput output;

 	public SynthFilter( String unitName, int calculationRate, int param ) throws SynthException
	{
		super( unitName, calculationRate, param );
		input = new SynthInput( this, "Input" );
		output = new SynthOutput( this, "Output" );
	}
}
