package com.softsynth.jsyn;
import java.util.*;

/**
 *	Filter_2o2p2z unit.
Second Order, Two Pole, Two Zero filter using the following formula: <P>
<PRE>
     y(n) = 2.0 * (A0*x(n) + A1*x(n-1)  + A2*x(n-2) - B1*y(n-1)  - B2*y(n-2))
</PRE><P>

where y(n) is Output, x(n) is Input, x(n-1) is a delayed copy of the input,
and y(n-1) is a delayed copy of the output. 
<P>
This filter is a recursive IIR or Infinite Impulse Response filter.
it can be unstable depending on the values of the coefficients.
<P>
A thorough description of the digital filter theory needed to fully describe this filter is beyond the scope of this 
document. 
Calculating coefficients is non-intuitive; the interested user is referred to one of the standard texts on filter theory 
(e.g., Moore, "Elements of Computer Music", section 2.4).
<P>
Special thanks to Robert Bristow-Johnson for contributing his filter equations to the music-dsp list.
They were used for the lowPass, highPass, and bandPass calculations.

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 011
 * @see Synth
 * @see SynthUnit
 * @see Filter_1o1z
 * @see Filter_1o1p
 * @see Filter_2o2p
 * @see Filter_1o1p1z
 * @see StateVariableFilter
 */

public class Filter_2o2p2z extends SynthFilter 
{
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A0;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A1;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable A2;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable B1;
/** Filter coefficient. SIGNAL_TYPE_RAW_SIGNED, default = 0.0. */
	public SynthVariable B2;

	double           omega = 0.0;
	double           cs = 0.0;
	double           sn = 0.0;
	double           Q = 0.0;
	double           alpha = 0.0;

 	public Filter_2o2p2z( int calculationRate ) throws SynthException
	{
		super( "Filter_2o2p2z", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		A0 = new SynthVariable( this, "A0" );
		A1 = new SynthVariable( this, "A1" );
		A2 = new SynthVariable( this, "A2" );
		B1 = new SynthVariable( this, "B1" );
		B2 = new SynthVariable( this, "B2" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public Filter_2o2p2z( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}

	double sinh( double x )
	{
		return (0.5 * (Math.exp(x) - Math.exp(-x)));
	}


	void calcCommon( double freq, double bandwidth )
	{
		double ratio = freq / Synth.getFrameRate();
		if( ratio >= 0.499 ) ratio = 0.499; /* Don't get close to Nyquist because it will blow up. */
		omega = 2.0 * Math.PI * ratio;
		cs = Math.cos( omega );
		sn = Math.sin( omega );
		Q = sn / (Math.log(2.0) * bandwidth * omega );
		alpha = sn * sinh( 0.5 / Q );
	}

/*    y[n] = (c0/d0)*x[n] + (c1/d0)*x[n-1] + (c2/d0)*x[n-2] - (d1/d0)*y[n-1] - (d2/d0)*y[n-2] */
/**
 * Set coefficients of filter for Low Pass operation.
 * Frequencies below the given frequency parameter will be passed.
 * Frequencies above will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Cutoff frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking 
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void lowPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double d0 =  1.0 + alpha;
		double temp = 0.5 / d0;
		double c1 = (1.0 - cs);
		double A0_A2_Value = c1 * 0.5 * temp;
		A0.set( time, A0_A2_Value );
		A1.set( time, c1 * temp );
		A2.set( time, A0_A2_Value );
		B1.set( time, -2.0 * cs * temp );
		B2.set( time, (1.0 - alpha) * temp );
	}

/**
 * Set coefficients of filter for High Pass operation.
 * Frequencies above the given frequency parameter will be passed.
 * Frequencies below will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Cutoff frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking 
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void highPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double d0 =  1.0 + alpha;
		double temp = 0.5 / d0;
		double ct = (1.0 + cs);
		double A0_A2_Value = ct * 0.5 * temp;
		A0.set( time, A0_A2_Value );
		A1.set( time, -ct * temp );
		A2.set( time, A0_A2_Value );
		B1.set( time, -2.0 * cs * temp );
		B2.set( time, (1.0 - alpha) * temp );
	}

/**
 * Set coefficients of filter for Band Pass operation.
 * Frequencies near the given frequency parameter will be passed.
 * Frequencies above and below will be cut off to varying degrees.
 *
 * @param time Time at which to set ports..
 * @param frequency Center frequency in Hertz.
 * @param bandwidth Bandwidth in octaves (between midpoint (dBgain/2) gain frequencies for peaking 
 *      or between -3 dB frequencies for BPF and notch).
 * @exception SynthException	  If port setting fails.
 */
	public void bandPass( int time, double frequency, double bandwidth ) throws SynthException
	{
		calcCommon( frequency, bandwidth );

		double d0 =  1.0 + alpha;
		double temp = 0.5 / d0;
		A0.set( time, alpha * temp );
		A1.set( time, 0.0 );
		A2.set( time, -alpha * temp );
		B1.set( time, -2.0 * cs * temp );
		B2.set( time, (1.0 - alpha) * temp );
	}

	public void lowPass( double frequency, double bandwidth ) throws SynthException
	{
		lowPass( Synth.getTickCount(), frequency, bandwidth );
	}
	public void highPass( double frequency, double bandwidth ) throws SynthException
	{
		highPass( Synth.getTickCount(), frequency, bandwidth );
	}
	public void bandPass( double frequency, double bandwidth ) throws SynthException
	{
		bandPass( Synth.getTickCount(), frequency, bandwidth );
	}
}
