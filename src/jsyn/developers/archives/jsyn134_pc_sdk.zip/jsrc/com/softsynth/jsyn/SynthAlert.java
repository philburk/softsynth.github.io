package com.softsynth.jsyn;
import java.util.*;
import java.awt.*;

/**
 * SynthAlert class to display error messages from JSyn.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthAlert extends Dialog
{
	TextArea textArea;
	Button   okButton;
	Button   abortButton;
	static   Exception  excp = null;
	static   Frame  topFrame;
	
	public SynthAlert( Frame frame )
	{
		super( frame, "Message from JSyn.", true );
		setLayout( new BorderLayout() );
		resize( 600, 200 );
		textArea = new TextArea( 6, 80 );
		add( "Center", textArea );
		Panel panel = new Panel();
		add( "South", panel );
		panel.add( okButton = new Button("Continue") );
		panel.add( abortButton = new Button("Abort") );
	}

	public static Frame getFrame( Component c )
	{
		do
		{
			if(c instanceof Frame) return (Frame)c;
		} while((c = c.getParent()) != null);
		return null;
	}

/** Set Frame to be used for future error messages by passing a component.
** The component hierarchy will be searched up to find the first Frame
** containing the component.
*/
	public static void setFrame( Component c )
	{
		topFrame = getFrame( c );
	}
	
	public static void showError( Component c, String text )
	{
		Frame frame = null;
		
		if( c == null ) frame = topFrame;
		else frame = SynthAlert.getFrame(c);

		if( frame != null )
		{
			SynthAlert alert = new SynthAlert( frame );
			alert.showMessage( text );
		}
		else
		{
			System.err.println( text );
		}
	}

	public static void showError( Component c, Exception e )
	{
		excp = e;
		SynthAlert.showError( c, e.toString() );
	}

	public static void showError( String text )
	{
		showError( null, text );
	}
	
	public static void showError( Exception e )
	{
		excp = e;
		showError( null, e );
	}
	public void showMessage( String text )
	{
		textArea.selectAll();
		textArea.replaceText( text, textArea.getSelectionStart(), textArea.getSelectionEnd() );
		show();
	}

	public boolean action(Event evt, Object arg)
	{
		if( evt.target == okButton )
		{
			dispose();
			return true;
		}
		else if( evt.target == abortButton )
		{
			dispose();
			if( excp != null) excp.printStackTrace();
			System.exit(1);
			return true;
		}
		return false;
	}

}