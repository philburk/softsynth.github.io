
package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
/**
 * Implement plucked string algorithm using JSyn
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class PluckedString extends SynthNote
{
	SampleReader_16V1       myPluckPlayer;
	InterpolatingDelayUnit  myDelay;
	Filter_1o1z             myAverager;
	MultiplyAddUnit         myFeedback;
	
	public SynthInput  rate;
	public SynthInput  pluckStrength;
	public SynthInput  feedback;
	public SynthInput  delay;
	PluckSample myPluckSample;
	final static int PLUCK_SIZE = 300;
	
	public PluckedString() throws SynthException
	{
		this( 1.0 / 100.0 ); /* Period for lowest note. */
	}
	public PluckedString( double delayTime ) throws SynthException
	{
		super();
/* Create subunits. */
		add( myPluckPlayer = new SampleReader_16V1());
		add( myDelay       = new InterpolatingDelayUnit(delayTime));
		add( myAverager    = new Filter_1o1z());
		add( myFeedback    = new MultiplyAddUnit());
/* Fill a sample with random pluck contour. */
		myPluckSample = new PluckSample( PLUCK_SIZE );
		myPluckSample.fill();
		myDelay.output.connect( myAverager.input );
		myAverager.output.connect( myFeedback.inputA );
		myPluckPlayer.output.connect( myFeedback.inputC );
		myFeedback.output.connect( myDelay.input );
/* Make some ports appear as if they were part of a PluckedString. */
		addPort( rate = myPluckPlayer.rate );
		addPort( pluckStrength = myPluckPlayer.amplitude, "PluckStrength" );
		addPort( feedback = myFeedback.inputB, "Feedback" );
		addPort( delay = myDelay.delay );
		addPort( output = myFeedback.output );
		
		rate.setup( 0.0, 20000.0, 60000.0 );
		pluckStrength.setup( 0.0, 0.5, 1.0 );
// Use negative feedback to lower sound an octave. Should we do this???
		feedback.setup( -1.0, -0.999, -0.90 );
		delay.setup( 0.0, delayTime/2, delayTime );
		
	}
	public void pluck()
	throws SynthException
	{
		setStage( Synth.getTickCount(), 0 );
	}
	
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0: 
			myPluckPlayer.samplePort.queue( time, myPluckSample );
			break;
		default:
			break;
		}
	}
}
