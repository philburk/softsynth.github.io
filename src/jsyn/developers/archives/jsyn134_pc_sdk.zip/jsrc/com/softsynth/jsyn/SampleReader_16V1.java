package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleReader_16V1 unit.
Variable-rate monophonic 16-bit sample player.

<P>This unit is limited to a pitch one octave above base pitch, if recorded
at 44.1 kHz. If it is recorded at 22 kHz, the pitch can go two octaves
up.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SampleReader_16V1 extends SampleReader 
{
/** Sample Rate in Hertz. Range is 0.0 to 2.0*Synth.getFrameRate(), typically 88200.0.
	Default is 2.0*Synth.getFrameRate(), typically 44100.0.	*/
	public SynthInput rate;

 	public SampleReader_16V1( int calculationRate ) throws SynthException
	{
		super( "Sample_Read16V1", calculationRate );
		rate = new SynthInput( this, "Rate" );
	}
/**
 *	Create a SampleReader_16V1 that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SampleReader_16V1( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
