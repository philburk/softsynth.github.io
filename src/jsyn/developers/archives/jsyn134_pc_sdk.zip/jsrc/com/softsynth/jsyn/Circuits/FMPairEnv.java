package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/**     FM Pair with Amplitude Envelopes on Modulator and Carrier.
        Based on Andrew Gram's FMCircuit.
*/

public class FMPairEnv extends FMPair
{
	public SynthEnvelope        modAmpEnv;
	EnvelopePlayer              modEnvPlayer;
	public SynthEnvelope        amplitudeEnv;
	EnvelopePlayer              carEnvPlayer;
	public SynthEnvelopeQueue   modAmpEnvPort;
	public SynthEnvelopeQueue   amplitudeEnvPort;

	void makeCircuit()
	{
		super.makeCircuit();
		
/* Add SynthUnits to circuit */
		add(modEnvPlayer = new EnvelopePlayer());
		add(carEnvPlayer = new EnvelopePlayer());

/* Connect units together. */
		modEnvPlayer.output.connect(modOsc.amplitude);
		carEnvPlayer.output.connect(carOsc.amplitude);
                
/* Override existing ports. */
		modAmplitude = modEnvPlayer.amplitude;
		amplitude = carEnvPlayer.amplitude;

		modAmpEnvPort = modEnvPlayer.envelopePort;
		amplitudeEnvPort = carEnvPlayer.envelopePort;
		
/* Set signal types for more conveniant control. */
		modAmplitude.setSignalType(Synth.SIGNAL_TYPE_OSC_FREQ); // so we can set modulation range in Hz

/* Set default envelopes. */
		double[] data =
		{
			0.05, 1.0,  /* duration,value pair for frame[0] */
			0.30, 0.2,  /* duration,value pair for frame[1] */
			0.30, 0.0   /* duration,value pair for frame[2] */
		};
		modAmpEnv = new SynthEnvelope( data );
		amplitudeEnv = new SynthEnvelope( data );
		
/* Set ports to useful values and ranges. */
		modAmplitude.setup(   0.0, 500.0, 10000.0 );
		amplitude.setup(   0.0, 0.5, 1.0 );
    }

/* Do addPorts in separate method so we can override port assignments. */
	void addAllPorts()
	{
		super.addAllPorts();
		addPort( modAmpEnvPort, "modAmpEnv" );
		addPort( amplitudeEnvPort, "amplitudeEnv" );
	}
	
/** Define a behavior for setStage(). This is a flexible way to do something like ON/OFF
 * control of a circuit.
 */
	public void setStage( int time, int stage )
	throws SynthException
	{
		if( stage == 0 )
		{
			modAmpEnvPort.clear( time );
			modAmpEnvPort.queue( time, modAmpEnv );
			amplitudeEnvPort.clear( time );
			amplitudeEnvPort.queue( time, amplitudeEnv );
		}
	}

}
