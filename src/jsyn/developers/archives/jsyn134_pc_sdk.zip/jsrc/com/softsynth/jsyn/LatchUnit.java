package com.softsynth.jsyn;
import java.util.*;

/**
 *	LatchUnit unit.
 <P>
 Pass a value unchanged if gate true, otherwise output held value.
 <P>
 output = ( gate > 0.0 ) ? input : previous_output;
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 006
 * @see MinimumUnit
 */

public class LatchUnit extends SynthUnit 
{
	public SynthInput input;
	public SynthInput gate;
	public SynthOutput output;

 	public LatchUnit( int calculationRate ) throws SynthException
	{
		super( "Logic_Latch", calculationRate );
		input = new SynthInput( this, "Input" );
		gate = new SynthInput( this, "Gate" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public LatchUnit( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
