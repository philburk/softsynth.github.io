package com.softsynth.jsyn;
import java.util.*;

/**
 * Output approaches Input linearly. 
 * This unit provides a slowly changing value that approaches its input value linearly. 
 * <P>
 * When you
 * change the value of the input port, the ramp will start changing from
 * its current output value toward the value of input. An internal phase
 * value will go from 0.0 to 1.0 at a rate controlled by time. When the internal
 * phase reaches 1.0, the output will equal input.
 * <P>
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see ExponentialLag
 */

public class LinearLag extends SynthUnit 
{
/** Time in seconds to reach new value. SIGNAL_TYPE_TIME */
	public SynthVariable time;
/** Target value. Time is reset whenever input changes. Note: not connectable. SIGNAL_TYPE_RAW_SIGNED
 */
	public SynthVariable input;
	public SynthOutput output;

 	public LinearLag( int calculationRate ) throws SynthException
	{
		super( "Lag_Linear", calculationRate, 0 );
		time = new SynthVariable( this, "Time" );
		input = new SynthVariable( this, "Input" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a LinearLag that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public LinearLag( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
