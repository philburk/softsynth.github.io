package com.softsynth.jsyn;
import java.util.*;

/**
 *	WhiteNoise unit.
 *
 * This unit uses a pseudo-random number generator to produce white noise.
 * A new random number is generated every frame.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see RedNoise
 */

public class WhiteNoise extends SynthUnit 
{
	public SynthInput amplitude;
	public SynthOutput output;

 	public WhiteNoise( int calculationRate ) throws SynthException
	{
		super( "Noise_White", calculationRate, 0 );
		amplitude = new SynthInput( this, "Amplitude" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public WhiteNoise( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
