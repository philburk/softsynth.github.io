package com.softsynth.jsyn;
import java.util.*;

/**
 *	Root class for various oscillators.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 012
 * @see Synth
 * @see SynthChannelData
 */

public class SynthOscillator extends SynthUnit 
{
/** Oscillator frequency in Hertz. Range is +/- sample rate. Default is 440.0. */
	public SynthInput frequency;
	public SynthInput amplitude;
/** Phase of oscillator. Range is -1.0 to +1.0.
 */
	public SynthVariable phase;
	public SynthOutput output;
	
 	public SynthOscillator( String unitName, int calculationRate, int param ) throws SynthException
	{
		super( unitName, calculationRate, param );
		frequency = new SynthInput( this, "Frequency" );
		amplitude = new SynthInput( this, "Amplitude" );
		phase = new SynthVariable( this, "Phase" );
		output = new SynthOutput( this, "Output" );
	}
}
