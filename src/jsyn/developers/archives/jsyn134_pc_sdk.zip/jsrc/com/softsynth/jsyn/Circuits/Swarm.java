package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Swarm
 *
 *   Each element of swarm contains an ExponentialLag connected to the
 *   Frequency of an oscillator. The half lives and target values of the
 *   lags are slightly different.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */


public class Swarm extends SynthNote
{
	final static int    NUM_ELEMENTS = 10;
	ExponentialLag[]    lags;
	TriangleOscillator[]    sines;
	BusWriter[]         mixers;
	BusReader           reader;
	MultiplyUnit        myScalar;
	MultiplyAddUnit     myOffsetter;
	MultiplyUnit        amplPlug;  // scale and fanout input amplitude
	
/*
 * Setup synthesis.
 */
	public Swarm()  throws SynthException
	{
		super();
		
		lags = new ExponentialLag[NUM_ELEMENTS];
		sines = new TriangleOscillator[NUM_ELEMENTS];
		mixers = new BusWriter[NUM_ELEMENTS];
		
/* Create various unit generators and add them to circuit. */
		add( reader = new BusReader() );
		add( amplPlug = new MultiplyUnit() );

/* Create SynthDistributors for signals which fan-out inside circuit. */
		frequency = new SynthDistributor( this, "frequency", Synth.SIGNAL_TYPE_SVF_FREQ  );

		for( int i=0; i<NUM_ELEMENTS; i++ )
		{
			add( sines[i] = new TriangleOscillator() );
			add( lags[i] = new ExponentialLag() );
			add( mixers[i] = new BusWriter() );
			
			lags[i].halfLife.set( 0.1 + (0.02*i) );

			frequency.connect( lags[i].input );
			amplPlug.output.connect( sines[i].amplitude );
			lags[i].output.connect( sines[i].frequency );
			sines[i].output.connect( mixers[i].input );
			mixers[i].busOutput.connect( reader.busInput );
		}

/* Make ports on internal units appear as ports on circuit. */ 
/* Give some circuit ports more meaningful names. */
		addPort( amplitude = amplPlug.inputA, "amplitude" );
		addPort( output = reader.output );

		amplPlug.inputB.set( 1.0 / NUM_ELEMENTS );
		
/* Set ports to useful values and ranges. */
		amplitude.setup(   0.0, 0.3, 0.999 );
		frequency.setup(   0.0, 800.0, 3000.0 );
	}
	
	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0:
			stop( time );
				
			start( time );
			break;
		}
	}
}

