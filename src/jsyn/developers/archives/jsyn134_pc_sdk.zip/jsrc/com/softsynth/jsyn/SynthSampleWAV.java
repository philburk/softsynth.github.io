package com.softsynth.jsyn;
import java.util.*;
import java.io.*;

/**
 * Sample that can load itself from a standard WAV format file.
 *
 * @see ParseRIFF
 * @see SynthSampleAIFF
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class SynthSampleWAV extends SynthSample implements ChunkHandler
{
	static final short WAVE_FORMAT_PCM = 1;
	static final int WAVE_ID = ('W'<<24) | ('A'<<16) | ('V'<<8) | 'E';
	static final int FMT_ID = ('f'<<24) | ('m'<<16) | ('t'<<8) | ' ';
	static final int DATA_ID = ('d'<<24) | ('a'<<16) | ('t'<<8) | 'a';
	static final int CUE_ID = ('c'<<24) | ('u'<<16) | ('e'<<8) | ' ';

	ParseRIFF       parser;

/** Create a WAV parser.
 * @param stream A stream that may come from a file or in memory byte array.
 * @exception SynthException If parsing fails, or insufficient memory.
 * @exception IOException If parsing fails, or IO error occurs.
 */
	public SynthSampleWAV( InputStream stream ) throws SynthException, IOException
	{
		load(stream);
	}
	public SynthSampleWAV()
	{
		super();
	}

/** Load the sample data from the given stream and return it in an array of shorts.
 * 
 * @param stream May be any stream from a file, a URL, a byte array, etc.
 * @param ifLoadData If true, sample data will be loaded into memory.
 * @exception SynthException	 If parsing fails, or there is insufficient memory.
 * @exception IOException If parsing fails, or IO error occurs.
 */
	public short[] loadShorts( InputStream stream, boolean ifLoadData ) throws SynthException, IOException
	{
		short[] shortData = null;
		this.ifLoadData = ifLoadData;
		parser = new ParseRIFF( stream ); // RIFF not IFF
		parser.parse( this );  // parser will call back to handleChunk() and handleForm()
		if( ifLoadData && (numFrames > 0) )
		{
			shortData = convertLittleBytesToShorts();  // LITTLE not BIG
		}
		parser = null;
		return shortData;
	}
	
/* Set Sustain Loop by assuming first two markers are loop points. */
	void setLoopPoints()
	{
		if( cuePoints != null )
		{
			if( cuePoints.size() >= 2 )
			{
				setSustainLoop( ((CuePoint)cuePoints.elementAt(0)).getPosition(),
					((CuePoint)cuePoints.elementAt(1)).getPosition() );
			}
		}
	}
	
/* Parse various chunks encountered in WAV file. */
	void parseCueChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		int numCuePoints = parser.readIntLittle();
		if( (ckSize - 4) != (6*4*numCuePoints) )
				throw new EOFException("Cue chunk too short!");
		for( int i=0; i<numCuePoints; i++ )
		{
			int uniqueID = parser.readIntLittle(); /* dwName */
			int position = parser.readIntLittle();
			System.out.println("parseCueChunk: " + i + " : " + position + ", " + uniqueID );
			parser.skip(4*4); /* dwName */
			insertSortedCue( new CuePoint( position, uniqueID ) );
		}
		setLoopPoints();
	}
			
	void parseFmtChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		int format = parser.readShortLittle();
		if( format != WAVE_FORMAT_PCM )
			throw new IOException("Only WAVE_FORMAT_PCM supported, not " + format);
// FIXME Java1.1		throw new UnsupportedEncodingException("Only WAVE_FORMAT_PCM supported, not " + format);
		channelsPerFrame = parser.readShortLittle();
		setSampleRate( (double) parser.readIntLittle() );
		parser.readIntLittle(); /* skip dwAvgBytesPerSec */
		int bytesPerSample = parser.readShortLittle();
		int bitsPerSample = parser.readShortLittle();
		if( bitsPerSample != 16 )
				throw new IOException("Only 16 bit samples supported.");
	}
	
	void parseDataChunk( ParseIFF parser, int ckSize )  throws IOException
	{
		long numRead;
		System.out.println("parseDataChunk()");
		dataPosition = parser.getOffset();
		if( ifLoadData )
		{
			byteData = new byte[ckSize];
			numRead = parser.read( byteData );
		}
		else
		{
			numRead = parser.skip( ckSize );
		}
		if( numRead != ckSize )
			throw new EOFException("WAV data chunk too short!");
/* Convert little endian bytes to shorts. */
		int numSamples = ckSize /  2;
		numFrames = numSamples / channelsPerFrame;
	}
	
	public void handleForm( ParseIFF parser, int ckID, int ckSize, int type )  throws IOException
	{
		if( (ckID == ParseRIFF.RIFF_ID) && (type != WAVE_ID) )
			throw new IOException("Bad WAV form type = " + parser.IDToString(type) );
	}

/** Called by parse() method to handle chunks in a WAV specific manner.
 * @param ckID four byte chunk ID such as 'data'
 * @param ckSize size of chunk in bytes
 * @return number of bytes left in chunk
*/
	public void handleChunk( ParseIFF parser, int ckID, int ckSize )  throws IOException
	{
		switch( ckID )
		{
		case FMT_ID:
			parseFmtChunk( parser, ckSize );
			break;
		case DATA_ID:
			parseDataChunk( parser, ckSize );
			break;
		case CUE_ID:
			parseCueChunk( parser, ckSize );
			break;
		default:
			break;
		}
	}
}
