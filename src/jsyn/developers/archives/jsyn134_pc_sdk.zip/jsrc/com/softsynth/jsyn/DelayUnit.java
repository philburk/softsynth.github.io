package com.softsynth.jsyn;
import java.util.*;

/**
 *	DelayUnit unit.
 <P>
 DelayUnit provides a simple time delay with an input and output.
 The internal data format is the same resolution as a SynthTable which is
 floating point if the sound processor supports it.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see SynthChannelData
 * @see SampleWriter_16F1
 */

public class DelayUnit extends SynthFilter
{
 	public DelayUnit( int calculationRate, double delayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		super( "Delay_Basic", calculationRate, (int) (0.5 + (delayTime * Synth.getFrameRate())) );
	}
/**
 *	Create a DelayUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If delayTime negative or exceeds memory.
 */
 	public DelayUnit( double delayTime ) throws SynthException
	{
		this( Synth.RATE_AUDIO, delayTime );
	}
}
