package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * ParabolicEnvelope modulating a sine wave. This can be used as the basis for granular synthesis.
 * 
 * @see TJ_Grains
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class ParabolicGrain extends SynthNote
{
	public SineOscillator      sineOsc;
	public ParabolicEnvelope   parabola;
	public LatchUnit           freqLatch;

/* Declare ports. */
	public SynthInput  rate;
	public SynthInput  triggerInput;
	public SynthOutput triggerOutput;
	public SynthOutput triggerPass;

/*
 * Setup synthesis.
 */
	public ParabolicGrain()  throws SynthException
	{
		super();

/* Create various unit generators and add them to circuit. */
		add( sineOsc = new SineOscillator() );
		add( parabola = new ParabolicEnvelope() );
		add( freqLatch = new LatchUnit() );

/* Connect SynthUnits to make signal path. */
		parabola.output.connect( sineOsc.amplitude );
		parabola.triggerOutput.connect( freqLatch.gate );
		freqLatch.output.connect( sineOsc.frequency );

/* Make ports on internal units appear as ports on circuit. */ 
		addPort( frequency = freqLatch.input );
		addPort( rate = parabola.frequency, "Rate" );
		addPort( amplitude = parabola.amplitude );
		addPort( triggerInput = parabola.triggerInput );
		addPort( triggerOutput = parabola.triggerOutput );
		addPort( triggerPass = parabola.triggerPass );
		addPort( output = sineOsc.output );

/* Set signal type for frequency control so that we can operate in hertz. */
		frequency.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ );
	}

}

