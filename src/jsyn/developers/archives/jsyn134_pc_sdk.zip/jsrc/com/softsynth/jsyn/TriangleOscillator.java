package com.softsynth.jsyn;
import java.util.*;

/**
 *	TriangleOscillator unit. The waves it produces looks like: /\/\/\ .
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class TriangleOscillator extends SynthOscillator
{
 	public TriangleOscillator( int calculationRate ) throws SynthException
	{
		super( "Osc_Triangle", calculationRate, 0 );
	}
/**
 *	Create a TriangleOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public TriangleOscillator( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
