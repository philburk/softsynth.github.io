package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleWriter_16F2 unit.
 * This unit writes two channels of input to a sample.
 * It can be used to capture a stereo recording of a performance.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 013
 * @see Synth
 * @see SynthChannelData
 */

public class SampleWriter_16F2 extends SynthUnit 
{
	public SynthInput input;
	public SynthSampleQueue samplePort;

 	public SampleWriter_16F2( int calculationRate ) throws SynthException
	{
		super( "Sample_Write16F2", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		samplePort = new SynthSampleQueue( this );
	}
/**
 *	Create a SampleWriter_16F2 that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SampleWriter_16F2( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
