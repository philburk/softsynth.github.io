package com.softsynth.jsyn;
import java.util.*;

/**
 *	EnvelopePlayer unit.
<P>
EnvelopePlayer will play blocks of multi-segment envelope data.  Blocks are queued
to the envelope using SynthEnvelopeQueue.queue()
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthEnvelope
 * @see SynthEnvelopeQueue
 */

public class EnvelopePlayer extends SynthUnit 
{
	public SynthInput rate;
	public SynthInput amplitude;
	public SynthEnvelopeQueue envelopePort;
	public SynthOutput output;

 	public EnvelopePlayer( int calculationRate ) throws SynthException
	{
		super( "Envelope_Segmented", calculationRate, 0 );
		rate = new SynthInput( this, "Rate" );
		amplitude = new SynthInput( this, "Amplitude" );
		envelopePort = new SynthEnvelopeQueue( this );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
 	public EnvelopePlayer( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
