package com.softsynth.jsyn;
import java.util.*;

/**
 *	MultiplyUnsignedUnit unit.
 *  Inputs are unsigned, output is unsigned and clipped between 0.0 and 2.0.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JavaSynth Version 005
 * @see MultiplyAddUnit
 * @see MultiplyUnsignedUnit
 */

public class MultiplyUnsignedUnit extends SynthUnit 
{
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthInput inputA;
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthInput inputB;
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthOutput output;

 	public MultiplyUnsignedUnit( int calculationRate ) throws SynthException
	{
		super( "Math_MultiplyUnsigned", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public MultiplyUnsignedUnit( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
