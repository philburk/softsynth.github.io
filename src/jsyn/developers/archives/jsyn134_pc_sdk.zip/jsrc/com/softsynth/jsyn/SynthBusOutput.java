package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthBusOutput port that can connect to one SynthBusInputs
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see SynthBusInput
 * @see BusReader
 */

public class SynthBusOutput extends SynthPort
{

	SynthBusOutput( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}

/**	
 *	Connect SynthBusOutput port to a SynthBusInput port of another instrument.
 *  Each port can have multiple indexed parts.
 *
 * @exception SynthException	If index out of range,
 *            or already connected, or connection attempted to non-bus signal.
 */
	public void connect( int outIndex, SynthBusInput inPort, int inIndex ) throws SynthException
	{
		super.connectUnits( this, outIndex, inPort, inIndex );
	}

	public void connect( SynthBusInput inPort ) throws SynthException
	{
		connect( 0, inPort, 0 );
	}

}
