
package JSynExamples;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view102.*;

/**
 * Play with a Pulse oscillator being modulated by an LFO.
 * Change PulseWidth to change timbre.
 *
 * @author Phil Burk
 * (C) 1997 Phil Burk
 */

public class TJ_PulseFader extends Applet
{
	PulseOscillator myOsc;
	LineOut             myOut;
	TriangleOscillator  myLFO;
	AddUnit             mySum;
	SynthScope          scope;

/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_PulseFader applet = new TJ_PulseFader();
		AppletFrame frame = new AppletFrame("Test Java Synthesis", applet);
		frame.resize(400,300);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{
		setLayout( new GridLayout(0,1) );
		
		try
		{
/* Start synthesis engine. */
		Synth.startEngine( 0 );

/* Make a waveform unit generators. */
		myOsc = new PulseOscillator();
		myLFO = new TriangleOscillator();
		mySum = new AddUnit();
		myOut = new LineOut();

/* Connect oscillator to left channel of stereo player. */
		myLFO.output.connect( mySum.inputA );
		mySum.output.connect( myOsc.frequency );
		myOsc.output.connect( 0, myOut.input, 0 );
		myOsc.output.connect( 0, myOut.input, 1 );

/* Change port types for user friendly units. */
		mySum.inputB.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ );
		myLFO.amplitude.setSignalType( Synth.SIGNAL_TYPE_OSC_FREQ );

		add( new PortFader( myOsc.amplitude, 0.5, 0.0, 0.999 ) );
		add( new PortFader( myOsc.width, "PulseWidth", 0.0, -1.0, 1.0 ) );
		add( new PortFader( myLFO.frequency, "ModRate", 3.0, 0.0, 20.0 ) );
		add( new PortFader( myLFO.amplitude, "ModDepth", 300.0, 0.0, 1000.0 ) );
		add( new PortFader( mySum.inputB, "CenterFreq", 400.0, 0.0, 1000.0 ) );

/* Create an oscilloscope to show oscillator and LFO output. */
//		scope = new SynthScope( frame );
//		scope.createProbe( myOsc.output, "Osc", Color.yellow );
//		scope.createProbe( myLFO.output, "LFO", Color.red );
//		scope.createProbe( mySum.output, "Freq", Color.green );
//      scope.finish();
//		scope.show();

/* Start execution of units. */
		myOut.start();
		myOsc.start();
		mySum.start();
		myLFO.start();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	
		getParent().validate();
		getToolkit().sync();
	}

	public void stop()
	{
		try
		{
/* Stop execution of units. */
			myOsc.delete();
			myOsc = null;
			myLFO.delete();
			myLFO = null;
			mySum.delete();
			mySum = null;
			myOut.delete();
			myOut = null;
			removeAll(); // remove portFaders
/* Turn off tracing. */
			Synth.verbosity = Synth.SILENT;
/* Stop synthesis engine. */
			Synth.stopEngine();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
}
