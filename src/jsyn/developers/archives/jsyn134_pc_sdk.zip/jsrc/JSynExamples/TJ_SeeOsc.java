package JSynExamples;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view102.*;
import com.softsynth.jsyn.circuits.*;

/**
 * See many oscillator's waveforms.
 *
 * @author Phil Burk
 * (C) 1997 Phil Burk
 */

public class TJ_SeeOsc extends Applet
{
	LineOut            myOut;
	SynthDistributor   frequency;
	MultiplyUnit       myAmp;
	SynthScope         scope;
	PortFader          freqFader;
	PortFader          ampFader;
	Checkbox[]         sourceBoxes;
	Vector             sounds;
	Vector             names;
	Panel              cboxPanel;
	SynthOscillator    previous = null;
	
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_SeeOsc applet = new TJ_SeeOsc();
		AppletFrame frame = new AppletFrame("See Osc Waveforms", applet);
		frame.resize(500,500);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}
	
	void makeCBoxPanel( )
	{
		cboxPanel = new Panel();
		cboxPanel.setLayout( new GridLayout( 1, 0 ) );
		CheckboxGroup cbg = new CheckboxGroup();
		sourceBoxes = new Checkbox[sounds.size()];
		for( int i=0; i<sourceBoxes.length; i++ )
		{
			cboxPanel.add(sourceBoxes[i] = new Checkbox((String)names.elementAt( i ), cbg, (i==0) ));
		}
	}

	void useNthSound( int soundIndex ) throws SynthException
	{
		if( previous != null ) previous.stop();
		SynthOscillator osc = (SynthOscillator) sounds.elementAt( soundIndex );
		osc.output.connect( myAmp.inputA );
		osc.start();
		previous = osc;
	}
	
/*
 * Setup synthesis.
 */
	public void start()
	{
		sounds = new Vector();
		names = new Vector();
		
/* Use GridBagLayout to get reasonably sized components. */
		GridBagLayout  gridbag  =  new  GridBagLayout();
		GridBagConstraints  constraint  =  new  GridBagConstraints();
		setLayout(gridbag);
		constraint.fill  =  GridBagConstraints.BOTH;
		constraint.weightx  =  1.0;
		constraint.weighty  =  1.0;

		try
		{
/* Start synthesis engine. */
		Synth.startEngine( 0 );

/* Make waveform unit generators. */
		sounds.addElement( new SineOscillator() );
		names.addElement( "Sine" );
		
		sounds.addElement( new SawtoothOscillator() );
		names.addElement( "Sawtooth" );
		
		sounds.addElement( new TriangleOscillator() );
		names.addElement( "Triangle" );
		
		sounds.addElement( new SquareOscillator() );
		names.addElement( "Square" );
		
		sounds.addElement( new RedNoise() );
		names.addElement( "RedNoise" );
		
		sounds.addElement( new ImpulseOscillator() );
		names.addElement( "Impulse" );
		
		myAmp      = new MultiplyUnit();
		myOut      = new LineOut();
		
/* Set default sound to zeroth sound. */
		useNthSound( 0 );
		
/* Use distributor to control the frequency of all oscillator with just one port. */
		frequency = new SynthDistributor( "Frequency", Synth.SIGNAL_TYPE_OSC_FREQ );
		
/* Connect distributor to all Frequency controls for synchronous control. */
		for( int i=0; i<sounds.size(); i++ )
		{
			SynthOscillator osc = (SynthOscillator) sounds.elementAt(i);
			frequency.connect( osc.frequency );
		}

		myAmp.output.connect( 0, myOut.input, 0 );
		myAmp.output.connect( 0, myOut.input, 1 );

/* Create an oscilloscope to show each waveform. */
		add( scope = new SynthScope() );
		scope.createProbe( myAmp.output, "Output", Color.yellow );
		scope.finish();

		constraint.gridwidth  =  GridBagConstraints.REMAINDER; 
		constraint.gridheight  =  1;  
		constraint.weighty  =  1.0;
		gridbag.setConstraints(scope,  constraint);

/* Create a fader to control Frequency. */
		add( freqFader = new PortFader( frequency, 440.0, -1000.0, 1000.0 ) );
		constraint.gridheight  =  1;  
		constraint.weighty  =  0.0;
		gridbag.setConstraints(freqFader,  constraint);
			
/* Create a fader to control Amplitude. */
		add( ampFader = new PortFader( myAmp.inputB, "Amplitude", 0.5, 0.0, 1.0 ) );
		constraint.gridheight  =  GridBagConstraints.RELATIVE;  
		gridbag.setConstraints(ampFader,  constraint);

/* Make an array of checkboxes to select which oscillator to hear. */
		makeCBoxPanel( );
		constraint.gridheight  =  GridBagConstraints.REMAINDER;  
		gridbag.setConstraints(cboxPanel,  constraint);
		add( cboxPanel );
		
		myAmp.start();
		myOut.start();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}

		getParent().validate();
		getToolkit().sync();
	}
	

	public void stop()
	{
		try
		{
/* Delete units. */
			sounds.removeAllElements();
			removeAll(); // remove portFaders
/* Turn off tracing. */
			Synth.verbosity = Synth.SILENT;
/* Stop synthesis engine. */
			Synth.stopEngine();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
	
	public boolean action(Event evt, Object what)
	{
		try
		{
/* Determine which Checkbox was selected and use that source. */
			for( int i=0; i<sourceBoxes.length; i++ )
			{
				if( evt.target == sourceBoxes[i] )
				{
					useNthSound( i );
					return true;
				}
			}
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
		return false;
    }
}
