/*
 * Copyright 2009 Phil Burk, Mobileer Inc
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.jsyn.debug;

import javax.swing.JApplet;

import com.jsyn.JSyn;
import com.jsyn.Synthesizer;
import com.jsyn.instruments.SubtractiveSynthVoice;
import com.jsyn.unitgen.LineOut;
import com.jsyn.util.VoiceAllocator;

/**
 * Check to see if the CPU usage is controlled by the autoDisable feature.
 * 
 * @author Phil Burk Public Domain 2010 Mobileer Inc
 */

public class DebugCircuitUsage extends JApplet {
    private static final long serialVersionUID = 1614628946115373956L;
    private static final int MAX_VOICES = 32;
    private Synthesizer synth;
    private VoiceAllocator allocator;
    private LineOut lineOut;
    private SubtractiveSynthVoice[] voices;

    private void test() throws InterruptedException {
        synth = JSyn.createSynthesizer();

        // Add an output.
        synth.add(lineOut = new LineOut());

        // Start synthesizer using default stereo output at 44100 Hz.
        synth.start();
        // We only need to start the LineOut. It will pull data from the
        // voices.
        lineOut.start();

        voices = new SubtractiveSynthVoice[MAX_VOICES];
        for (int i = 0; i < MAX_VOICES; i++) {
            SubtractiveSynthVoice voice = new SubtractiveSynthVoice();
            synth.add(voice);
            voice.getOutput().connect(0, lineOut.input, 0);
            voice.getOutput().connect(0, lineOut.input, 1);
            voices[i] = voice;
        }
        allocator = new VoiceAllocator(voices);

        printUsage(3.0);

        // Play all of the voices at once.
        allNotesOn();
        printUsage(2.0);
        allNotesOff();
        printUsage(3.0);

        // Play them again to see the effect of the HotSpot compiler and the caches.
        allNotesOn();
        printUsage(2.0);
        allNotesOff();
        printUsage(3.0);

        // Stop everything.
        synth.stop();
    }

    private void allNotesOn() {
        System.out.println("All Notes On! ==================");
        double amplitude = 1.0 / MAX_VOICES;
        for (int i = 0; i < MAX_VOICES; i++) {
            double frequency = 200 + (50 * i) + Math.random();
            allocator.noteOn(40 + i, frequency, amplitude, synth.createTimeStamp());
        }
    }

    private void allNotesOff() {
        System.out.println("All Notes Off. -------");
        allocator.allNotesOff(synth.createTimeStamp());
    }

    private void printUsage(double seconds) throws InterruptedException {
        // Get synthesizer time in seconds.
        double timeNow = synth.getCurrentTime();
        double timeStop = timeNow + seconds;
        while (synth.getCurrentTime() < timeStop) {
            System.out.printf("Usage = %6.4f\n", synth.getUsage());
            synth.sleepFor(0.2);
        }
    }

    public static void main(String[] args) {
        try {
            new DebugCircuitUsage().test();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
