@rem Run User JSyn Program

set CLASSDIR=..\..\classes
rem Include JSyn classes from the JAR file in the CLASSPATH
set CLASSPATH=%CLASSPATH%;%CLASSDIR%\JSynClasses.jar;%CLASSDIR%

java mystuff.TJ_Beep

