@rem Build User JSyn Program

set CLASSDIR=..\..\classes
rem Include JSynClasses.JAR and the other JSyn classes in the CLASSPATH
set CLASSPATH=%CLASSPATH%;%CLASSDIR%\JSynClasses.jar;%CLASSDIR%

@rem compile all of the java programs in this directory
javac -d  %CLASSDIR%  *.java
