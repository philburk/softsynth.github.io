package JSynExamples;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/**
 * Test Hardware Audio Device Query and Selection
 * <P>
 * This Applet provides a section of available devices by name.
 * The maximum number of channels is given in square bracket, eg. "[2]".
 * If both input and output are started, then the input is connected to output.
 * If only output is selected, then sine waves are connected to the outputs.
 * <P>
 * The underlying device interface is based on the PortAudio library
 * which is available at http://www.portaudio.com
 * 
 * @author (C) 2001  Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class TJ_Devices extends Applet
{
	SynthContext       synthContext;
// Arrays to hold units fo rmultiple channels.
	ChannelIn          inputs[];
	ChannelOut         outputs[];
	SineOscillator     sines[];
	DeviceSelector     inDevSel;
	DeviceSelector     outDevSel;
	Button             startButton;
	Button             stopButton;
	public final static int   INPUT_MODE = 0;
	public final static int   OUTPUT_MODE = 1;

/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_Devices applet = new TJ_Devices();
		AppletFrame frame = new AppletFrame("Test JSyn Devices", applet);
		frame.resize(600,300);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{		
		setLayout( new GridLayout(0,1) );

/* Make sure we are using the necessary version of JSyn */
		Synth.requestVersion( 142 );
		
		// Synth.setTrace( Synth.VERBOSE );
		try
		{
	// Create a unique SynthContext so that this Applet will not interfere with other Applets. */
		synthContext = new SynthContext();
		synthContext.initialize();

	// Create objects that select and enable a device.
		add( inDevSel = new DeviceSelector( "Input", INPUT_MODE ) );
		add( outDevSel = new DeviceSelector( "Output", OUTPUT_MODE ) );
		
	// Add buttons to start and stop engine using selected devices.
   		add( startButton = new Button("Start") );
   		startButton.addActionListener(
   			new ActionListener() {
   				public void actionPerformed(ActionEvent e)
   				{ stopAudio();
				  startAudio();	} } );

   		add( stopButton = new Button("Stop") );
   		stopButton.addActionListener(	new ActionListener() {
   				public void actionPerformed(ActionEvent e)
   				{ stopAudio();	} } );		
		
		
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}

		getParent().validate();
		getToolkit().sync();
	}
	

	void startAudio()
	{
		int numIn, numOut;
		
		try
		{	
		
		inDevSel.start();
		outDevSel.start();
									   
/* Start synthesis engine. Use half default frame rate because many PC cards do not support
 * FullDuplex operation at the full sample rate.
 * Use devices and numChannels from DeviceSelectors.
 * We don't need to set Synth.FLAG_ENABLE_INPUT because we pass devices explicitly.
 */
		int inDevID = inDevSel.getDeviceID();
		int outDevID = outDevSel.getDeviceID();
		synthContext.start( 0,
						   Synth.DEFAULT_FRAME_RATE / 2,
						   inDevID, inDevSel.getNumChannels( inDevID ),
						   outDevID, outDevSel.getNumChannels( outDevID )
						   );
		
	// Open all of the channels available on the input device.
		numIn = inDevSel.getNumChannels( inDevID );
		if( numIn > 0 )
		{
			inputs = new ChannelIn[numIn];
			for( int i=0; i<numIn; i++ )
			{
				inputs[i] = new ChannelIn(synthContext, i);
				inputs[i].start();
			}
		}
		
	// Open all of the channels available on the output device.
		numOut = outDevSel.getNumChannels( outDevID );
		if( numOut > 0 )
		{
			outputs = new ChannelOut[numOut];
			if( numIn <= 0 )
			{
				sines = new SineOscillator[numOut];
			}
			
			for( int i=0; i<numOut; i++ )
			{
				outputs[i] = new ChannelOut(synthContext, i);
				outputs[i].start();
		// If we have an input device, connect it to the outputs.
				if( numIn > 0 )
				{
					inputs[i % numIn].output.connect( outputs[i].input );
				}
				else
				{
		// Otherwise, connect sine waves playing a harmonic series.
					sines[i] = new SineOscillator(synthContext);
					sines[i].frequency.set(200.0 * (i+1));
					sines[i].amplitude.set(1.0);
					sines[i].start();
					sines[i].output.connect( outputs[i].input );
				}	
			}
		}
		
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}

		getParent().validate();
		getToolkit().sync();
	}
	
	public void stop()
	{
		try
		{
			stopAudio();
			synthContext.delete();
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
/** Delete an array of units.
 */
	void killUnits( SynthUnit units[] )
	{
		if( units != null )
		{
			for( int i=0; i<units.length; i++ )
			{
				units[i].stop();
				units[i].delete();
			}
		}
	}
		
	void stopAudio()
	{
		killUnits( outputs );
		outputs = null;
		killUnits( inputs );
		inputs = null;
		killUnits( sines );
		sines = null;
		
		synthContext.stop();

		inDevSel.stop();
		outDevSel.stop();
			
		getParent().validate();
		getToolkit().sync();
	}
	
/**
 * Puts up a menu that allows the user to select an available device.
 */
class DeviceSelector extends Panel
{
	String             text;
	Label              currentNameLabel;
	Choice             deviceNames;
	Checkbox           devEnable;
	Hashtable          nameToIndexHash;
	int                mode;
	
	public DeviceSelector( String text, int mode )
	{
		this.text = text;
		this.mode = mode;
		add( devEnable = new Checkbox(text, (mode == OUTPUT_MODE) ) );
		add( deviceNames = new Choice() );
		nameToIndexHash = new Hashtable();
		
	// Loop though all of the available devices and fill
	// the choice menu with valid options.
		for( int i=0; i<AudioDevice.getNumDevices(); i++ )
		{
			int maxChannels = getMaxChannels( i );
			if( maxChannels > 0 )
			{
			// If valid, add name of device to choices.
				String name = AudioDevice.getName( i ) +
							  " [" + maxChannels + "]";
				deviceNames.addItem( name );
				nameToIndexHash.put( name, new Integer(i) );
			}
		}
				
		add( currentNameLabel = new Label( "Current = stopped" ) );
	}
	
/* Set label to indicate state. */
	public void start()
	{
		if( devEnable.getState() )
		{
			currentNameLabel.setText( text + " = " + AudioDevice.getName( getDeviceID() ) );
		}
	}
	
	public void stop()
	{
		currentNameLabel.setText( text + " = stopped");
	}
	
	public int getMaxChannels( int id )
	{
		int maxChannels = (mode == INPUT_MODE) ?
						  AudioDevice.getMaxInputChannels( id ) :
						  AudioDevice.getMaxOutputChannels( id );
		return maxChannels;
	}
	
	public int getNumChannels( int id )
	{
		return (id == Synth.NO_DEVICE) ? 0 : getMaxChannels( id );
	}
	
	public int getSelectedDeviceID()
	{
		Integer idObj = (Integer) 
			   nameToIndexHash.get( deviceNames.getSelectedItem() );
		return idObj.intValue();
	}
	
	public int getDeviceID()
	{
		return devEnable.getState() ? getSelectedDeviceID() : Synth.NO_DEVICE;
	}
}
}
