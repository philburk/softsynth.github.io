#!/bin/bash
# change directory t where the script is.
cd "`dirname \"$0\"`"

echo "Run Wire using old version of Java to avoid bug in 1.4 and 1.5"

# Print path to java so we can debug this script more easily if java got moved.
ls -l `which java`

# Run Wire
/System/Library/Frameworks/JavaVM.framework/Versions/1.3/Commands/java -jar Wire.app/Contents/Resources/Java/Wire.jar