@rem Build JSyn and Examples
@set MYCLASSES=classes
@set CLASSPATH=%MYCLASSES%
@set JSYNDIR=jsrc\com\softsynth\jsyn
set JAVAC=javac
%JAVAC% -d %MYCLASSES% %JSYNDIR%\*.java
%JAVAC% -d %MYCLASSES% %JSYNDIR%\util\*.java
%JAVAC% -d %MYCLASSES% %JSYNDIR%\view102\*.java %JSYNDIR%\view11x\*.java %JSYNDIR%\circuits\*.java
%JAVAC% -d %MYCLASSES% jsrc\JSynExamples\*.java
rem ALL DONE!
