README for JSyn
Copyright (C) 1997 Phil Burk
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.

--------------- Disclaimer ---------------------------

This version of JSyn may only be used for non-commercial purposes, and may NOT 
be redistributed by any means. Please contact "philburk@softsynth.com" regarding 
the availability of commercial licenses.

JSyn is available AS IS with no warranty of fitness or suitability for any purpose.
Use at your own risk.

--------------- Installation -------------------------

For HTML docs on how to install and use JSyn, please browse "jsyn\docs\index.html".

If you encounter ANY bugs, or have any suggestions please let me
know. Also please let me know if you develop any JSyn applications. I would
like to mention them on my web site.

Please visit the JSyn web site at http://www.softsynth.com/jsyn
for more information or to download the latest version.

Thank you,
Phil Burk
philburk@softsynth.com
