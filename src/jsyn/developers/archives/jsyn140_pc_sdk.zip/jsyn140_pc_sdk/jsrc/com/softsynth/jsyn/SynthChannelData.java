package com.softsynth.jsyn;
import java.util.*;

/**
 *	The SynthChannelData class is a container for digital audio data.  The actual data may need to reside in memory that is accessible to 
 *	DMA or to a DSP so we cannot assume that it is in main memory.  We also need to maintain cache coherence if the data is 
 *	going to be read or written by hardware other than the CPU.  For this reason, Envelopes cannot use memory allocated by, or 
 *	accessable to the application.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthSample
 * @see SynthEnvelope
 */

public class SynthChannelData extends SynthObject 
{
	int  numFrames;
	int  sustainBegin = -1;
	int  sustainEnd = -1;
	int  releaseBegin = -1;
	int  releaseEnd = -1;
	public Vector  cuePoints;

	public  SynthChannelData()
	{
		this(0);
	}
	
	public SynthChannelData( int numFrames )
	{
		this.numFrames = numFrames;
	}

/**
 * @return Number of frames of data.
 */
	public int getNumFrames() { return numFrames; }

/**
 *	Set location of Sustain Loop in units of Frames. Set SustainBegin to -1 if no Sustain Loop. SustainEnd value is the 
 *	frame index of the frame just past the end of the loop.  The number of frames included in the loop is (SustainEnd - 
 *	SustainBegin). 
 */
	public void setSustainLoop( int startFrame, int endFrame )
	{
		this.sustainBegin = startFrame;
		this.sustainEnd = endFrame;
	}
/***
 * @return Beginning of sustain loop or -1 if no loop.
 */
	public int getSustainBegin() { return this.sustainBegin; }
/***
 * @return End of sustain loop or -1 if no loop.
 */
	public int getSustainEnd() { return this.sustainEnd; }
/***
 * @return Size of sustain loop in frames, 0 if no loop.
 */
	public int getSustainSize() { return (this.sustainEnd - this.sustainBegin); }


/**
 *	Set location of Release Loop in units of Frames. Set ReleaseBegin to -1 if no ReleaseLoop. ReleaseEnd value is the 
 *	frame index of the frame just past the end of the loop.  The number of frames included in the loop is (ReleaseEnd - 
 *	ReleaseBegin). 
 */
	public void setReleaseLoop( int startFrame, int endFrame )
	{
		this.releaseBegin = startFrame;
		this.releaseEnd = endFrame;
	}
/***
 * @return Beginning of release loop or -1 if no loop.
 */
	public int getReleaseBegin() { return this.releaseBegin; }
/***
 * @return End of release loop or -1 if no loop.
 */
	public int getReleaseEnd() { return this.releaseEnd; }
/***
 * @return Size of release loop in frames, 0 if no loop.
 */
	public int getReleaseSize() { return (this.releaseEnd - this.releaseBegin); }

/* Insert CuePoint in order of position. */
	public void insertSortedCue( CuePoint cuePoint )
	{
		if( cuePoints == null ) cuePoints = new Vector();
		int idx = cuePoints.size();
		for( int k=0; k<cuePoints.size(); k++ )
		{
			CuePoint cue = (CuePoint) cuePoints.elementAt(k);
			if( cue.getPosition() > cuePoint.getPosition() )
			{
				idx = k;
				break;
			}
		}
		cuePoints.insertElementAt( cuePoint, idx );
	}
	
	public CuePoint findCuePoint( int uniqueID )
	{
		if( cuePoints == null ) return null;
		int idx = cuePoints.size();
		for( int k=0; k<cuePoints.size(); k++ )
		{
			CuePoint cue = (CuePoint) cuePoints.elementAt(k);
			if( cue.getID() == uniqueID )
			{
				return cue;
			}
		}
		return null;
	}
	
	public int findCuePosition( int uniqueID )
	{
		CuePoint cue = findCuePoint( uniqueID );
		if( cue == null ) return -1;
		else return cue.getPosition();
	}
}
