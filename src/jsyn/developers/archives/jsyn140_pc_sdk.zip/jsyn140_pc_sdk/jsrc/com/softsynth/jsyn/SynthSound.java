package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthSound is an interface that is used for the elemental SynthSounds
 * or for collections of units called SynthCircuits
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SynthSound extends SynthObject
{
	String  name;
	Vector  ports;  /* Vector containing all the ports of a sound. */

	SynthSound()
	{
		ports = new Vector();
	}

/**
 * Add a port to a vector that contains all ports for a sound.
 * The vector can be used by inspectors, and automated sound editors.
 */
	public void addPort( SynthPort port, String alias )
	{
		port.setAlias( alias );
		ports.addElement( port );
	}
	public void addPort( SynthPort port )
	{
		ports.addElement( port );
	}

/**
 * @return Number of ports belonging to this sound.
 */
	public int getNumPorts()
	{
		return ports.size();
	}

/**
 * @return indexed SynthPort belonging to this sound.
 */
	public SynthPort getPortAt( int index )
	{
		return (SynthPort) ports.elementAt( index );
	}

/**
 * @return named SynthPort belonging to this sound.
 */
	public SynthPort findNamedPort( String name )
	{
		SynthPort port;
		int numPorts = getNumPorts();
		for( int i=0; i<numPorts; i++ )
		{
			port = getPortAt(i);
			if( port.getAlias().equals( name ) ) return port;
		}
		return (SynthPort) null;
	}

/**
 *	Start execution of this instrument by the synthesis process at the specified time in ticks.
 *	If we are already past that time then start immediately.
 *
 * @exception SynthException	If peer is invalid.
 */
	public void start( int time ) 	throws SynthException
	{	
		if( Synth.verbosity >= Synth.TERSE )
		{
			System.out.println("start(" + time + ") => " + Integer.toHexString(peerToken));
		}

		int nativeError = Synth.StartUnitAt( time, getPeer() );
		if( nativeError < 0 ) throw new SynthException( nativeError, peerToken );
	}

/**
 *	Start execution of this instrument immediately. 
 *
 * @exception SynthException	If peer is invalid.
 */
	public void start()
	throws SynthException
	{
		if( Synth.verbosity >= Synth.TERSE )
		{
			System.out.println("start() => " + Integer.toHexString(peerToken));
		}
		int nativeError = Synth.StartUnit( getPeer() );
		if( nativeError < 0 ) throw new SynthException( nativeError, peerToken );
	}
/**
 *	Stop execution of this instrument by the synthesis process at the specified time in ticks.
 *	If we are already past that time then stop immediately.
 *
 * @exception SynthException	 If token is invalid.
 */
 	public void stop( int time )
	throws SynthException
	{
		int nativeError = Synth.StopUnitAt( time, getPeer() );
		if( nativeError < 0 ) throw new SynthException( nativeError, peerToken );
	}

 /**
 *	Stop execution of this instrument immediately. 
 *
 * @exception SynthException	 If token is invalid.
 */
	public void stop()
	throws SynthException
	{
		int nativeError = Synth.StopUnit( getPeer() );
		if( nativeError < 0 ) throw new SynthException( nativeError, peerToken );
	}

/**
 *	Set the priority of a unit.
 *  High priority units will execute before lower priority units.
 *
 * @exception SynthException	 If priority is out of range..
 */
	public void setPriority( int priority )
	throws SynthException
	{
		int nativeError = Synth.SetPriority( getPeer(), priority );
		if( nativeError < 0 ) throw new SynthException( nativeError, peerToken, priority );
	}
/**
 *	Get the priority of a sound.
 *
 * @exception SynthException	 If unit token is invalid.
 */
	public int getPriority( )
	throws SynthException
	{
		int result = Synth.GetPriority( getPeer() );
		if( result < 0 )
		{
			nativeError = result;
			throw new SynthException( nativeError, peerToken );
		}
		return result;
	}

/**
 * Set stage of multi-stage sound.
 * Typically noteOn will be stage 0, off will be 1.
 * @exception SynthException	 If an error occurs.
 */
	public void setStage( int time, int stage )
	throws SynthException
	{
	}
	public void setStage( int stage )
	throws SynthException
	{
		setStage( Synth.getTickCount(), stage);
	}

/** Returns name. */
	public String getName()
	{
		return name;
	}
}
