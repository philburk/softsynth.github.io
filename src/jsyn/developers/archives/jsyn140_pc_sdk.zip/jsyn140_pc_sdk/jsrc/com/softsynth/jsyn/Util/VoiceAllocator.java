package com.softsynth.jsyn.util;
import java.util.*;
import java.io.*;
import com.softsynth.jsyn.*;

/** Voice Allocator for managing the allocation and reuse of voices.
 * Uses an abstract method makeVoice() which must be defined in later classes.  * BussedVoiceAllocator is typically used in stead of VoiceALlocator.

 * To allocate a voice if freely available, use allocate().<br>
 * To allocate a free voice, or steal the oldest voice use steal().
 * Steal is the preferred method for getting a voice because it is usually more important
 * to start the new voice then to continue the old one.
 * 
 * @see JSynExamples.TJ_PlayKeys1 * @see BussedVoiceAllocator
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public abstract class VoiceAllocator
{	final static int    LONGTIME = Integer.MAX_VALUE/2;  // for simulating far future
	SynthCircuit        voices[];
	int                 priorities[];	int                 stopTimes[];	int                 maxVoices;
	int                 numVoices = 0;	
/** Specify the maximum number of voices that can be allocated at a time.
 * If an attempt is made to allocate more, then voices that are in use
 * may be stolen.
 */
	public VoiceAllocator( int maxVoices )
	{
		this.maxVoices = maxVoices;
		voices = new SynthCircuit[maxVoices];
		priorities = new int[maxVoices];
		stopTimes = new int[maxVoices];
	}
	
/** @return Maximum number of voices that will be allocated.
 */
	public int getMaxVoices()
	{
		return maxVoices;
	}
	
/** Create a new voice. This method must be defined in your classes.
 */
	public abstract SynthCircuit makeVoice() throws SynthException;

/* Add a voice to the pool. */
	synchronized SynthCircuit addVoice( int stopTime, int priority ) throws SynthException
	{
		if( numVoices == maxVoices ) return null;
		SynthCircuit circ = makeVoice();
		voices[numVoices] = circ;
		mark( numVoices, stopTime, priority);
		numVoices++;
		return circ;
	}

/* Search for earliest voice with matching allocation status. */
	synchronized int searchEarliest( int startTime, int priority )
	{
		int minDelta = Integer.MAX_VALUE;
		int chosen = -1;
		for( int i=0; i<numVoices; i++ )
		{
			int delta = stopTimes[i] - startTime;
			
	// Is voice free, or can we steal it?
			if( (priority >= priorities[i]) || (delta <= 0))
			{
	// Find earliest such voice.
				if( delta < minDelta )
				{
					minDelta = delta;
					chosen = i;
				}
			}
		}
		return chosen;
	}
	
	void mark( int chosen, int stopTime, int priority )
	{
		stopTimes[chosen] = stopTime;		priorities[chosen] = priority;
//		System.out.println("VoiceAllocator: mark " + chosen + " at " + stopTime );
	}
	
/** Allocate a voice for use at startTime, lasting until stopTime.
 * @return a voice or null if maximum number of voices are already allocated. */
	public synchronized SynthCircuit allocate( int startTime, int stopTime, int priority ) throws SynthException 
	{
/* If no voices, just make one. */
		if( numVoices == 0 ) return addVoice( stopTime, priority );
		
/* Look for earliest free voice. */
		int chosen = searchEarliest( startTime, priority-1 );
		if( chosen >= 0 )
		{
			mark(chosen, stopTime, priority );	// mod ND
			return voices[chosen];
		}
		
/* If not maxed out, just make one. */
		if( numVoices < maxVoices ) return addVoice( stopTime, priority );

		return null;
	}
/** Allocate a voice using a default priority of zero.
 */
	public synchronized SynthCircuit allocate( int startTime, int stopTime ) throws SynthException
	{		return allocate( startTime, stopTime, 0 );
	}	
/** Allocate a voice to use with an unknown stopTime.
 */
	public synchronized SynthCircuit allocate( int startTime ) throws SynthException
	{		return allocate( startTime, startTime + LONGTIME, 0 );
	}
	public synchronized SynthCircuit allocate(  ) throws SynthException
	{		return allocate( Synth.getTickCount() );
	}
	
/** Allocate a voice at startTime, lasting until stopTime. Try to allocate a voice then steal 
	the voice whose stopTime is earliest if none other available. */
	public synchronized SynthCircuit steal( int startTime, int stopTime, int priority ) throws SynthException
	{
/* First try to allocate one. */
		SynthCircuit circ = allocate( startTime, stopTime, priority );
		if( circ != null ) return circ;
		
/* Then steal earliest allocated voice. */
		int chosen = searchEarliest( startTime, priority );
		if( chosen >= 0 )
		{
			if( Synth.verbosity >= Synth.TERSE )
			{
				System.out.println("VoiceAllocator: steal " + chosen);
			}
			mark(chosen, stopTime, priority);
			return voices[chosen];
		}
		return null;
	}
	
/** Steal a voice using a default priority of zero.
 */
	public synchronized SynthCircuit steal( int startTime, int stopTime ) throws SynthException
	{		return steal( startTime, stopTime, 0 );
	}
	
/** Steal a voice with an unknown stopTime. */
	public synchronized SynthCircuit steal( int startTime ) throws SynthException
	{		return steal( startTime, startTime + LONGTIME, 0 );
	}
	public SynthCircuit steal()  throws SynthException
	{
		return steal( Synth.getTickCount() );
	}
/** Free a voice for others to use. */
	public synchronized void free( int stopTime, SynthCircuit circuit )
	{
		for( int i=0; i<numVoices; i++ )
		{
			if( circuit == voices[i] )
			{
				// System.out.println("VoiceAllocator: free " + i + " at " + stopTime);
				mark( i, stopTime, 0 );
				break;
			}
		}
	}
	
	public void free( SynthCircuit circuit )  throws SynthException
	{
		free( Synth.getTickCount(), circuit );
	}

}
