package com.softsynth.jsyn;
import java.util.*;

/**
 *	InterpolatingDelayUnit
 <P>
 InterpolatingDelayUnit provides a variable time delay with an input and output.
 The internal data format is the same resolution as a SynthTable which is
 floating point if the sound processor supports it.
 The amount of delay can be varied from 0.0 to the delayTime specified at creation.
 The fractional delay values are calculated by linearly interpolating between
 adjacent values in the delay line.
 <P>
 This unit can be used to implement time varying delay effects such as a flanger
 or a chorus. It can also be used to implement physical models of acoustic instruments,
 or other tuneable delay based resonant systems.
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 * @see InterpolatingDelayUnit
 * @see SampleWriter_16F1
 */

public class InterpolatingDelayUnit extends SynthFilter
{
/** Delay time in seconds. Range: 0.0 to unit's maxDelayTime in seconds. */
	public SynthInput delay;

 	public InterpolatingDelayUnit( int calculationRate, double maxDelayTime ) throws SynthException
	{
/* FIXME - adjust for control rate delay. */
		super( "Delay_Interpolated", calculationRate, (int) (0.5 + (maxDelayTime * Synth.getFrameRate())) );
		delay = new SynthInput( this, "Delay" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public InterpolatingDelayUnit( double delayTime ) throws SynthException
	{
		this( Synth.RATE_AUDIO, delayTime );
	}
	
	public InterpolatingDelayUnit() throws SynthException
	{
		this( 1.0 );
	}
}
