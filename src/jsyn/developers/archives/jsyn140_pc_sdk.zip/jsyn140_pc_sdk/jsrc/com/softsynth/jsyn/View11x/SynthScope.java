package com.softsynth.jsyn.view11x;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import com.softsynth.jsyn.*;

/**
 * Oscilloscope
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see TJ_SeeOsc
 */

public class SynthScope  extends com.softsynth.jsyn.view102.InternalSynthScope implements ActionListener
{
	public SynthScope( int sampleSize )
	{
		super( sampleSize );
		
		captureButton.addActionListener( this );
		zoomInButton.addActionListener( this );
		zoomOutButton.addActionListener( this );
		panLeftButton.addActionListener( this );
		panRightButton.addActionListener( this );
		
		autoBox.addItemListener(	new ItemListener() {
					public void itemStateChanged( ItemEvent e)
					{ handleAutoBoxLocally();
					} } );

	}
	public SynthScope()
	{
		this( 1024 );
	}
// Make Java ItemListener happy
	void handleAutoBoxLocally()
	{
		handleAutoBox();
	}
	
	public void actionPerformed(ActionEvent e)
	{ 
		System.out.println("AWT1.1 - action ");
		handleButtonAction( (Component) e.getSource() );
	}
}
