package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import java.applet.*;
import com.softsynth.jsyn.*;

/**
 * Oscilloscope
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see TJ_SeeOsc
 */

public class SynthScope  extends InternalSynthScope
{
	public SynthScope( int sampleSize )
	{
		super( sampleSize );
	}
	public SynthScope()
	{
		this( 1024 );
	}

	public boolean action(Event evt, Object what)
	{
//		System.out.println("AWT1.0.2 - action ");
		return handleButtonAction( (Component) evt.target );
    }

}
