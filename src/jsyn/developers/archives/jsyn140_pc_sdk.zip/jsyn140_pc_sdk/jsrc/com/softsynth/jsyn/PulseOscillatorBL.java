package com.softsynth.jsyn;
import java.util.*;

/**
 *	PulseOscillatorBL unit that is bandlimited to prevent aliasing artifacts.
 * This will sound better then PulseOscillator, particularly at higher frequencies.
 * It will also take more CPU power to calculate
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 014
 * @see Synth
 * @see SynthChannelData
 */

public class PulseOscillatorBL extends SynthOscillator 
{
/**
 * Level for comparator used to generate pulse wave. 0 gives a 50% duty cycle
 * pulse wave. Positive values cause the positive portion of the pulse to
 * be wider than the negative. Negative values cause the negative portion
 * of the pulse to be wider than the positive. The range is -1.0 to +1.0,
 * defaults to 0.0.
 */
	public SynthInput width;

 	public PulseOscillatorBL( int calculationRate ) throws SynthException
	{
		super( "Osc_PulseBL", calculationRate, 0 );
		width = new SynthInput( this, "Width" );
	}
/**
 *	Create a PulseOscillatorBL that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public PulseOscillatorBL( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}

