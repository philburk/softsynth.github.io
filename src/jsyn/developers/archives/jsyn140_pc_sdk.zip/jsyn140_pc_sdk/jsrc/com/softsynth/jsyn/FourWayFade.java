package com.softsynth.jsyn;
import java.util.*;

/**
 *	FourWayFade unit.
 <P>
  Mix inputs 0-3 based on the value of two fade ports.
  You can think of the four inputs arranged clockwise as follows.<P>
  <PRE>
     input[0] ---- input[1]
       |             |
       |             |
       |             |
     input[3] ---- input[2]
</PRE>
The "fade" port has two parts.
Fade[0] fades between the
pair of inputs (0&3) and the pair of inputs (1&2).      
Fade[1] fades between the
pair of inputs (0&1) and the pair of inputs (3&2).
<PRE>
   Fade[0]    Fade[1]    Output
     -1         -1       Input[3]
     -1         +1       Input[0]
     +1         -1       Input[2]
     +1         +1       Input[1]
     
     
     -----Fade[0]----->
     
        A
        |
        |
     Fade[1]
        |
        |
 </PRE>   
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see CrossFade
 * @see PanUnit
 */

public class FourWayFade extends SynthUnit 
{
/** This port has four parts, 0,1,2 and 3. */
	public SynthInput input;
/** This port has two parts, 0 and 1, which fade between "left-to-right"
 * and "back-to-front".
 */
	public SynthInput fade;
	public SynthOutput output;

 	public FourWayFade( int calculationRate ) throws SynthException
	{
		super( "Math_FourWayFade", calculationRate );
		input = new SynthInput( this, "Input" );
		fade = new SynthInput( this, "Fade" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
  	public FourWayFade( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
