package com.softsynth.jsyn.view11x;

/** Interface to get values back from a CustomFader.  Any class
that uses a CustomFader will be notified of its value being changed 
by implementing this interface. <br>
@author Nick Didkovsky and Phil Burk
*/
public interface CustomFaderListener extends com.softsynth.jsyn.view102.CustomFaderListener
{
}
