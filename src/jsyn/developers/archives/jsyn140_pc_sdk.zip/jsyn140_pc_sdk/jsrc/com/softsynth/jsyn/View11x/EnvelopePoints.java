package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import com.softsynth.util.NumericOutput;
import java.util.*;
import java.awt.*;

/**
 * Vector that contains duration,value pairs.
 * Used by EnvelopeEditor
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class EnvelopePoints extends Vector
{
	String   name = "";
	double   maximumY = 1.0;
	
	public void setName( String name )
	{
		this.name = name;
	}
	public String getName()
	{
		return name;
	}
	
	public void setMaximumY( double   maximumY )
	{
		this.maximumY = maximumY;
	}
	public double   getMaximumY()
	{
		return maximumY;
	}
	
	public void add( double dur, double y )
	{
		double dar[] = { dur, y };
		addElement(  dar  );
	}
	
/** Insert point without changing total duration by reducing next points duration.
 */
	public void insert( int index, double dur, double y )
	{
		double dar[] = { dur, y };
		if( index < size() )
		{
			((double[]) elementAt( index ))[0] -= dur;
		}
		insertElementAt( dar, index );
	}

	public double[] getPoint( int index )
	{
		return (double[]) elementAt( index );
	}
	
	public double getTotalDuration()
	{
		double sum = 0.0;
		for( int i=0; i<size(); i++ )
		{
			double dar[] = (double []) elementAt(i);
			sum += dar[0];
		}
		return sum;
	}
}
