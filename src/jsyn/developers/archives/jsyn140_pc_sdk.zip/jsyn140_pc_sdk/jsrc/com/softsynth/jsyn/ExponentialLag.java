package com.softsynth.jsyn;
import java.util.*;

/**
 *	Output approaches Input exponentially. 
This unit provides a slowly changing value that approaches its Input value exponentially. 
The equation is: 
<P><PRE>
	Output = Output + Rate*(Input - Output);
</PRE>
The Rate is calculated internally based on the value on the halfLife port.
Rate is generally just slightly less than 1.0.

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 */

public class ExponentialLag extends SynthUnit 
{
/** Signal to approach. SIGNAL_TYPE_RAW_SIGNED */
	public SynthInput input;
/** Controls rate at which to approach input.
 * The output will go from its current value halfway to its input value in 
 * the time specified using this port.  Note: not connectable. SIGNAL_TYPE_HALF_LIFE
 */
	public SynthVariable halfLife;
/**
 * Current internal value.  This may be tweaked to force the output to a value immediately.
 * It can be used to generate an inexpensive decaying envelope by setting the Input to 0.0
 * and then setting Current to 1.0.
*/
	public SynthVariable current;
	public SynthOutput output;

 	public ExponentialLag( int calculationRate ) throws SynthException
	{
		super( "Lag_Exponential", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		halfLife = new SynthVariable( this, "HalfLife" );
		current = new SynthVariable( this, "Current" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a ExponentialLag that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public ExponentialLag( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
