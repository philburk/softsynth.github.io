package com.softsynth.jsyn;
import java.util.*;

/**
 *	SampleWriter_16F1 unit.
This unit writes input to a sample. It is used as a building block for
reverberation and echo effects when used in conjunction with a sample player
(e.g. SampleReader_16F1).
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SampleWriter_16F1 extends SampleWriter 
{
 	public SampleWriter_16F1( int calculationRate ) throws SynthException
	{
		super( "Sample_Write16F1", calculationRate );
	}
/**
 *	Create a SampleWriter_16F1 that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SampleWriter_16F1( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
