package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthInput is an input port for a SynthUnit. It can be connected to a SynthOutput
 * or set() directly.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthInput extends SynthVariable
{
	
	SynthInput( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	
/**	
 *  Connect output port of another instrument to this input port.
 *  Each port can have multiple indexed parts.
 *  A stereo sample reader would, for example, have an "Output" with two parts. 
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void connect( int inIndex, SynthOutput outPort, int outIndex ) throws SynthException
	{
		super.connectUnits( outPort, outIndex, this, inIndex );
	}
	public void connect( SynthOutput outPort ) throws SynthException
	{
		connect( 0, outPort, 0 );
	}
	
/** This method is illegal for SynthInput but is legal for a subclass SynthDistributor.
 * We need to define it so that we can make polymorphic ports.
 * But defining this method here prevents me from catching input<->input connection errors.
 * @exception SynthException	If used to connect two SynthInputs, or if port is not invalid, or index out of range.
 */
	public void connect( int outIndex, SynthInput inPort, int inIndex ) throws SynthException
	{
		if( inPort instanceof SynthDistributor ) // FIXME - review
		{
		System.out.println("SynthInput being connected to SynthDistributor.");
			inPort.connect( inIndex, this, outIndex );
		}
		// super.connectUnits( this, outIndex, inPort, inIndex ); /* Let CSyn catch error. */
	}

	public void connect( SynthInput inPort ) throws SynthException
	{
		connect( 0, inPort, 0 );
	}

/**
 *	Disconnects the connections made to this port.
 *	Only one connection can be made to an input port so a connection 
 *  can be uniquely referenced by naming the input port.  Output ports have infinite fan-out.
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void disconnect( int index )
	throws SynthException
	{
		super.disconnectUnits( this, index );
	}
	public void disconnect( ) throws SynthException
	{
		disconnect( 0 );
	}

/**
 * Convenient way to create a MultiplyUnit and connect it up.
 * To get Z = X * Y, use:
 * <pre>
 *    Z.input.multiply( X.output, Y.output );
 * </pre>
 * Make sure you save a reference to the MultiplyUnit or it may get garbage collected.
 * 
 * @return new MultiplyUnit()
 * @exception SynthException If MultiplyUnit cannot be created, or ports invalid.
 */
	public MultiplyUnit multiply( SynthOutput outPortX, SynthOutput outPortY )
	throws SynthException
	{
		MultiplyUnit mult = new MultiplyUnit();
		connect( mult.output );
		outPortX.connect( mult.inputA );
		outPortY.connect( mult.inputB );
		return mult;
	}
}
