package com.softsynth.jsyn.view11x;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

/** Custom Fader written to work around bugs and other problems with existing Scrollbar class.
 * AWT 1.0.2 and AWT 1.1 versions are both derived from the InternalCustomFader class.
 * @see RootCustomFader
@author Nick Didkovsky and Phil Burk
*/
public class CustomFader extends com.softsynth.jsyn.view102.InternalCustomFader implements MouseListener, MouseMotionListener
{
	
 /** Constructor with initial value, visible, min value, max value.  LineIncrement defaults to 1, PageIncrement defaults to 10 (see setUnitIncrement() and setBlockIncrement() below) */
	public CustomFader(int orientation, int val, int visible, int min, int max)
	{
		super( orientation, val, visible, min, max);
		addMouseListener(this);
  		addMouseMotionListener(this);
	}

	// placate the MouseMotionListener interface for AWT 1.1
	public void mouseDragged(MouseEvent e)
	{
//		System.out.println("AWT1.1 - dragged " + e.getX() + ", " + e.getY() );
		handleMouseDragged( e.getX(), e.getY());
	}
	public void mouseMoved(MouseEvent e) { }
	
	// placate the MouseListener interface
	public void mousePressed(MouseEvent e)
	{
		handleMousePressed( e.isShiftDown(), e.getX(), e.getY());
//		System.out.println("AWT1.1 - pressed " + isShiftDown + ", " + e.getX() + ", " + e.getY() );
	}
	  
	public void mouseClicked(MouseEvent e) { }
	
	public void mouseReleased(MouseEvent e)
	{
//		System.out.println("AWT1.1 - released " + e.getX() + ", " + e.getY() );
		handleMouseReleased( e.getX(), e.getY());
	}
	public void mouseEntered(MouseEvent e)
	{
//		System.out.println("AWT1.1 - entered " + e.getX() + ", " + e.getY() );
		handleMouseEntered(e.getX(), e.getY());
	}
	public void mouseExited(MouseEvent e)
	{
//		System.out.println("AWT1.1 - entered " + e.getX() + ", " + e.getY() );
		handleMouseExited(e.getX(), e.getY());
	}

}

 