package com.softsynth.jsyn;
import java.util.*;

/**
 *	This unit divides InputA by InputB. 
 <br><pre>
 output = inputA / inputB
 </pre><br>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see MultiplyUnit
 * @see AddUnit
 */

public class DivideUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public DivideUnit( int calculationRate ) throws SynthException
	{
		super( "Math_Divide", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public DivideUnit( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
