package com.softsynth.jsyn;
import java.util.*;

/**
 *	MinimumUnit unit.
 <P>
  Output equals A or B, whiechever is smaller.
 <P>
output = ( inputA < InputB ) ? inputA : InputB;
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Maximum
 */

public class MinimumUnit extends SynthUnit 
{
	public SynthInput inputA;
	public SynthInput inputB;
	public SynthOutput output;

 	public MinimumUnit( int calculationRate ) throws SynthException
	{
		super( "Math_Minimum", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public MinimumUnit( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
