package com.softsynth.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** An OutputStream wrapper for a RandomAccessFile
 * Needed by routines that output to an OutputStream.
 */
public class RandomOutputStream extends OutputStream
{
	RandomAccessFile randomFile;
	
	public RandomOutputStream( RandomAccessFile randomFile )
	{
		this.randomFile = randomFile;
	}
	
	public void write(int b) throws IOException
	{
		randomFile.write( b );
	}
	
	public void write(byte[] b) throws IOException
	{
		randomFile.write( b );
	}
	public void write(byte[] b, int off, int len) throws IOException
	{
		randomFile.write( b, off, len );
	}
		
	public void seek( long position )  throws IOException
	{
		randomFile.seek( position );
	}
	public long getFilePointer()  throws IOException
	{
		return randomFile.getFilePointer();
	}

}
