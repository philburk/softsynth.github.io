package com.softsynth.jsyn.view102;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
/**
 * Fader with Label and value display.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
abstract public class InternalLabelledFader extends Panel implements CustomFaderListener, Tweakable
{
	Tweakable  target;
	int        targetIndex;
	String     faderName;
	Label      nameLabel;
	Label      valueLabel;
	double     min,max;
	protected final static int RANGE = 2000;
	protected InternalCustomFader fader;
/**
 * Create a LabelledFader.
 * @param target Object that implements tweakable interface. If null, then this objects tweak method() will be called.
 * @param targetIndex Index that will be passed to tweak() method.
 * @param faderName Name of fader displayed on left of fader..
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public InternalLabelledFader( Tweakable target, int targetIndex, String faderName, double startValue, double min, double max )
	{
		if( target == null ) this.target = this;
		else this.target = target;
		
		this.targetIndex = targetIndex;
		this.faderName = faderName;
		this.min = min;
		this.max = max;
		setLayout( new GridLayout(0,3) );
/* Add space to label so it doesn't come too close to Scrollbar. */
		nameLabel = new Label( faderName + " ", Label.RIGHT );
		add(nameLabel);
		makeFader( doubleToFader(startValue));
		fader.addCustomFaderListener( this );
		fader.setUnitIncrement( RANGE/100 );
		add(fader);
		valueLabel = new Label();
		showValue( startValue );
		add(valueLabel);
	}
	
	double faderToDouble( int val )
	{
			return ((val*(max-min))/RANGE) + min;
	}
	
	int doubleToFader( double fval )
	{
			return (int)(((fval - min)*RANGE)/(max-min));
	}
	void showValue( double fval )
	{
/* Prevent size of label from fluctuating wildly. */
		String fvalString = Double.toString( fval );
		int maxchars = fvalString.indexOf( '.' ) + 5;
		String actualString = (fvalString.length() > maxchars) ? fvalString.substring(0,maxchars) : fvalString;
		valueLabel.setText( actualString );
	}
	
	public double getMinimum() { return min; }
	public double getMaximum() { return max; }
	
/** Set minimum value corresponding to the leftmost fader position. */
	public void setMinimum( double min )
	{
		this.min = min;
	}
/** Set maximum value corresponding to the rightmost fader position. */
	public void setMaximum( double max )
	{
		this.max = max;
	}
	
		
	public void setValue( double fval )
	{
		int ival = doubleToFader( fval );
		fader.setValue( ival );
	}
	
/** This can be overridden in subclasses. */
	public void tweak( int idx, double fval )
	{
	}

/** Any class listening to a CustomFader must implement CustomFaderListener by defining this method */
    public void customFaderValueChanged(Object jsb, int value)
	{
		double fval = faderToDouble( value );
		target.tweak( targetIndex, fval );
		showValue( fval );
	}
	
	abstract protected void makeFader( int initial );
}
