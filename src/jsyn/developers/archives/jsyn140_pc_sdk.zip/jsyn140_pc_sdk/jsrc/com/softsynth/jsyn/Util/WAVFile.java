package com.softsynth.jsyn.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** A RandomAccesFile with additional methods for writing
 */
public class WAVFile extends RandomAccessFile
{
	static final short WAVE_FORMAT_PCM = 1;
	long riffSizePosition = 0;
	long dataSizePosition = 0;
	
	public WAVFile( String name, String mode )  throws IOException
	{
		super( name, mode );
	}
	
	public void writeIntLittle( int n ) throws IOException
	{
		write( n & 0xFF );
		write( (n>>8) & 0xFF );
		write( (n>>16) & 0xFF );
		write( (n>>24) & 0xFF );
	}
	public void writeShortLittle( short n ) throws IOException
	{
		write( n & 0xFF );
		write( (n>>8) & 0xFF );
	}
	
	public void writeFormatChunk( int channelsPerFrame, int sampleRate ) throws IOException
	{
		write('f'); write('m'); write('t'); write(' ');
		writeIntLittle( 16 ); // size
		writeShortLittle( WAVE_FORMAT_PCM );
		writeShortLittle( (short) channelsPerFrame );
		writeIntLittle( sampleRate );
		writeIntLittle( sampleRate*channelsPerFrame*2 ); /* bytes/second */
		writeShortLittle( (short) (channelsPerFrame*2) ); /* block align */
		writeShortLittle( (short) (2*8) ); /* bits per sample */
	}
	
	public void writeDataChunk( short samples[] ) throws IOException
	{
		writeDataChunkHeader( samples.length*2 );
		for( int i=0; i<samples.length; i++ )
		{
			writeShortLittle( samples[i] );
		}
	}
	
	public void writeDataChunkHeader( int size ) throws IOException
	{
		write('d'); write('a'); write('t'); write('a');
		dataSizePosition = getFilePointer();
		writeIntLittle( size ); // size
	}
	
	
	public void writeRIFF( int size ) throws IOException
	{
		write('R'); write('I'); write('F'); write('F');
		riffSizePosition = getFilePointer();
		writeIntLittle( size );
	}
	
	public void writeHeader( int channelsPerFrame, int sampleRate ) throws IOException
	{
/* write RIFF header */
		writeRIFF( 0 );
		write('W'); write('A'); write('V'); write('E');
/* write Format and data chunks */
		writeFormatChunk( channelsPerFrame, sampleRate );
		writeDataChunkHeader( 0 );
	}
	
/** Fix RIFF and data chunk sizes based on final size.
 * Assume data chunk is the last chunk.
 */
	public void fixSizes()  throws IOException
	{
	// adjust RIFF size
		long end = getFilePointer();
		int riffSize = (int) (end - riffSizePosition) - 4;
		seek( riffSizePosition );
		writeIntLittle( riffSize );
	// adjust data size
		int dataSize = (int) (end - dataSizePosition) - 4;
		seek( dataSizePosition );
		writeIntLittle( dataSize );
		System.out.println("riffSize = " + riffSize + ", dataSize = " + dataSize );
	}
		
	public void write( short samples[], int channelsPerFrame, int sampleRate ) throws IOException
	{
		int formSize = 4 + (8+(samples.length*2)) + (8+16); /* RIFF+wave+fmt*/
/* write RIFF header */
		writeRIFF( formSize );
		write('W'); write('A'); write('V'); write('E');
/* write Format and data chunks */
		writeFormatChunk( channelsPerFrame, sampleRate );
		writeDataChunk( samples );
	}
	
	void test1()  throws IOException
	{
		final int FRAME_RATE = 44100;
		final int NUM_SAMPLES = (int) (FRAME_RATE * 10.0);
		short data[] = new short[NUM_SAMPLES];
		short phase = 0;
		for( int i=0; i<NUM_SAMPLES; i++ )
		{
			data[i] = phase;
			phase += 456;
		}
		write( data, 1, FRAME_RATE );
	}
	
	void test2()  throws IOException
	{
		final int FRAME_RATE = 44100;
		final int NUM_SAMPLES = 1000;
		short data[] = new short[NUM_SAMPLES];
		short phase = 0;
		for( int i=0; i<NUM_SAMPLES; i++ )
		{
			data[i] = phase;
			phase += 0x200;
		}
		writeHeader( 1, FRAME_RATE );
	// write out data using a stream to simulate recording
		RandomOutputStream outStream = new RandomOutputStream( this );
		for( int i=0; i<1; i++ )
		{
			for( int k=0; k<NUM_SAMPLES; k++ )
			{
				outStream.write( (byte) data[k] );
				outStream.write( (byte) (data[k]>>8) );
			}
		}
	// go back and fix up the sizes
		fixSizes();
	}
		
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		try
		{
			WAVFile app = new WAVFile("testout.wav", "rw");
			// app.setLength(0); FIXME - only supported in Java 1.2 !!!
			app.test2();
			app.close();
		} catch( IOException e ) {
			System.err.println( e );
		}
		System.exit(0);
	}
	
}
