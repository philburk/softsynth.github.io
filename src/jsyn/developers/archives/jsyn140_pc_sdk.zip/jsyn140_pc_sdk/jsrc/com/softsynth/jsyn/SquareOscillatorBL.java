package com.softsynth.jsyn;
import java.util.*;

/**
 * SquareOscillatorBL unit. It has a woody, clarinet-like sound.
 * This version is band limited and will sound better than SquareOscillator
 * but uses more CPU time to compute.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SquareOscillatorBL extends SynthOscillator
{
 	public SquareOscillatorBL( int calculationRate ) throws SynthException
	{
		super( "Osc_SquareBL", calculationRate, 0 );
	}
/**
 *	Create a SquareOscillatorBL that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SquareOscillatorBL( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
