package com.softsynth.util;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

/**
 * AlertBox class to display error messages.
 *
 * @author (C) 2000 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class AlertBox extends Dialog
{
	TextArea textArea;
	Button   okButton;
	Button   abortButton;
	static   Exception  excp = null;
	static   Frame  topFrame;
	
	public AlertBox( Frame frame, String title )
	{
		super( frame, title, true );
		setLayout( new BorderLayout() );
		setSize( 620, 200 );
		textArea = new TextArea( "", 6, 80, TextArea.SCROLLBARS_BOTH  );
		add( "Center", textArea );
		
		Panel panel = new Panel();
		add( "South", panel );
		
		panel.add( okButton = new Button("Acknowledge") );
		okButton.addActionListener(	new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				hide();
			} } );
		
		panel.add( abortButton = new Button("Abort") );
		abortButton.addActionListener(	new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			} } );
		
		validate();
	}

/** Search up the component hierarchy to find the first Frame
** containing the component.
*/
	public static Frame getFrame( Component c )
	{
		do
		{
			if(c instanceof Frame) return (Frame)c;
		} while((c = c.getParent()) != null);
		return null;
	}
	
	public void showError( String msg )
	{
		textArea.setText( msg );
		show();
	}
}