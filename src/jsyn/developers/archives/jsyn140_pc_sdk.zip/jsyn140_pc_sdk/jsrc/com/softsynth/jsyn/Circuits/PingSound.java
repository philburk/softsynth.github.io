
package com.softsynth.jsyn.circuits;
import java.util.*;
import java.awt.*;
import com.softsynth.jsyn.*;
/**
 * Ping Sound
 * Filters a sawtooth wave. The filter frequency is controlled by a short envelope.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class PingSound extends SynthCircuit
{
	public SawtoothOscillator  myOsc;
	public StateVariableFilter myFilter;
	public EnvelopePlayer      myEnv;
	public MultiplyUnit        freqScalar;
	public SynthEnvelope       myEnvData; 
	int                        numFrames;

/* Declare ports. */
	public SynthInput  frequency;
	public SynthInput  cutoff;
	public SynthInput  resonance;
	public SynthInput  amplitude;
	public SynthInput  rate;

/*
 * Setup synthesis.
 */
	public PingSound()  throws SynthException
	{
		super();

/* Create various unit generators and add them to circuit. */
		add( myOsc = new SawtoothOscillator() );
		add( myFilter = new StateVariableFilter() );
		add( myEnv = new EnvelopePlayer() );
		add( freqScalar = new MultiplyUnit() );

/* Create an envelope and fill it with recognizable data. */
		double[] data =
		{
			0.01, 0.8,  /* duration,value pair for frame[0] */
			0.10, 0.3,  /* duration,value pair for frame[1] */
			0.14, 0.0,  /* duration,value pair for frame[2] */
		};
		numFrames = data.length/2;

		myEnvData = new SynthEnvelope( data );

/* Connect SynthUnits to make control signal path. */
		myEnv.output.connect( myFilter.amplitude );
		myEnv.output.connect( freqScalar.inputA );
		freqScalar.output.connect( myFilter.frequency );
/* Connect SynthUnits to make audio signal path. */
		myOsc.output.connect( myFilter.input );

/* Make ports on internal units appear as ports on circuit. */ 
		addPort( frequency = myOsc.frequency );
		addPort( amplitude = myOsc.amplitude );
		addPort( cutoff = freqScalar.inputB, "Cutoff");
		addPort( resonance = myFilter.resonance );
		addPort( rate = myEnv.rate );
		addPort( output = myFilter.output );

/* Set signal type for filter control so that we can operate in hertz. */
		cutoff.setSignalType( Synth.SIGNAL_TYPE_SVF_FREQ );

		frequency.set(100.0);
		cutoff.set(1000.0);
		resonance.set(0.4);
		amplitude.set(0.2);
		rate.set(1.0);
	}

	public void trigger( int time, double frequency, double level ) throws SynthException
	{
		this.frequency.set( time, frequency );
		amplitude.set( time, level );
		setStage( time, 0 );
	}

	public void trigger()  throws SynthException
	{
		trigger( Synth.getTickCount(), 400.0, 0.5 );
	}

	public void setStage( int time, int stage )  throws SynthException
	{
		switch( stage )
		{
		case 0: 
			stop( time );
			myEnv.envelopePort.clear( time );
			myEnv.envelopePort.queue( time, myEnvData, 0, numFrames, Synth.FLAG_AUTO_STOP );
			start( time );
			break;
		default:
			break;
		}
	}

}

