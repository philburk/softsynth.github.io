package com.softsynth.jsyn;
import java.util.*;

/**
 * ImpulseOscillator unit.
 *
 * This unit is a simple impulse generator. The output is either zero or the
 * Amplitude value. The width of the impulse is one sample. This is useful
 * for pinging filters.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see SawtoothOscillator
 * @see StateVariableFilter
 */

public class ImpulseOscillator extends SynthOscillator 
{

 	public ImpulseOscillator( int calculationRate ) throws SynthException
	{
		super( "Osc_Impulse", calculationRate, 0 );
	}
/**
 *	Create a ImpulseOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public ImpulseOscillator( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
