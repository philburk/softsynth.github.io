package com.softsynth.jsyn;
import java.util.*;

/**
 *	PulseOscillator unit.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class PulseOscillator extends SynthOscillator 
{
/**
 * Level for comparator used to generate pulse wave. 0 gives a 50% duty cycle
 * pulse wave. Positive values cause the positive portion of the pulse to
 * be wider than the negative. Negative values cause the negative portion
 * of the pulse to be wider than the positive. The range is -1.0 to +1.0,
 * defaults to 0.0.
 */
	public SynthInput width;

 	public PulseOscillator( int calculationRate ) throws SynthException
	{
		super( "Osc_Pulse", calculationRate, 0 );
		width = new SynthInput( this, "Width" );
	}
/**
 *	Create a PulseOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public PulseOscillator( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
