package com.softsynth.jsyn;
import java.util.*;

/**
 *	SawtoothOscillator unit.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SawtoothOscillator extends SynthOscillator 
{
 	public SawtoothOscillator( int calculationRate ) throws SynthException
	{
		super( "Osc_Sawtooth", calculationRate, 0 );
	}
/**
 *	Create a SawtoothOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public SawtoothOscillator( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
