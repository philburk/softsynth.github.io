package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthEnvelopeQueue class for Java Audio Synthesis
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see SynthEnvelope
 */

public class SynthEnvelopeQueue extends SynthDataQueue
{
	SynthEnvelopeQueue( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	SynthEnvelopeQueue( SynthSound sound ) throws SynthException
	{
		super( sound, "Data" );
	}

/**
 * Queue all or a portion of this data to be played once on this SynthEnvelopeQueue.
 *
 * If FLAG_AUTO_STOP is set then the unit will stop when the data is finished.
 * If a unit is inside a circuit, then the circuit will be stopped.
 * If that circuit is inside other circuits, then the highest level circuit
 * will be stopped.

 * @exception SynthException	 If frames are out of range.
 */
	public void queue( SynthEnvelope envelope, int startFrame, int numFrames, int flags )
	throws SynthException
	{
		super.queue( envelope, startFrame, numFrames, flags );
	}
	public void queue( SynthEnvelope envelope, int startFrame, int numFrames )
	throws SynthException
	{
		queue( envelope, startFrame, numFrames, 0 );
	}
/** Queue entire envelope to play once. */
	public void queue( SynthEnvelope envelope )
	throws SynthException
	{
		queue( envelope, 0, envelope.getNumFrames(), 0 );
	}

/**
 * Queue all or a portion of this envelope to be played by this SynthUnit in a loop.
 * If there is any envelope data after this in the queue then this portion will not be played.
 *
 * @exception SynthException	 If frames are out of range.
 */
	public void queueLoop( SynthEnvelope envelope, int startFrame, int numFrames )
	throws SynthException
	{
		super.queueLoop( envelope, startFrame, numFrames );
	}
	public void queueLoop( SynthEnvelope envelope )
	throws SynthException
	{
		queueLoop( envelope, 0, envelope.getNumFrames() );
	}
/**
 * Queue all or a portion of this envelope to be played once by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If frames are out of range.
 */
	public void queue( int time, SynthEnvelope envelope, int startFrame, int numFrames )
	throws SynthException
	{
		super.queue( time, envelope, startFrame, numFrames, 0 );
	}
	public void queue( int time, SynthEnvelope envelope )
	throws SynthException
	{
		queue( time, envelope, 0, envelope.getNumFrames() );
	}
/**
 * Queue all or a portion of this envelope to be played in a loop by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If frames are out of range.
 */
	public void queueLoop( int time, SynthEnvelope envelope, int startFrame, int numFrames )
	throws SynthException
	{
		super.queueLoop( time, envelope, startFrame, numFrames );
	}
	public void queueLoop( int time, SynthEnvelope envelope )
	throws SynthException
	{
		queueLoop( time, envelope, 0, envelope.getNumFrames() );
	}

/**
 *	Convenience method that will queue the attack portion of a envelope and the sustain loop if it exists.
 *	This could be used to implement a NoteOn method.
 *
 * @exception SynthException	   TBD
 */
	public void queueOn( int time, SynthEnvelope envelope )
	throws SynthException
	{
		super.queueOn( time, envelope );
	}
	public void queueOn( SynthEnvelope envelope )
	throws SynthException
	{
		queueOn( Synth.getTickCount(), envelope );
	}

/**
 *	Convenience method that will queue the decay portion of a envelope, or the gap and
 *	release loop portions if they exist. 
 *	This could be used to implement a NoteOff method.
 *
 * @exception SynthException	  TBD
 */
	public void queueOff( int time, SynthEnvelope envelope, boolean ifStop )
	throws SynthException
	{
		super.queueOff( time, envelope, ifStop );
	}
	public void queueOff( int time, SynthEnvelope envelope )
	throws SynthException
	{
		queueOff( time, envelope, false );
	}
	public void queueOff( SynthEnvelope envelope )
	throws SynthException
	{
		queueOff( Synth.getTickCount(), envelope, false );
	}

}
