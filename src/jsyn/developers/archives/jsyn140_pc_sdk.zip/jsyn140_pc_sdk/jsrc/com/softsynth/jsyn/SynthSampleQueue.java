package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthSampleQueue class for Java Audio Synthesis
 * This class doesn't do much except generate compile-time
 * errors if you accidentally try to queue envelope data on a sample queue.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthSampleQueue extends SynthDataQueue
{
	SynthSampleQueue( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	SynthSampleQueue( SynthSound sound ) throws SynthException
	{
		super( sound, "Data" );
	}

/**
 * Queue all or a portion of this data to be played once on this SynthSampleQueue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( SynthSample sample, int startFrame, int numFrames, int flags )
	throws SynthException
	{
		super.queue( sample, startFrame, numFrames, flags );
	}
	public void queue( SynthSample sample, int startFrame, int numFrames )
	throws SynthException
	{
		queue( sample, startFrame, numFrames, 0 );
	}
	public void queue( SynthSample sample )
	throws SynthException
	{
		queue( sample, 0, sample.getNumFrames() );
	}

/**
 * Queue all or a portion of this sample to be played by this SynthUnit in a loop.
 * If there is any sample data after this in the queue then this portion will not be played.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( SynthSample sample, int startFrame, int numFrames )
	throws SynthException
	{
		super.queueLoop( sample, startFrame, numFrames );
	}
	public void queueLoop( SynthSample sample )
	throws SynthException
	{
		queueLoop( sample, 0, sample.getNumFrames() );
	}
/**
 * Queue all or a portion of this sample to be played once by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( int time, SynthSample sample, int startFrame, int numFrames )
	throws SynthException
	{
		super.queue( time, sample, startFrame, numFrames, 0 );
	}
	public void queue( int time, SynthSample sample )
	throws SynthException
	{
		queue( time, sample, 0, sample.getNumFrames() );
	}
/**
 * Queue all or a portion of this sample to be played in a loop by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( int time, SynthSample sample, int startFrame, int numFrames )
	throws SynthException
	{
		super.queueLoop( time, sample, startFrame, numFrames );
	}
	public void queueLoop( int time, SynthSample sample )
	throws SynthException
	{
		queueLoop( time, sample, 0, sample.getNumFrames() );
	}

/**
 *	Convenience method that will queue the attack portion of a sample and the sustain loop if it exists.
 *	This could be used to implement a NoteOn method.
 *
 * @exception SynthException	   TBD
 */
	public void queueOn( int time, SynthSample sample )
	throws SynthException
	{
		super.queueOn( time, sample );
	}
	public void queueOn( SynthSample sample )
	throws SynthException
	{
		queueOn( Synth.getTickCount(), sample );
	}

/**
 *	Convenience method that will queue the decay portion of a sample, or the gap and
 *	release loop portions if they exist. 
 *	This could be used to implement a NoteOff method.
 *
 * @exception SynthException	  TBD
 */
	public void queueOff( int time, SynthSample sample, boolean ifStop )
	throws SynthException
	{
		super.queueOff( time, sample, ifStop );
	}
	public void queueOff( int time, SynthSample sample )
	throws SynthException
	{
		super.queueOff( time, sample, false );
	}
	public void queueOff( SynthSample sample )
	throws SynthException
	{
		queueOff( Synth.getTickCount(), sample, false );
	}
}
