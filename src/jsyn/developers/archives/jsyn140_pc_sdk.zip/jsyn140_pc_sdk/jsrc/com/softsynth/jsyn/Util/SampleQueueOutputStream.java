
package com.softsynth.jsyn.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** 
 * Adds streaming write capabilities to a SynthSampleQueue.
 * The queue must be on a unit that will read data from the queue
 * such as a SampleReader_16F1. Data is written to the sample that
 * will then later be read by the SampleReader.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class SampleQueueOutputStream extends SampleQueueStream
{
	
	public SampleQueueOutputStream( SynthSampleQueue queue, int bufferSizeInFrames, int channelsPerFrame )
	{
		super( queue,  bufferSizeInFrames, channelsPerFrame );
	}
	
/** Return true if the buffer has underflowed and data was not supplied in time.
 * To prevent this, use a larger buffer, or write the data more often.
 */
	public boolean getUnderflowed()
	{
		available();
		return flowError;
	}
	
/** Return the number of frames when this stream has been drained.
 */
	int getNumWhenSatisfied()
	{
		return sample.getNumFrames();
	}
	
/** Write an array of short data to the sample.
* If there is not enough room available, block until all of the data can be written.
* To avoid blocking, call available() first to see how much can be written without blocking.
* @param data Array of shorts containing PCM sample data
* @param offset index of array to start writing data from
* @param numFrames number of frames to write to sample
* @return number of frames read
*/
	public int write( short data[], int offset, int numFrames )
	{
		return move( data, offset, numFrames );
	}

/** Wait until any data that has been written to the queue has been played.
 * Call this when you want to make sure you hear the last little bit of a sound.
 * @return frames not played if the stream is stopped.
 */
	public int flush()
	{
	// calculate how many frames are remaining to be played
		int framesLeft = getNumWhenSatisfied() - available();
		if( !running ) return framesLeft;
		int ticksToSleep = framesLeft / Synth.getFramesPerTick();
		Synth.sleepForTicks( ticksToSleep + 1 );
		return 0;
	}

	void moveDirect( int moveIndex, short data[], int offset, int numFrames )
	{ 
		sample.write( moveIndex, data, offset, numFrames );
	}
}
