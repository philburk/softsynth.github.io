package com.softsynth.jsyn;
import java.util.*;

/**
 * TableOscillator uses an interpolating table lookup to calculate its output.
 * If you want the waveform to loop smoothly, like a sinewave, then set the
 * last point equal to the beginning point. For a 256 point sinewave,
 * allocate a 256+1=257 entry table then set Table[256] = Table[0];
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see SynthTable
 * @see SynthTablePort
 */

public class TableOscillator extends SynthOscillator 
{
	public SynthTablePort tablePort;

 	public TableOscillator( int calculationRate ) throws SynthException
	{
		super( "Osc_Table", calculationRate, 0 );
		tablePort = new SynthTablePort( this, "Table" );
	}
/**
 *	Create a TableOscillator that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public TableOscillator( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
