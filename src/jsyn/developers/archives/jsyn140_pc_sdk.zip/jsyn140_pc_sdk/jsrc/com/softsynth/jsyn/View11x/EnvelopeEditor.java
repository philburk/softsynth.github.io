package com.softsynth.jsyn.view11x;
import com.softsynth.jsyn.*;
import com.softsynth.util.NumericOutput;
import java.util.*;
import java.awt.*;

/**
 * Edit a vector of ordered duration,value pairs.
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

/* ========================================================================== */
public class EnvelopeEditor extends XYController
{
	EnvelopePoints points;
	Vector       listeners;
	int          dragIndex = -1;
	double       dragLowLimit;
	double       dragHighLimit;
	double       dragPoint[];
	double       xBefore;        // WX value before point
	double       xPicked;       // WX value of picked point
	double       dragWX;
	double       dragWY;
	int          maxPoints = Integer.MAX_VALUE;
	int          radius = 3;
	double       verticalBarSpacing = 1.0;
	boolean      verticalBarsEnabled = false;
	double       maximumXRange = Double.MAX_VALUE;
	double       minimumXRange = 0.1;
	
	public EnvelopeEditor()
	{
		listeners = new Vector();
	}
	
	public void setMaximumXRange( double maxXRange )
	{
		maximumXRange = maxXRange;
	}
	public double getMaximumXRange()
	{
		return maximumXRange;
	}
	public void setMinimumXRange( double minXRange )
	{
		minimumXRange = minXRange;
	}
	public double getMinimumXRange()
	{
		return minimumXRange;
	}
	
/** Add a listener to receive edit events.
 *  Listener will be passed the editor object and the edited object.
 */
	public void addEditListener( EditListener listener )
	{
		listeners.addElement( listener );
	}
	public void removeEditListener( EditListener listener )
	{
		listeners.removeElement( listener );
	}
	
/** Send event to every subscribed listener. */
	private void tellListeners()
	{
		Enumeration e = listeners.elements();
		while( e.hasMoreElements() )
		{
			EditListener listener = (EditListener) e.nextElement();
	 		listener.objectEdited( (Object) this, (Object) points );
		}
	}

	public void setMaxPoints( int maxPoints )
	{
		this.maxPoints = maxPoints;
	}
	
	public int getMaxPoints( )
	{
		return maxPoints;
	}
	public int getNumPoints( )
	{
		return points.size();
	}

	public void setPoints( EnvelopePoints points )
	{
		this.points = points;
		setMaxWorldY( points.getMaximumValue() );
	}
	public EnvelopePoints getPoints()
	{
		return points;
	}
	
/** Return index of point before this X position.
 */
	public int findPointBefore( double wx )
	{
		int pnt = -1;
		double px = 0.0;
		xBefore = 0.0;
		for( int i=0; i<points.size(); i++ )
		{
			px  += points.getPoint( i )[0];
			if( px > wx ) break;
			pnt = i;
			xBefore = px;
		}
		return pnt;
	}
	
	int pickPoint( double wx, double wxAperture, double wy, double wyAperture )
	{
		double px = 0.0;
		double wxLow = wx - wxAperture;
		double wxHigh = wx + wxAperture;
		// System.out.println("wxLow = " + wxLow + ", wxHigh = " + wxHigh );
		double wyLow = wy - wyAperture;
		double wyHigh = wy + wyAperture;
		// System.out.println("wyLow = " + wyLow + ", wyHigh = " + wyHigh );
		double wxScale = 1.0 / wxAperture;  // only divide once, then multiply
		double wyScale = 1.0 / wyAperture;
		int bestPoint = -1;
		double bestDistance = Double.MAX_VALUE;
		for( int i=0; i<points.size(); i++ )
		{
			double dar[] = points.getPoint( i );
			px += dar[0];
			double py = dar[1];
			// System.out.println("px = " + px + ", py = " + py );
			if( (px > wxLow) && (px < wxHigh) && (py > wyLow) && (py < wyHigh) )
			{
				/* Inside pick range. Calculate distance squared. */
				double ndx = (px-wx) * wxScale;
				double ndy = (py-wy) * wyScale;
				double dist = (ndx*ndx) + (ndy*ndy);
				// System.out.println("dist = " + dist );
				if( dist < bestDistance )
				{
					bestPoint = i;
					bestDistance = dist;
					xPicked = px;
				}
			}
		}
		return bestPoint;
	}
		
	void clickDown( boolean shiftDown, int gx, int gy )
	{	
		dragIndex = -1;
		double wx = convertGXtoWX( gx );
		double wy = convertGYtoWY( gy );
	// calculate world values for aperture
		double wxAp = convertGXtoWX( radius + 2 ) - convertGXtoWX( 0 );;
		// System.out.println("wxAp = " + wxAp );
		double wyAp = convertGYtoWY( 0 ) - convertGYtoWY( radius + 2 );
		// System.out.println("wyAp = " + wyAp );
		int pnt = pickPoint( wx, wxAp, wy, wyAp );
		// System.out.println("pickPoint = " + pnt);
		if( shiftDown )
		{
			if( pnt >= 0 )
			{
				points.removeElementAt( pnt );
				repaint();
			}
		}
		else
		{
			if( pnt < 0 ) // didn't hit one so look for point to left of click
			{
				if( points.size() < maxPoints ) // add if room
				{
					pnt = findPointBefore( wx );
					// System.out.println("pointBefore = " + pnt);
					dragIndex = pnt+1;
					if( pnt == (points.size()-1) )
					{
						points.add( wx - xBefore, wy );
					}
					else
					{
						points.insert( dragIndex, wx - xBefore, wy );
					}
					dragLowLimit = xBefore;
					dragHighLimit = wx + (maximumXRange - points.getTotalDuration());
					repaint();
				}
			}
			else // hit one so drag it
			{
				dragIndex = pnt;
				if( dragIndex <= 0 ) dragLowLimit = 0.0; // FIXME
				else dragLowLimit = xPicked - points.getPoint( dragIndex )[0];
				dragHighLimit = xPicked + (maximumXRange - points.getTotalDuration());
				// System.out.println("dragLowLimit = " + dragLowLimit );
			}
		}
	// Set up drag point if we are dragging.
		if( dragIndex >= 0 )
		{
			dragPoint = points.getPoint( dragIndex );
		}

	}
	
	void drag( int gx, int gy )
	{
		if( dragIndex < 0 ) return;
		
		double wx = convertGXtoWX( gx );
		if( wx < dragLowLimit ) wx = dragLowLimit;
		else if( wx > dragHighLimit ) wx = dragHighLimit;
		dragPoint[0] = wx - dragLowLimit; // duration

		double wy = convertGYtoWY( gy );
		wy = clipWorldY( wy );
		dragPoint[1] = wy;
		dragWY = wy;
		dragWX = wx;
		repaint();
	}
		
	void clickUp( int gx, int gy )
	{
		drag( gx, gy );
		tellListeners();
	}
	
/* Respond to 1.0.2 style AWT mouse actions. */
	public boolean mouseDown( Event evt, int gx, int gy )
	{
		clickDown( evt.shiftDown(), gx, gy );
		return true;
	}
	public boolean mouseDrag( Event evt, int x, int y )
	{
		drag( x, y );
		return true;
	}
	public boolean mouseUp( Event evt, int x, int y )
	{
		clickUp( x, y );
		return true;
	}

/** Override this to draw a grid or other stuff under the envelope.
 */
	public void drawUnderlay( Graphics g )
	{
		if( verticalBarsEnabled ) drawVerticalBars( g );
	}
	
	
	public void setVerticalBarsEnabled( boolean flag )
	{
		verticalBarsEnabled = flag;
	}
	public boolean getVerticalBarsEnabled()
	{
		return verticalBarsEnabled;
	}
	
/** Set spacing in world coordinates.
 */
	public void setVerticalBarSpacing( double spacing )
	{
		verticalBarSpacing = spacing;
	}
	public double getVerticalBarSpacing()
	{
		return verticalBarSpacing;
	}
/** Draw vertical lines.
 */
	void drawVerticalBars( Graphics g )
	{
		int width = bounds().width;
		int height = bounds().height;
		double wx = verticalBarSpacing;
		int    gx;

		g.setColor( Color.gray );
		while( true )
		{
			gx = convertWXtoGX( wx );
			if( gx > width ) break;			
			g.drawLine( gx, 0, gx, height );
			wx += verticalBarSpacing;
		}
	}
		
	void drawPoints( Graphics g, Color lineColor )
	{
		double wx = 0.0;
		int gx1 = 0;
		int gy1 = bounds().height;
		for( int i=0; i<points.size(); i++ )
		{
			double dar[] = (double []) points.elementAt(i);
			wx += dar[0];
			double wy = dar[1];
			int gx2 = convertWXtoGX( wx );
			int gy2 = convertWYtoGY( wy );
			if( i == 0 )
			{
				g.setColor( isEnabled() ? Color.blue : Color.blue.darker() );
				g.drawLine( gx1, gy1, gx2, gy2 );
				g.setColor( isEnabled() ? lineColor : lineColor.darker() );
			}
			else if ( i > 0 )
			{
				g.drawLine( gx1, gy1, gx2, gy2 );
			}
			int diameter = (2*radius) + 1;
			g.fillOval( gx2 - radius, gy2 - radius, diameter, diameter );
			gx1 = gx2;
			gy1 = gy2;
		}
	}

	void drawAllPoints( Graphics g )
	{
		drawPoints( g, getForeground() );
	}
	
/* Override default paint action. */
	public void paint( Graphics g )
	{
		double wx = 0.0;
		int width = bounds().width;
		int height = bounds().height;
		
// draw background and erase all values
		g.setColor( isEnabled() ? getBackground() : getBackground().darker() );
		g.fillRect( 0, 0, width, height );
				
// Determine total duration.
		if( points.size() > 0 )
		{
			wx = points.getTotalDuration();
			if( wx > getMaxWorldX() )
			{
				if( wx <= maximumXRange ) setMaxWorldX( wx );
			}
			else if( wx < (getMaxWorldX()*0.7) )
			{
				double newMax = wx/0.7;
				if( newMax >= minimumXRange )  setMaxWorldX( newMax );
			}
		}
		// System.out.println("total X = " + wx );
		
		drawUnderlay( g );
		
		drawAllPoints( g );
		
	/* Show X,Y,TotalX as text. */
		g.drawString( points.getName() +
					  ", len=" +
					  NumericOutput.doubleToString( wx, 7, 3 ),
					  5, 15 );
		if( dragPoint != null )
		{
			String s = "i=" + dragIndex + ", dur=" +
					   NumericOutput.doubleToString( dragPoint[0], 7, 3 )
					   + ", y = " +
					   NumericOutput.doubleToString( dragPoint[1], 8, 4 );
			g.drawString( s, 5, 30 );
		}
	}
}
