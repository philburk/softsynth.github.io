package com.softsynth.jsyn;
import java.util.*;

/**
 *	RedNoise unit.
 *
 This unit interpolates straight line segments between pseudo-random numbers
to produce "red" noise. It is a grittier alternative to the white generator
Noise_White. It is also useful as a slowly changing random control generator
for natural sounds. Frequency port controls the number of times per second
that a new random number is chosen.

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 * @see WhiteNoise
 */

public class RedNoise extends SynthOscillator
{
 	public RedNoise( int calculationRate ) throws SynthException
	{
		super( "Noise_Red", calculationRate, 0 );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
	public RedNoise( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
