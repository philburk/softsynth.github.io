package com.softsynth.jsyn;
import java.util.*;

/**
 * LineIn unit.
 * Outputs stereo signal from audio line in or microphone.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 0014
 * @see Synth
 * @see SynthUnit
 */

public class LineIn extends SynthUnit 
{
/**
 * input - 2 parts, 0=Left, 1=Right.
 * Stereo signal from ADC.
 */
	public SynthOutput output;

 	public LineIn( int calculationRate ) throws SynthException
	{
		super( "Line_In", calculationRate, 0 );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public LineIn( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
