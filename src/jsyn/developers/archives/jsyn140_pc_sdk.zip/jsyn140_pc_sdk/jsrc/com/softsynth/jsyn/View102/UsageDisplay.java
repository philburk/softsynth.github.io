package com.softsynth.jsyn.view102;
import java.util.*;
import java.awt.*;
import java.applet.*;
import com.softsynth.jsyn.*;
/**
 * Display percent CPU utilization.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class UsageDisplay extends Panel
{
	Button  updateButton;
	Label   usageLabel;

	public UsageDisplay()
	{
		add( updateButton = new Button( "Usage" ) );
		add( usageLabel = new Label( "????" ) );
	}

	void updateDisplay()
	{
		double usage = Synth.getUsage();
		int percent = (int) (usage * 100.0); /* Chop trailing digits. */
		usageLabel.setText( Integer.toString(percent) + "%");
	}
	
	public boolean action(Event evt, Object what)
	{
		if( evt.target == updateButton )
		{
			updateDisplay();
			return true;
		}
		return false;
    }
}
