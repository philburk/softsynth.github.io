package com.softsynth.jsyn;
import java.util.*;

/**
 *	Tracks the peaks of an input signal.
 * This can be used to monitor the overall amplitude of a signal.
 * The output can be used to drive color organs, vocoders,
 * VUmeters, etc.
 *
 * Output drops exponentially when the input drops below the current output level. 
 * The output approaches zero based on the value on the halfLife port.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 013
 * @see Synth
 * @see SynthUnit
 */

public class PeakFollower extends SynthUnit 
{
/** Signal to approach. SIGNAL_TYPE_RAW_SIGNED */
	public SynthInput input;
	
/** Controls rate at which to approach input.
 * If the input is zero, then the output will go from its current value halfway to zero in 
 * the time specified using this port.  Note: not connectable. SIGNAL_TYPE_HALF_LIFE
 */
	public SynthVariable halfLife;
/**
 * Current internal value.  This may be tweaked to force the output to a value immediately.
 * It can be used to generate an inexpensive decaying envelope by forcing the current value
 * to a number above zero.
*/
	public SynthVariable current;
	public SynthOutput output;

 	public PeakFollower( int calculationRate ) throws SynthException
	{
		super( "Lag_PeakFollower", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		halfLife = new SynthVariable( this, "HalfLife" );
		current = new SynthVariable( this, "Current" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a PeakFollower that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public PeakFollower( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
