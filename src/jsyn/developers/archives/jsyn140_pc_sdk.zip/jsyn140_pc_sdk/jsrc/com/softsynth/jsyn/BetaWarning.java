package com.softsynth.jsyn;
import java.util.*;
import java.awt.*;
import java.applet.*;
/**
 * Warning for Beta Version - not used.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

class BetaWarning extends Dialog
{
	Button           okButton;
	Button           cancelButton;
	TextArea         textArea;
	public boolean   accepted = false;

	BetaWarning( Frame frame, Date expires, long remaining )
		throws SynthException
	{
		super( frame, "JSyn Beta V" + Synth.getVersion() , true );  /* true for modal */
		setLayout( new FlowLayout() );

		resize( 450, 400 );
		textArea = new TextArea("JSyn is Copyright 1997 Phil Burk - All Rights Reserved\n", 14, 60);
		
		textArea.appendText( "This is a beta test copy of JSyn, an Audio Synthesiser Plugin for Java.\n" );
		if( remaining < 0 )
		{
			
			textArea.appendText("NOTE: Your copy has EXPIRED! Please visit:\n\n" );
			textArea.appendText("      http://www.softsynth.com/jsyn\n\n" );
		}
		else
		{
			textArea.appendText("Your copy of JSyn will EXPIRE on:\n\n");
			textArea.appendText("      " + expires + "\n\n");
		}
		textArea.appendText( "JSyn is CONFIDENTIAL and PROPRIETARY.\n" );
		textArea.appendText( "JSyn may NOT be redistributed by any means.\n" );
		textArea.appendText( "Software available AS IS with no warranty of fitness\n" );
		textArea.appendText( "or suitability for any purpose. Use at your own risk.\n" );
		textArea.appendText( "Please direct bug reports to: philburk@softsynth.com\n" );

		add( textArea );
		add( okButton = new Button("I Have Read and Accept the Above Terms.") );
		add( cancelButton = new Button("Cancel.") );
	}

	public boolean action(Event evt, Object what)
	{
		if( evt.target == okButton )
		{
			dispose();
			accepted = true;
			return true;
		}
		else if( evt.target == cancelButton )
		{
			dispose();
			return true;
		}
		return false;
    }

}

