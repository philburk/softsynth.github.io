package com.softsynth.view;

/************************************************************************
 * Custom Fader that generates floating point values.
 */
public class CustomFaderDouble extends com.softsynth.view.CustomFader
{
	double     min,max;
	protected final static int RANGE = 2000;

	public CustomFaderDouble( int orientation, double initialValue, double min, double max )
	{
		super( orientation, 0, RANGE/20, 0, RANGE );
		this.min = min;
		this.max = max;
		setValue( initialValue );
		setUnitIncrement( RANGE/100 );
	}

	public double faderToDouble( int val )
	{
			return ((val*(max-min))/RANGE) + min;
	}
	
	public int doubleToFader( double fval )
	{
			return (int)(((fval - min)*RANGE)/(max-min));
	}

	public double getMinimum() { return min; }
	public double getMaximum() { return max; }
	
/** Set minimum value corresponding to the leftmost fader position. */
	public void setMinimum( double min )
	{
		this.min = min;
	}
/** Set maximum value corresponding to the rightmost fader position. */
	public void setMaximum( double max )
	{
		this.max = max;
	}
	
	public void setValue( double fval )
	{
		int ival = doubleToFader( fval );
		super.setValue( ival );
	}
}
