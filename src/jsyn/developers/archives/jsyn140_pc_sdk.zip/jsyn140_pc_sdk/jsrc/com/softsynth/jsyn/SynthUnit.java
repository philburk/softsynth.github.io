package com.softsynth.jsyn;
import java.util.*;

/**
 *	SynthUnits are the root class class for unit generators. Units are functional
 *  building blocks for doing audio synthesis.
 *	SynthUnits include oscillators, filters, multipliers, etc. 
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SineOscillator
 */


public class SynthUnit extends SynthSound
{
/* FIXME - Control Rate
 *	Also determines the rate at which the SynthUnit will be calculated.
 *	The calculationRate may be either Synth.RATE_AUDIO, or Synth.RATE_CONTROL.
 * Use audio rate for units that generate or process sound like oscillators or filters.
 * A unit running at control rate consumes
 * fewer processor cycles but has a more coarse output.  Use control rate
 * for slowly changing signals like LFOs, envelopes, and math units that operate
 * on slowly changing signals.
 */
/**
 *	Construct an instrument of the given type.
 *
 * @exception SynthException	 If name does not match list of valid units.
 *            Note that match is case sensitive.
*/

 	public SynthUnit( String unitName, int calculationRate, int param ) throws SynthException
	{
		int unitHash = Synth.hashName( unitName );
		name = unitName;
		peerToken = Synth.CreateUnit( unitHash, calculationRate, param );
		if( peerToken < 0 )
		{
/* Maybe it failed because of lack of resources. Do a garbage collect and try again. */
			Synth.reclaim();
			peerToken = Synth.CreateUnit( unitHash, calculationRate, param );
			if( peerToken < 0 )
			{
				throw new SynthException( peerToken, unitName, param );
			}
		}
		if( Synth.verbosity >= Synth.TERSE )
		{
			System.out.println("new SynthUnit(" + unitName + ") => " + Integer.toHexString(peerToken));
		}
	}
	
 	public SynthUnit( String unitName, int calculationRate ) throws SynthException
	{
		this( unitName, calculationRate, 0 );
	}

/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If name does not match list of valid units.
 *            Note that match is case sensitive.
 */
 	public SynthUnit( String unitName ) throws SynthException
	{
		this( unitName, Synth.RATE_AUDIO );
	}


}
