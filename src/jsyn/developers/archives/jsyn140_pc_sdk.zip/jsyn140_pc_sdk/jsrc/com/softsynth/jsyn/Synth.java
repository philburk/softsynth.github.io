// Search for PLUGIN and APPLICATION to see what code needs to be switched.
package com.softsynth.jsyn;
import java.util.*;
import com.softsynth.util.*;

/* The JRI used for Netscape is not reentrant so methods must be declared synchronized
 * for the plugin. But the JDirect interface does not support synchronized methods so
 * we turn it off for applications.
 */
/*    /*synchronized/**/ // PLUGIN natives should be synchronized 1/3

/**
 *	This class provides access to the 'C' based audio synthesis
 *  engine through the Java native method interface.
 *  It also provides methods for starting and stopping the JSyn synthesis engine,
 * getting timing information, and for sleeping.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see SynthUnit
 * @see SynthSample
 * @see SynthEnvelope
 * @see SynthTable
 */
public class Synth  // APPLICATION 2/2
//public class Synth  extends netscape.plugin.Plugin  // PLUGIN 2/3
{
/** The isPlugin variable is used to prevent maliscious developers from using
 * the microphone without permission in an Applet.
 */
	public final static boolean isPlugin = true; // PLUGIN 3/3
	public final static int VERSION = 140;  /* Update this to match "cs_shared.h" */
	public final static String copyright = "Copyright 2000 Phil Burk, All Rights Reserved";

	static  // Static loader only loads native code if initial call to getVersion fails.
	{
		try
		{
			int vsn = getVersion(); // This will work when using JDirect or Netscape Plugin.
			System.out.println("JSyn via Netscape Plugin or JDirect - V" + vsn );  
			System.out.println("Methods are /*synchronized/**/." );
		} catch (UnsatisfiedLinkError e1) {
// Looks like we need to explicitly load the library.
			String libName = "JSynV" + VERSION;  // Native library for PC
			try
			{
				System.loadLibrary(libName);
				System.out.println("Using native library " + libName );
			}
			catch (UnsatisfiedLinkError e2)
			{
				libName = "JSynNative";  // Native library for Macintosh
				try
				{
					System.loadLibrary(libName);
					System.out.println("Using native library " + libName );
				}
				catch (UnsatisfiedLinkError e3)
				{
					System.err.println("Could not load native library for JSyn!");
					throw e3;
				}
			}
		}
	}
	
/* */
	static SynthSleeper sleeper;
	static int          flags = 0;
	static boolean      gotInputPermission = false;
	
/** Set Synth.verbosity to Synth.SILENT, TERSE, or VERBOSE for increasing levels 
 * of debug output.
 * @depracated Use setTrace() instead.
 */
	public       static int verbosity = 0;
/** Is engine started? */
	public       static int openCount = 0;

/** Value for verbosity, no debug output. */
	public final static int SILENT = 0;
/** Value for verbosity, sparse debug output. */
	public final static int TERSE = 1;
/** Value for verbosity, full debug output. */
	public final static int VERBOSE = 2;

	public final static int RATE_AUDIO = 0;
//	public final static int RATE_CONTROL = 1;
/** Priority for SynthUnit execution. */
	public final static int PRIORITY_LOW = 0;
	public final static int PRIORITY_MEDIUM = 1;
	public final static int PRIORITY_HIGH = 2;
/** Signed signal in the range of -1.0 to +1.0 */	
	public final static int SIGNAL_TYPE_RAW_SIGNED = 0;
/** UNSigned signal in the range of 0.0 to +2.0 */	
	public final static int SIGNAL_TYPE_RAW_UNSIGNED = 1;
/** Oscillator frequency in Hertz in the range of +/- Samplerate/2 */	
	public final static int SIGNAL_TYPE_OSC_FREQ = 2;
/** Sample reader rate in the range of 0.0 to Samplerate*2 */	
	public final static int SIGNAL_TYPE_SAMPLE_RATE = 3;
/** Halflife in seconds. */	
	public final static int SIGNAL_TYPE_HALF_LIFE = 4;
/** Time in seconds. */	
	public final static int SIGNAL_TYPE_TIME = 5;
/** Frequency for StateVariableFilter in Hertz. */	
	public final static int SIGNAL_TYPE_SVF_FREQ = 6;
/** General signal type for full range scalars. */	
	public final static int SIGNAL_TYPE_FULL_RANGE = 7;
/** Number of signal types supported. */	
	public final static int NUM_SIGNAL_TYPES = 8; // Should be one more than previous type!
	
/** Request that the synthesis occur as fast as possible, which may be slower
 * or faster than real-time. Actual synthesis will occur during calls to sleepUntilTick();
 */
	public final static int FLAG_NON_REAL_TIME = (1<<2);
/**
 * FLAG_LOOP_IF_LAST is used with SynthEnvelopeQueue and SynthSampleQueue to
 * request that the last block of data queued be looped until another block is queued.
 * This is useful for sustained waveforms, or LFOs made from envelope sections.
 */
	public final static int FLAG_LOOP_IF_LAST = (1<<3);
/**
 * FLAG_AUTO_STOP is used with SynthEnvelopeQueue and SynthSampleQueue to
 * make an instrument stop automatically when the data is finished.
 */
	public final static int FLAG_AUTO_STOP =    (1<<4);
/**
 * FLAG_ENABLE_INPUT turns on the audio capture feature.
 */
	public final static int FLAG_ENABLE_INPUT =    (1<<5);
/**
 * FLAG_DISABLE_OUTPUT turns off the audio output feature for machines that do not support full duplex recording.
 */
	public final static int FLAG_DISABLE_OUTPUT =    (1<<6);
	final static int JS_ERR_BASE = -200;  /* 'C' base in SynGen.h starts at -100 */
	final static int JS_ERR_CIRCUIT_CLOSED = JS_ERR_BASE - 0;
	final static int JS_ERR_OBSOLETE = JS_ERR_BASE - 1;
	final static int JS_ERR_EXPIRED = JS_ERR_BASE - 2;
	final static int JS_ERR_OUT_OF_RANGE = JS_ERR_BASE - 3;
	final static int JS_ERR_USER = JS_ERR_BASE - 4; // update this when adding new errors
	public final static int DEBUG_REPORT = 1;  /* Pass to debug() - MUST MATCH CSyn.h */
	public final static int DEBUG_THREAD = 2;  /* Pass to debug() - MUST MATCH CSyn.h */
	public final static int DEBUG_GET_ALLOCS = 5;  /* Pass to debug() - MUST MATCH CSyn.h */
/** Variable that can be used by applications to schedule algorithmically generated events
 * a minimum time in the future. Is not used internally by JSyn.
 */
	public static int timeAdvance = 100;
	public final static double DEFAULT_FRAME_RATE = 44100.0;
	static double           millisPerTick;

	/** @dll.import("JSynV140",entrypoint="CSyn_StartEngine") */
	native /*synchronized/**/ static int StartEngine( int flags, double frameRate );  /* Opens connection to SynGen. */
	/** @dll.import("JSynV140",entrypoint="CSyn_StopEngine") */
	native /*synchronized/**/ static int StopEngine( );

	/** @dll.import("JSynV140",entrypoint="CSyn_Start") */
	native /*synchronized/**/ static int Start( int flags, double frameRate );  /* Starts synthesis process. */
	/** @dll.import("JSynV140",entrypoint="CSyn_Stop") */
	native /*synchronized/**/ static int Stop( );

	/** @dll.import("JSynV140",entrypoint="CSyn_Initialize") */
	native /*synchronized/**/ static int Initialize();  /* Initialize synthesis library. */
	/** @dll.import("JSynV140",entrypoint="CSyn_Terminate") */
	native /*synchronized/**/ static int Terminate( );

/**
 *	Returns the fraction of critical resources used by synthesis engine.
 *  A value of 0.5 would be 50%.
 *
 *	@return fraction of resources used.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetUsage") */
	public native /*synchronized/**/ static double getUsage( );
/**
 *	Returns the expiration date for this version of JSyn.
 *  Licensed copies will return 0 for NO expiration.
 *  Date is a single integer in the format (((Y*100)+M*100)+D), eg. 19970831
 *
 *	@return expiration date
 */
/** @dll.import("JSynV140",entrypoint="CSyn_GetExpirationDate") */
	public native /*synchronized/**/ static int getExpirationDate( );
/**
 *	@return Number of units, samples, tables and other objects allocated.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetObjectCount") */
	public native /*synchronized/**/ static int getObjectCount( );
	
/**
 *	Returns index of last calculated frame.
 *	The frame index will tend to jump upwards because frames are calculated in 
 *	large blocks by a high priority process.
 *
 *	@return Index of last calculated frame.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetFrameCount") */
	public native /*synchronized/**/ static int getFrameCount( );
/** Get current time in ticks. This is the basic clock use for scheduling in JSyn.
 *	@return Count of synthesis ticks.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetTickCount") */
	public native /*synchronized/**/ static int getTickCount( );
	
/**
 * Used by sleep routines to keep FIFOs clear.
 *	@return errors from Synth engine running in background.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_CheckEngineErrors") */
	native /*synchronized/**/ static  int CheckEngineErrors( );

/**
 *	@return Number of audio frames per clock tick.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetFramesPerTick") */
	public native /*synchronized/**/ static int getFramesPerTick( );
	
/** Rate that frames are generated, typically 44100.0.
 *	@return Number of audio frames per second.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetFrameRate") */
	public native /*synchronized/**/ static double getFrameRate( );
/**
 *	@return Number of clock ticks per second.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetTickRate") */
	public native /*synchronized/**/ static double getTickRate( );
/**
 * @return Version number of native synth library.
 */
	/** @dll.import("JSynV140",entrypoint="CSyn_GetVersion") */
	public native /*synchronized/**/ static int getVersion( );
	/** @dll.import("JSynV140",entrypoint="CSyn_CreateUnit") */
	native /*synchronized/**/ static int CreateUnit( int unitHash, int rate, int param );  /* Make a unit generator. */
	/** @dll.import("JSynV140",entrypoint="CSyn_CreateCircuit") */
	native /*synchronized/**/ static int CreateCircuit( int[] unitArray, int numUnits, int flags );
	/** @dll.import("JSynV140",entrypoint="CSyn_Delete") */
	native /*synchronized/**/ static int Delete(  int token );  /* Delete a synth object. */
	/** @dll.import("JSynV140",entrypoint="CSyn_StopUnit") */
	native /*synchronized/**/ static int StopUnit( int unit );
	/** @dll.import("JSynV140",entrypoint="CSyn_StartUnit") */
	native /*synchronized/**/ static int StartUnit( int unit );
	/** @dll.import("JSynV140",entrypoint="CSyn_StopUnitAt") */
	native /*synchronized/**/ static int StopUnitAt( int time, int unit );
	/** @dll.import("JSynV140",entrypoint="CSyn_StartUnitAt") */
	native /*synchronized/**/ static int StartUnitAt( int time, int unit );
	/** @dll.import("JSynV140",entrypoint="CSyn_ConnectUnits") */
	native /*synchronized/**/ static int ConnectUnits( int srcUnit, int srcPortHash, int srcPartNum,
                              int dstUnit, int dstPortHash, int dstPartNum );
	/** @dll.import("JSynV140",entrypoint="CSyn_DisconnectUnits") */
	native /*synchronized/**/ static int DisconnectUnits( int dstUnit, int dstPortHash, int partNum );
	/** @dll.import("JSynV140",entrypoint="CSyn_SetPriority") */
	native /*synchronized/**/ static int SetPriority( int token, int priority );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetPriority") */
	native /*synchronized/**/ static int GetPriority( int token );
	/** @dll.import("JSynV140",entrypoint="CSyn_SetPort") */
	native /*synchronized/**/ static int SetPort( int token, int portHash, int partNum, double value );
	/** @dll.import("JSynV140",entrypoint="CSyn_SetPortAt") */
	native /*synchronized/**/ static int SetPortAt( int time, int token, int portHash, int partNum, double value );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetPort") */
	native /*synchronized/**/ static double GetPort( int token, int portHash, int partNum );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetPortFrames") */
	native /*synchronized/**/ static int GetPortFrames( int token, int portHash, int partNum );
	/** @dll.import("JSynV140",entrypoint="CSyn_SetPortSignalType") */
	native /*synchronized/**/ static int SetPortSignalType( int token, int portHash, int partNum, int signalType );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetPortSignalType") */
	native /*synchronized/**/ static int GetPortSignalType( int token, int portHash, int partNum );
	/** @dll.import("JSynV140",entrypoint="CSyn_CreateSample") */
	native /*synchronized/**/ static int CreateSample( int numBytes, int flags );
	/** @dll.import("JSynV140",entrypoint="CSyn_WriteSampleJava") */
	native /*synchronized/**/ static int WriteSample( int sample, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_ReadSampleJava") */
	native /*synchronized/**/ static int ReadSample( int sample, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_CreateEnvelope") */
	native /*synchronized/**/ static int CreateEnvelope( int numFrames );
	/** @dll.import("JSynV140",entrypoint="CSyn_WriteEnvelopeJava") */
	native /*synchronized/**/ static int WriteEnvelope( int envel, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_ReadEnvelopeJava") */
	native /*synchronized/**/ static int ReadEnvelope( int envel, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_ClearDataQueue") */
	native /*synchronized/**/ static int ClearDataQueue( int unit, int portHash );
	/** @dll.import("JSynV140",entrypoint="CSyn_ClearDataQueueAt") */
	native /*synchronized/**/ static int ClearDataQueueAt( int time, int unit, int portHash );
	/** @dll.import("JSynV140",entrypoint="CSyn_QueueData") */
	native /*synchronized/**/ static int QueueData( int unit, int portHash, int token, int startFrame, int numFrames, int flags );
	/** @dll.import("JSynV140",entrypoint="CSyn_QueueDataAt") */
	native /*synchronized/**/ static int QueueDataAt( int time, int unit, int portHash, int token, int startFrame, int numFrames, int flags );
	/** @dll.import("JSynV140",entrypoint="CSyn_CreateTable") */
	native /*synchronized/**/ static int CreateTable( int numValues );
	/** @dll.import("JSynV140",entrypoint="CSyn_WriteTableJava") */
	native /*synchronized/**/ static int WriteTable( int table, int startFrame, int numFrames, short[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_WriteTableDoublesJava") */
	native /*synchronized/**/ static int WriteTableDoubles( int table, int startFrame, int numFrames, double[] data, int startIndex, int dataLangth );
	/** @dll.import("JSynV140",entrypoint="CSyn_UseTable") */
	native /*synchronized/**/ static int UseTable( int unit, int portHash, int partNum, int table );
	/** @dll.import("JSynV140",entrypoint="CSyn_SetTrace") */
	native /*synchronized/**/ static void SetTrace( int mask );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetTrace") */
	native /*synchronized/**/ static int GetTrace();
	/** @dll.import("JSynV140",entrypoint="CSyn_SleepUntilTick") */
	native static int SleepUntilTick( int tick );
	/** @dll.import("JSynV140",entrypoint="CSyn_GetNumParts") */
	native /*synchronized/**/ static int GetNumParts( int token, int portHash );

// Begin public methods ======================================================
	/** @dll.import("JSynV140",entrypoint="CSyn_Debug") */
	public native /*synchronized/**/ static int debug( int id, int data );
	public static int debug( )
	{
		return debug( DEBUG_REPORT, 0 );
	}
	
 /**
 * Sleep until the specified tick is reached.
 * @exception SynthException	 If timer not running.
 */
	public static void sleepUntilTick( int tick )
	throws SynthException
//	throws InterruptedException
	{
		if( (flags & FLAG_NON_REAL_TIME) != 0 )
		{
			try
			{
				sleeper.sleepUntilIndex( tick );
			} catch( InterruptedException e )
			{
				// System.err.println("sleepUntilIndex() interrupted. FIXME");
			}
		}
		else
		{
			int current = getTickCount();
			while( (tick-current) > 0 )
			{
				if( openCount == 0 ) break;
				sleepForTicks(tick-current);
				current = getTickCount();
			}
		}
	}
	
	public static void checkEngineErrors() 
	throws SynthException
	{
		int result = CheckEngineErrors();
		if( result < 0 )
		{
			throw new SynthException( result, "background engine error detected while sleeping" );
		}
	}
	
/**
 * Sleep for the specified number of ticks.
 * @exception SynthException	 If timer not running.
 */
	public static void sleepForTicks( int ticks )
	throws SynthException
//	throws InterruptedException
	{
		if( (flags & FLAG_NON_REAL_TIME) != 0 )
		{
			sleepUntilTick( ticks + Synth.getTickCount() );
		}
		else
		{
			int maxTicksPerSecond = (int) (Synth.getTickRate() / 2.0);
			if( maxTicksPerSecond < 1 ) throw new SynthException("Engine stopped.");
			int ticksPerSleep;
	//		System.out.println("sleepForTicks(" + millis + ")");
			try{
				while( ticks > 0 )
				{
	// Don't sleep for more than a given time so that we can check background FIFO.
					if( ticks > maxTicksPerSecond ) ticksPerSleep = maxTicksPerSecond;
					else ticksPerSleep = ticks;
	// Use Java sleep to let other Java threads run.
					int millis = (int)((double)ticksPerSleep * millisPerTick) + 1;
					Thread.sleep(millis);
					ticks -= ticksPerSleep;
					if( openCount > 0 ) checkEngineErrors();
					else throw new SynthException("Engine stopped.");
				}
			} catch( InterruptedException e )
			{
				System.err.println("sleepForTicks() interrupted.");
			}
		}
	}
	
/**
 *	Calls initialize() and start( flags, frameRate ).
 *
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized static void startEngine( int flags, double frameRate )
	throws SynthException
	{
		initialize();
		start( flags, frameRate );
	}

/** Ask for permission to turn on audio input. ABORT if not.
 */
	final static boolean askInputPermission()
	{
		com.softsynth.jsyn.view102.MessageDialog dlg = new com.softsynth.jsyn.view102.MessageDialog(
			"This Java Applet is requesting permission to turn on the\n" +
			"microphone or other audio input.\n" +
			"Press OK to grant permission.",
			"OK", "DENY" );
		return ( dlg.ask() == 0 );
	}
/**
 * Starts execution of process that performs synthesis.
 * This must be called before performing any synthesis.
 * If the flag Synth.FLAG_ENABLE_INPUT is set, and JSyn is running
 * as a plugin, then a dialog will appear asking for permission to
 * record from the microphone. If granted, then AudioInputPermission
 * will be set true. If not then the process will abort.
 *
 * @param frameRate Calculation rate in Hertz, typically 44100.0.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public synchronized static void start( int flags, double frameRate )
	throws SynthException
	{
		Synth.flags = flags;
		
		if( isPlugin && ((flags & Synth.FLAG_ENABLE_INPUT) != 0) && !gotInputPermission)
		{
			if( askInputPermission() )
			{
				gotInputPermission = true;
			}
			else
			{
				System.err.println("Aborting to prevent unauthorized use of microphone.");
				System.exit(0); // Bye Bye
			}
		}
		
		if( sleeper == null ) sleeper = new SynthSleeper();
		sleeper.setIndex( Synth.getTickCount() );
		
// System.out.println("JSyn Engine starting.");
		int err = Synth.Start( flags, frameRate );
// System.out.println("JSyn Engine started. Returned " + err);
		if( err < 0 ) throw new SynthException( err, flags );
		millisPerTick = 1000.0/getTickRate(); /* Cache on this side of native method interface. */
		if( Synth.verbosity > Synth.TERSE )
		{
			System.out.println("JSyn: V" + getVersion() + ", frame rate = " + Synth.getFrameRate() );
		}
	}
	
	public synchronized static void start( int flags )
	throws SynthException
	{
		start( flags, DEFAULT_FRAME_RATE );
	}

/** If the existing version is earlier than the 
 * requested version, then the user will be instructed to
 * upgrade to the latest version of JSyn.
 */
	public static void requestVersion( int requestedVersion )
	{
		String upgradeMessage = 
			"This Java Applet or application requires JSyn version \"" + (((double)requestedVersion)/10) + "\".\n" +
			"You have version \"" + (((double)VERSION)/10) + "\" installed on your computer\n" +
			"As a result, it may not work properly.\n\n" +
			"Please download a free upgrade to the new version\n" +
			"of the JSyn plugin at:\n\n" +
			"    http://www.softsynth.com/jsyn/plugins/";
		if( requestedVersion > VERSION )
		{
			SynthAlert.showError( upgradeMessage );
		// Wait for SynthAlert window to be completely closed so
		// that DirectSound doesn't get confused about GetFrontWindow() under startEngine().
			try
			{
				Thread.sleep(200);
			} catch( InterruptedException e ) {}
		}
	}
	
/**
 *	Initialize Library.
 *	This must be called before any other synthesis functions.
 *  Resets AudioInputPermission.
 *
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	
	public synchronized static void initialize()
	throws SynthException
	{
		gotInputPermission = false; // reset this for next Applet
/* Check for suitable version number in DLL. */
		int version;
		if( (version = getVersion()) != VERSION )
		{
			System.out.println("Version mismatch! Java = " + VERSION + ", 'native = " + version );
			throw new SynthException( JS_ERR_OBSOLETE, version );
		}
// System.out.println("Synth.startEngine()");
		int err = Synth.Initialize();
// System.out.println("JSyn Engine started. Returned " + err);
		if( err < 0 ) throw new SynthException( err, 0 );
		openCount += 1;
	}
/**
 *	Starts execution of process using default frameRate.
 * @exception SynthException	If engine cannot be started or if plugin is an old version, or expired.
 */
	public static void startEngine( int flags )
	throws SynthException
	{
		startEngine( flags, DEFAULT_FRAME_RATE );
	}
/**
 *	Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void stopEngine( )
	throws SynthException
	{
		stop();
		terminate();
	}
/**
 *	Stops execution of process that performs synthesis.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void stop( )
	throws SynthException
	{
		int err = Synth.Stop();
		if( err < 0 ) throw new SynthException( err, 0 );
	}

/**
 *	Terminate library.
 * @exception SynthException	If engine cannot be stopped.
 */
	public synchronized static void terminate( )
	throws SynthException
	{
		if( Synth.verbosity > Synth.TERSE )
		{
			System.out.println( "Synth.terminate() called.");
		}
		SynthObject.deleteAll();
		openCount -= 1;
//		System.out.println( "call native Terminate()");
		int err = Synth.Terminate( );
//		System.out.println( "Synth.stopEngine() returned " + err);
		if( err < 0 ) throw new SynthException( err, 0 );
	}
/*
 * Attempt to reclaim engine resources by running garbage collector.
 */
	static void reclaim()
	{
		Runtime rt = Runtime.getRuntime();
		int lastNum = 0;
		int newNum = Synth.getObjectCount();
		while( newNum != lastNum )
		{
			lastNum = newNum;
			rt.gc();
			System.out.println("Synth.reclaim() - num = " + newNum);
			newNum = Synth.getObjectCount();
		}
		rt.runFinalization();
	}
/* Internal native method that fills a byte array. */
	/** @dll.import("JSynV140",entrypoint="CSyn_ErrorCodeToTextJava") */
	native /*synchronized/**/ static int ErrorCodeToText( int errorCode, byte[] text, int textSize );
	public static String errorCodeToString( int errorCode )
	{
//		if( openCount <= 0 ) return "JSyn error text unavailable because engine not started.";
		
		if( errorCode <= JS_ERR_BASE )
		{
			switch( errorCode )
			{
			case JS_ERR_CIRCUIT_CLOSED: return "SynthCircuit already compiled.";
			case JS_ERR_OBSOLETE: return "JSyn version mismatch. Download new version from www.softsynth.com.";
			case JS_ERR_EXPIRED: return "JSyn version EXPIRED! Download new version from www.softsynth.com.";
			case JS_ERR_OUT_OF_RANGE: return "JSyn value out of range.";
			case JS_ERR_USER: return "JSyn user code detected error.";
			}
			return "Unrecognized JSyn error.";
		}
		else
		{
			byte[] text = new byte[128];
			try
			{
				int len = ErrorCodeToText( errorCode, text, 128 );
				return new String( text, 0, 0, len );
			} catch( UnsatisfiedLinkError e ) {
				return "JSyn error text unavailable because link failed.";
			}
		}
	}
/* Create container for units.
 * @exception SynthException	If sub sounds invalid.
 */
	static int createCircuit( int[] peerArray, int flags )
	throws SynthException
	{
		int token;
		int numUnits = peerArray.length;
		token = Synth.CreateCircuit( peerArray, numUnits, flags );
		if( token < 0 ) throw new SynthException( token, numUnits );
		return token;
	}
	
/** Delete a synth object only if the engine is running to prevent Netscape hangs. */
	static int delete( int token )
	{
		if( openCount > 0 )
		{
			return Synth.Delete( token );
		}
		else return 0;
	}
	
/**
 * Convert a String to a hash value that is used internally in CSyn for fast
 * name lookup. This must match the algorith used in "gen_hash.c".
 */
	public static int hashName( String name )
	{
		int   len = name.length();
		int   hash = 0;
		int   shiftBy = 0;
		char  c;
		for( int i=0; i<len; i++ )
		{
			c = name.charAt(i);
			hash += c << shiftBy;
			shiftBy += 3;
			if( shiftBy > 19 ) shiftBy -= 20;
		}
	
		return hash;
	}
	
/** Set trace flags for debugging. */
	public static void setTrace( int mask )
	{
		verbosity = mask;
		SetTrace( mask );
	}
	public static int getTrace()
	{
		return GetTrace();
	}

}

class SynthSleeper extends SharedSleeper
{
	public int bumpIndex()
	{
		// System.out.println("bumpIndex = " + Synth.getTickCount() );
		Synth.SleepUntilTick( Synth.getTickCount() + 1 );
		return Synth.getTickCount();
	}
}

