/** 
 * Listener for parsing an XML stream.
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package com.softsynth.util;

public interface XMLListener
{
/** Handles the start of an element. */
	void beginElement( String tag, java.util.Hashtable attributes, boolean ifEmpty );
/** Handles the content of an element. */
	void foundContent( String content );
/** Handles the end of an element. */
	void endElement( String tag );
}
