package com.softsynth.jsyn;
import java.util.*;

/**
 * LineOut unit.
 * Adds to stereo signal to send to audio line out.
 * Mixes input stereo signal with the output of other Line_Outs.
 * The result is sent to the DAC at the end of each audio frame.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 */

public class LineOut extends SynthUnit 
{
/**
 * Input - 2 parts, 0=Left, 1=Right.
 * Stereo signal to send to line out.
 */
	public SynthInput input;

 	public LineOut( int calculationRate ) throws SynthException
	{
		super( "Line_Out", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public LineOut( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
