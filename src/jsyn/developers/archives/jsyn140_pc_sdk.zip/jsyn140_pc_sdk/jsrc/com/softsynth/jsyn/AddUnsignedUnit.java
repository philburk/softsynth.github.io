package com.softsynth.jsyn;
import java.util.*;

/**
 *	This unit performs UNsigned addition on its two inputs. 
 <P>
 output = inputA + inputB
 <P>
 output is clipped to the UNSIGNED range 0.0 to +2.0
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see AddUnit
 * @see SubtractUnit
 */

public class AddUnsignedUnit extends SynthUnit 
{
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthInput inputA;
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthInput inputB;
/** SIGNAL_TYPE_RAW_UNSIGNED, range is 0.0 to 2.0 */
	public SynthOutput output;

 	public AddUnsignedUnit( int calculationRate ) throws SynthException
	{
		super( "Math_AddUnsigned", calculationRate );
		inputA = new SynthInput( this, "InputA" );
		inputB = new SynthInput( this, "InputB" );
		output = new SynthOutput( this, "Output" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
	public AddUnsignedUnit( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
