package com.softsynth.jsyn;
import java.util.*;

/**
 *	BusWriter unit.
 * This unit can be used with a BusReader to mix multiple signals together.
 * It has a SynthBusOutput that can be connected to a single
 * SynthBusInput.  All the inputs are summed together.

 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 * @see BusReader
 * @see SynthMixer
 */

public class BusWriter extends SynthUnit 
{
	public SynthInput input;
	public SynthBusOutput busOutput;

 	public BusWriter( int calculationRate ) throws SynthException
	{
		super( "Bus_Write", calculationRate, 0 );
		input = new SynthInput( this, "Input" );
		busOutput = new SynthBusOutput( this, "BusOutput" );
	}
/**
 * Create one that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	 If resource allocation fails.
 */
 	public BusWriter( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
