package com.softsynth.util;


/**
 * Allow multiple threads to sleep on a single resource 
 * such as a non-real-time software synthesizer.
 * 
 * @author (C) 2000 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SharedSleeper
{
	int        currentIndex = 0;
	Semaphore  gotMaster; // used to determine which caller is the Master
	
	public SharedSleeper()
	{
		gotMaster = new Semaphore();
	}
	
	public void setIndex( int index )
	{
		currentIndex = index;
	}
	public int getIndex()
	{
		return currentIndex;
	}
	
/** Master causes increase in index while slaves monitor master.
 */
	synchronized int doMaster()
	{
	// Set priority to lowest so that other threads can get their
	// sleep requests in while we spin.
		Thread thread = Thread.currentThread();
		int oldPriority = thread.getPriority();
		thread.setPriority( Thread.MIN_PRIORITY );
		
		Thread.yield(); // give other threads a chance to wait
		currentIndex = bumpIndex();
		notifyAll();
		gotMaster.free();
		
		thread.setPriority( oldPriority );
		return currentIndex;
	}
	
	synchronized int doSlave() throws InterruptedException
	{
		wait();
		return currentIndex;
	}
	
	
/** Overridden by clients to perform work.
 */
	public int bumpIndex()
	{
		int nextIndex = currentIndex + 1;
		// System.out.println("SleepUntilIndex.bumpIndex: index = " + nextIndex );
		return nextIndex;
	}
	
/** Sleep until the given index is reached.
 * Index can wrap around as long as we don't wait for more than half a circle.
 */
	public int sleepUntilIndex( int desiredIndex ) throws InterruptedException
	{
	//	System.out.println("SleepUntilIndex.sleep: ENTER desired = " + desiredIndex +
	//					   ", current = " + currentIndex );
		int got = currentIndex;
		while( (desiredIndex - currentIndex) > 0 )
		{
			if( gotMaster.request() )
			{
				// System.out.println("Master waiting for " + desiredIndex );
				got = doMaster();
			}
			else
			{
				got = doSlave();
			}
		}
	//	System.out.println("SleepUntilIndex.sleep: EXIT desired = " + desiredIndex +
	//					   ", current = " + currentIndex );
		return got;
	}
}
