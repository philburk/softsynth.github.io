package com.softsynth.jsyn.view11x;
import com.softsynth.view.*;
import com.softsynth.jsyn.*;
import java.util.*;
import java.awt.*;
/**
 * Fader with Label and value display.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */
public class LabelledFader extends Panel implements CustomFaderListener, Tweakable
{
	Tweakable  target;
	int        targetIndex;
	String     faderName;
	Label      nameLabel;
	Label      valueLabel;
	protected  CustomFaderDouble fader;
/**
 * Create a LabelledFader.
 * @param target Object that implements tweakable interface. If null, then this objects tweak method() will be called.
 * @param targetIndex Index that will be passed to tweak() method.
 * @param faderName Name of fader displayed on left of fader..
 * @param fval The default starting value.
 * @param min Minimum value corresponding to the leftmost fader position.
 * @param max Maximum value corresponding to the rightmost fader position.
 */
	public LabelledFader( Tweakable target, int targetIndex, String faderName, double startValue, double min, double max )
	{
		if( target == null ) this.target = this;
		else this.target = target;
		
		this.targetIndex = targetIndex;
		this.faderName = faderName;
		setLayout( new GridLayout(0,3) );
/* Add space to label so it doesn't come too close to Scrollbar. */
		nameLabel = new Label( faderName + " ", Label.RIGHT );
		add(nameLabel);
		fader = new CustomFaderDouble( CustomFader.HORIZONTAL, startValue, min, max );
		fader.addCustomFaderListener( this );
		add(fader);
		valueLabel = new Label();
		showValue( startValue );
		add(valueLabel);
	}

	public double getMinimum() { return fader.getMinimum(); }
	public double getMaximum() { return fader.getMaximum(); }
	
	void showValue( double fval )
	{
/* Prevent size of label from fluctuating wildly. */
		String fvalString = Double.toString( fval );
		int maxchars = fvalString.indexOf( '.' ) + 5;
		String actualString = (fvalString.length() > maxchars) ? fvalString.substring(0,maxchars) : fvalString;
		valueLabel.setText( actualString );
	}

/** Return CustomFader used internally by LabelledFader.
 */
	public CustomFader getFader()
	{
		return (CustomFader) fader;
	}
		
	public void setValue( double fval )
	{
		fader.setValue( fval );
	}
		
/** This can be overridden in subclasses. */
	public void tweak( int idx, double fval )
	{
	}

/** Any class listening to a CustomFader must implement CustomFaderListener by defining this method */
    public void customFaderValueChanged(CustomFader fdr, int value)
	{
		CustomFaderDouble fdbl = (CustomFaderDouble) fdr;
		double fval = fdbl.faderToDouble( value );
		target.tweak( targetIndex, fval );
		showValue( fval );
	}

}
