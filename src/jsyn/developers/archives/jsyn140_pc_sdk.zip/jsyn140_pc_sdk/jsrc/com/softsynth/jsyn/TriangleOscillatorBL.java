package com.softsynth.jsyn;
import java.util.*;

/**
 * TriangleOscillatorBL unit.
 * This version is band limited and will sound better than TriangleOscillator
 * but uses more CPU time to compute.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class TriangleOscillatorBL extends SynthOscillator
{
 	public TriangleOscillatorBL( int calculationRate ) throws SynthException
	{
		super( "Osc_TriangleBL", calculationRate, 0 );
	}
/**
 *	Create a TriangleOscillatorBL that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If out of memory.
 */
 	public TriangleOscillatorBL( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
