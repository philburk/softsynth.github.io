package com.softsynth.jsyn;
import java.util.*;

/**
 *	CrossFade unit.
 <P>
  Mix input[0] and input[1] based on the value of "fade".
  When fade is -1, output is all input[0].
  When fade is 0, output is all half input[0] and half input[1].
  When fade is +1, output is all input[1].
 <P>
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 012
 * @see SelectUnit
 */

public class CrossFade extends SynthUnit 
{
/** This port has two parts, 0 and 1. */
	public SynthInput input;
/** Smoothly mixes between input[0] and input[1]. */
	public SynthInput fade;
	public SynthOutput output;

 	public CrossFade( int calculationRate ) throws SynthException
	{
		super( "Math_CrossFade", calculationRate );
		input = new SynthInput( this, "Input" );
		fade = new SynthInput( this, "Fade" );
		output = new SynthOutput( this, "Output" );
	}
/**
 *	Create a SynthUnit that runs at Synth.RATE_AUDIO.
 *
 * @exception SynthException	  If resource allocation fails.
 */
 	public CrossFade( ) throws SynthException
	{
		this( Synth.RATE_AUDIO );
	}
}
