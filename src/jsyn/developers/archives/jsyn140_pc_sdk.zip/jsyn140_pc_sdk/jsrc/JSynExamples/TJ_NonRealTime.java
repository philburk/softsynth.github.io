/** 
 * Test recording to disk in non-real-time.
 * Play several frequencies of a sine wave.
 * Save data in a WAV file format.
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package JSynExamples;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.awt.event.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.util.*;

public class TJ_NonRealTime
{
	SineOscillator        myOsc;
	final static double   FRAME_RATE = 44100.0;
	final static int      FRAMES_PER_BUFFER = 8*1024;
	final static double   TOTAL_TIME = 10.0;
	final static int      TOTAL_FRAMES = (int) (FRAME_RATE * TOTAL_TIME);
	StreamRecorder        recorder;
	WAVFileWriter         outStream;
	long                  benchStart, benchStop;
	
/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_NonRealTime app = new TJ_NonRealTime();
		app.test();
		System.exit(0);
	}

/*
 * Setup synthesis.
 */
	public void test()
	{
	// Make sure we are using the necessary version of JSyn
		Synth.requestVersion( 140 );
		
		String fileName = "recorded.wav";
	// Create an output file to write to.
		try
		{
			RandomAccessFile rfile = new RandomAccessFile( fileName, "rw" );
			outStream = new WAVFileWriter( rfile );
			System.out.println("Recording to file " + fileName );
			
		} catch( IOException e ) {
			System.err.println(e);
		} catch( SecurityException e ) {
			System.err.println(e);
		}
		

		try
		{
	// write header for WAV file
		outStream.writeHeader( 1, (int) FRAME_RATE );
		
	// Start synthesis engine in non-real-time mode for faster recording.
		Synth.startEngine( Synth.FLAG_NON_REAL_TIME, FRAME_RATE );
		// Synth.startEngine( FRAME_RATE );

	// Create SynthUnits to generate some sound and record it.
		myOsc = new SineOscillator();

	// Create a recorder that will continuously record its input.
		recorder = new StreamRecorder( outStream, FRAMES_PER_BUFFER, 4, 1 );
		myOsc.output.connect( recorder.input );
			
	// Start slightly in the future so everything is synced.
		int time = Synth.getTickCount() + 20;
		
	// benchmark for non-real-time. NOTE: file writing in Java is VERY slow!
		benchStart = System.currentTimeMillis();
		
	// start playing and recording
		myOsc.start( time );
		recorder.start( time );
		
	// change frequency several times so we can hear something happen
		int totalTicks = TOTAL_FRAMES / Synth.getFramesPerTick();
		int numNotes = 8;
		int dur = totalTicks/numNotes;
		double freq = 200.0;
		for( int i=0; i<numNotes; i++ )
		{
			myOsc.frequency.set( time, freq );
			time += dur;
			freq *= 4.0/3.0;
			Synth.sleepUntilTick( time );
		}
		
	// stop recorder and oscillator
		recorder.stop( time );
		myOsc.stop( time );
		
	// Update WAV file chunk sizes based on final recorded size.
		outStream.fixSizes();
		outStream.close();

	// print benchmark info
		benchStop = System.currentTimeMillis();
		double realSeconds = 0.001 * (benchStop - benchStart);
		System.out.print("Took " + realSeconds + " seconds");
		System.out.println(" to generate and write " + TOTAL_TIME + " seconds worth of sound.");
		System.out.println("Most of that time was probably spent doing Java File I/O.");
		
		Synth.stopEngine();

		} catch( IOException e ) {
			System.err.println(e);
		} catch (SynthException e) {
			System.err.println(e);
		}
	}
}

