/**
 * FilterFun - experiment with digital filters.
 * This is used to hear the effect of various filters on a variety of source material.
 * The filters have a graphical component that are subclasses of FunFilter.
 *
 * @author (C) 1998 Phil Burk, All Rights Reserved
 */

package JSynExamples;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view102.*;

public class FilterFun extends Applet implements Tweakable
{
	final static Color filterColor = Color.cyan;
	RedNoise          noise;
	ImpulseOscillator impulse;
	SawtoothOscillatorBL sawtooth;
	SineOscillator    sineosc;
	SynthOscillator   currentSource = null;
	SynthFilter       currentFilter = null;
	AddUnit           srcTap;
	AddUnit           filterTap;
	final static double MAX_CUTOFF = 10000.0;
	double            freqValue = 2000.0;
	double            ampValue = 0.5;
	double            cutoffValue = MAX_CUTOFF/2.0;
	double            bandwidthValue = 0.5;
	
	FunFilter         funBiquad;
	FunFilter         funSVF;
	FunFilter         fun1Z;
	FunFilter         fun1P;
	FunFilter         fun1P1Z;
	FunFilter         fun2P;
	
	LineOut           myOut;
	
	Choice            sourceChoice;
	Choice            filterChoice;
	LabelledFader     freqFader;
	LabelledFader     dbFader;
	Panel             filterGUI;
	SynthScope        scope;
	
/* The order of these must match the items in passChoice */
	final static int LOW_PASS = 0;
	final static int BAND_PASS = 1;
	final static int HIGH_PASS = 2;
	
/* Can be run as either an application or as an applet. */
	public static void main(String args[])
	{
/* DO: Change FilterLab to match the name of your class. Must match file name! */
	   FilterFun  applet = new FilterFun();
	   AppletFrame frame = new AppletFrame("Filter Fun", applet);
	   frame.resize(700,500);
	   frame.show();
 /* Begin test after frame opened so that DirectSound will use Java window. */
	   frame.test();
	}

/********************************************************************/
	void buildGUI()
	{
/* Use GridBagLayout to get reasonably sized components. */
		GridBagLayout  gridbag  =  new  GridBagLayout();
		setLayout(gridbag);
		GridBagConstraints  constraint  =  new  GridBagConstraints();
		constraint.fill  =  GridBagConstraints.BOTH;  
		constraint.gridwidth  = 1; 
		constraint.gridheight  = 1;
		constraint.gridx = 0;
		constraint.gridy = GridBagConstraints.RELATIVE;
		constraint.weightx  =  1.0;
		constraint.weighty  =  0.0;
		
		gridbag.setConstraints(makeSourcePanel(),  constraint);

		add( freqFader = new LabelledFader( this, 0, "Source Frequency", freqValue, 0.0, MAX_CUTOFF ) );
		gridbag.setConstraints(freqFader,  constraint);

		add( dbFader = new LabelledFader( this, 1, "Source Amplitude", ampValue, 0.0, 1.0) );
		gridbag.setConstraints(dbFader,  constraint);
		
		gridbag.setConstraints(makeFilterPanel(),  constraint);
		
		add( filterGUI = new Panel() );
		filterGUI.setLayout( new BorderLayout() );
		filterGUI.setBackground( filterColor );
		constraint.gridheight  = 4;
		constraint.weighty  =  1.0;
		gridbag.setConstraints(filterGUI,  constraint);
		
/* Create an oscilloscope to show each waveform. */
		add( scope = new SynthScope() );
		scope.createProbe( srcTap.output, "Source", Color.red );
		scope.createProbe( filterTap.output, "Filtered", Color.green );
		scope.finish();
			
		constraint.gridheight = GridBagConstraints.REMAINDER;  
		constraint.weighty  =  1.0;
		gridbag.setConstraints(scope,  constraint);
		
		
/* Synchronize Java display to make buttons appear. */
		getParent().validate();
		getToolkit().sync();
	}
	
/********************************************************************/		
	Panel makeSourcePanel( )
	{
		Panel panel = new Panel();
		add( panel );
		
		panel.add( new Label("Select Source:") );
		panel.add( sourceChoice = new Choice() );
			
		sourceChoice.addItem("RedNoise");
		sourceChoice.addItem("Impulse");
		sourceChoice.addItem("Sawtooth");
		sourceChoice.addItem("SineWave");
   		sourceChoice.addItemListener(	new ItemListener() {
   				public void itemStateChanged(ItemEvent e)
   				{ selectSource( sourceChoice.getSelectedItem() );	} } );
		return panel;
	}
		
	void selectSource( String sourceName )
	{
		if( sourceName.equals( "RedNoise" ) ) useSource( noise );
		else if ( sourceName.equals( "Impulse" ) ) useSource( impulse );
		else if ( sourceName.equals( "Sawtooth" ) ) useSource( sawtooth );
		else if ( sourceName.equals( "SineWave" ) ) useSource( sineosc );
	}
	
/********************************************************************/		
	Panel makeFilterPanel( )
	{
		Panel panel = new Panel();
		add( panel );
		panel.setBackground( filterColor );
		panel.add( new Label("Select Filter:") );
		panel.add( filterChoice = new Choice() );
			
		filterChoice.addItem("StateVariable");
		filterChoice.addItem("BiQuad");
		filterChoice.addItem("OnePole");
		filterChoice.addItem("OneZero");
		filterChoice.addItem("OnePoleOneZero");
		filterChoice.addItem("TwoPole");
   		filterChoice.addItemListener(	new ItemListener() {
   				public void itemStateChanged(ItemEvent e)
   				{ selectFilter( filterChoice.getSelectedItem() );	} } );
		return panel;
	}
		
	void selectFilter( String sourceName )
	{
		if( sourceName.equals( "StateVariable" ) ) useFilter( funSVF );
		else if ( sourceName.equals( "BiQuad" ) ) useFilter( funBiquad );
		else if ( sourceName.equals( "OnePole" ) ) useFilter( fun1P );
		else if ( sourceName.equals( "OneZero" ) ) useFilter( fun1Z );
		else if ( sourceName.equals( "OnePoleOneZero" ) ) useFilter( fun1P1Z );
		else if ( sourceName.equals( "TwoPole" ) ) useFilter( fun2P );
	}
		
	void stopAll()
	{
		if( currentSource != null ) currentSource.stop();
		srcTap.stop();
		if( currentFilter != null ) currentFilter.stop();
		filterTap.stop();
	}
	
/** Start units in signal order so that scope does not show delays. */
	void startAll()
	{
		if( currentSource != null ) currentSource.start();
		srcTap.start();
		if( currentFilter != null ) currentFilter.start();
		filterTap.start();
	}
/********************************************************************/
	void useSource( SynthOscillator osc )
	{
		stopAll();
		currentSource = osc;
		if( currentFilter != null ) osc.output.connect( currentFilter.input );
		osc.output.connect( srcTap.inputA );
		updateSource();
		startAll();
	}
	
/********************************************************************/
	void updateSource( )
	{
		currentSource.frequency.set( freqValue );
		currentSource.amplitude.set( ampValue );
	}
	
/********************************************************************/
	void useFilter( FunFilter funFilter )
	{
		stopAll();
		currentFilter = funFilter.filter;
		if( currentSource != null ) currentSource.output.connect( currentFilter.input );
		currentFilter.output.connect( filterTap.inputA );
		startAll();
		if( filterGUI != null )
		{
			filterGUI.removeAll();
			filterGUI.add( "Center", funFilter );
/* Synchronize Java display to make buttons appear. */
			getParent().validate();
			getToolkit().sync();
		}
	}

/********************************************************************/
	void buildSynth()
	{
		try
		{
			Synth.startEngine(0);

		/* Create unit generators. */
			noise = new RedNoise();
			impulse = new ImpulseOscillator();
			sawtooth = new SawtoothOscillatorBL();
			sineosc = new SineOscillator();
			srcTap = new AddUnit();
			filterTap = new AddUnit();
			funBiquad = new FunBiquadFilter();
			funSVF = new FunSVFFilter();
			fun1Z = new FunOneZeroFilter();
			fun1P = new FunOnePoleFilter();
			fun1P1Z = new FunOnePoleOneZeroFilter();
			fun2P = new FunTwoPoleFilter();
			
			myOut = new LineOut();
			filterTap.output.connect( 0, myOut.input, 0 );
			filterTap.output.connect( 0, myOut.input, 1 );
			myOut.start();
			
		} catch(SynthException e) {
			SynthAlert.showError(this,e);
		}
	}

/********************************************************************/
	public void start()  
	{
		buildSynth();
		buildGUI();
		useSource( noise );
		useFilter( funSVF );
	}

/********************************************************************/
	public void stop()  
	{
		try
		{
			removeAll();
			Synth.stopEngine();
		} catch(SynthException e) {
			SynthAlert.showError(this,e);
		}
	}

/********************************************************************
 ** Called by LabelledFader to apply new value. */
	public void tweak( int targetIndex, double val )
	{
		switch( targetIndex )
		{
		case 0:
			{
				freqValue = val;
				break;
			}
		case 1:
			{
				ampValue = val;
				break;
			}
		}
		updateSource();
	}
	
/*
 * Define classes of graphical components for each filter.
 */
/********************************************************************/
/******* FunFilter **************************************************/
/********************************************************************/
	abstract class FunFilter extends Panel
	{
		public SynthFilter filter;
		
		public FunFilter()
		{
			setLayout( new GridLayout( 0, 1 ) );
			add( new Label( getEquation(), Label.CENTER ) );
		}
	
		public abstract String getEquation();
		
	}
	
/********************************************************************/
/******* FunTunableFilter *******************************************/
/********************************************************************/
	abstract class FunTunableFilter extends FunFilter  implements Tweakable
	{
		LabelledFader    cutoffFader;
		LabelledFader    widthFader;
		Choice           passChoice;
		
		public FunTunableFilter()
		{
			add( cutoffFader = new LabelledFader( this, 0, "Cutoff Frequency", cutoffValue, 0.1, MAX_CUTOFF ) );
			add( widthFader = new LabelledFader( this, 1, "Bandwidth", bandwidthValue, 0.001, 0.5) );
			
/* The order of these must match the constants LOW_PASS, HIGH_PASS, BAND_PASS. */
			add( passChoice = new Choice() );
			
			passChoice.addItem("LowPass");
			passChoice.addItem("BandPass");
			passChoice.addItem("HighPass");
   			passChoice.addItemListener(	new ItemListener() {
   				public void itemStateChanged(ItemEvent e)
   				{ setPass( passChoice.getSelectedIndex() );	} } );
		}
		

/********************************************************************
 ** Called by LabelledFader to apply new value. */
	public void tweak( int targetIndex, double val )
	{
		switch( targetIndex )
		{
		case 0:
			{
				cutoffValue = val;
				updateFilter();
				break;
			}
		case 1:
			{
				bandwidthValue = val;
				updateFilter();
				break;
			}
		}
	}

	public abstract void setPass( int passIndex );
	public abstract void updateFilter();
	}

/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunSVFFilter extends FunTunableFilter  implements Tweakable
	{
		StateVariableFilter svf;
		
		public FunSVFFilter()
		{
			this.filter = svf = new StateVariableFilter();
			updateFilter();
		}
		public String getEquation()
		{
			return "State Variable Filter as described by Hal Chamberlain";
		}
		public void setPass( int passIndex )
		{
			switch( passIndex )
			{
				case LOW_PASS: svf.lowPass.connect( filterTap.inputA ); break;
				case BAND_PASS: svf.bandPass.connect( filterTap.inputA ); break;
				case HIGH_PASS: svf.highPass.connect( filterTap.inputA ); break;
			}
		}
/*
 * Update biquadFilter based on currently selected biquadFilter type (low,high,etc).
 * Either use methods in this lab class, or use methods in biquadFilter
 * for comparison.
 */
		public void updateFilter()
		{
			svf.frequency.set( cutoffValue );
			svf.resonance.set( bandwidthValue );
		}
	}
	
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunBiquadFilter extends FunTunableFilter  implements Tweakable
	{
		Filter_2o2p2z biquad;
		int passIndex = LOW_PASS;
		
		public FunBiquadFilter()
		{
			this.filter = biquad = new Filter_2o2p2z();
			updateFilter();
		}

		public String getEquation()
		{
			return "y(n) = 2.0 * (A0*x(n) + A1*x(n-1) + A2*x(n-2) - B1*y(n-1) - B2*y(n-2))";
		}
		
		public void setPass( int passIndex )
		{
			this.passIndex = passIndex;
			updateFilter();
		}

/*
 * Update biquadFilter based on currently selected biquadFilter type (low,high,etc).
 * Either use methods in this lab class, or use methods in biquadFilter
 * for comparison.
 */
		public void updateFilter()
		{
			switch( passChoice.getSelectedIndex() )
			{
				case LOW_PASS: biquad.lowPass( cutoffValue, bandwidthValue ); break;
				case BAND_PASS: biquad.bandPass( cutoffValue, bandwidthValue ); break;
				case HIGH_PASS: biquad.highPass( cutoffValue, bandwidthValue ); break;
			}
		}
	}
	
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunOneZeroFilter extends FunFilter
	{
		Filter_1o1z      f1o1z;
		
		public FunOneZeroFilter()
		{
			this.filter = f1o1z = new Filter_1o1z();
			add( new PortFader( f1o1z.A0, 0.5, -1.0, 1.0 ) );
			add( new PortFader( f1o1z.A1, 0.5, -1.0, 1.0 ) );
		}
		public String getEquation()
		{
			return "y(n) = A0*x(n) + A1*x(n-1)";
		}
	}
	
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunOnePoleFilter extends FunFilter
	{
		Filter_1o1p      f1o1p;
		
		public FunOnePoleFilter()
		{
			this.filter = f1o1p = new Filter_1o1p();
			add( new PortFader( f1o1p.A0, 0.6, -1.0, 1.0 ) );
			add( new PortFader( f1o1p.B1, 0.3, -1.0, 1.0 ) );
		}
		public String getEquation()
		{
			return "y(n) = A0*x(n) - B1*y(n-1)";
		}
	}
	
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunOnePoleOneZeroFilter extends FunFilter
	{
		Filter_1o1p1z      fltr;
		
		public FunOnePoleOneZeroFilter()
		{
			this.filter = fltr = new Filter_1o1p1z();
			add( new PortFader( fltr.A0, 0.5, -1.0, 1.0 ) );
			add( new PortFader( fltr.A1, 0.2, -1.0, 1.0 ) );
			add( new PortFader( fltr.B1, 0.3, -1.0, 1.0 ) );
		}
		public String getEquation()
		{
			return "y(n) = A0*x(n) + A1*x(n-1) - B1*y(n-1)";
		}
	}
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
	class FunTwoPoleFilter extends FunFilter
	{
		Filter_2o2p     fltr;
		
		public FunTwoPoleFilter()
		{
			this.filter = fltr = new Filter_2o2p();
			add( new PortFader( fltr.A0, 0.5, -1.0, 1.0 ) );
			add( new PortFader( fltr.B1, 0.2, -1.0, 1.0 ) );
			add( new PortFader( fltr.B2, 0.3, -1.0, 1.0 ) );
		}
		public String getEquation()
		{
			return "y(n) = A0*x(n) - B1*y(n-1) - B2*y(n-2)";
		}
	}
}
