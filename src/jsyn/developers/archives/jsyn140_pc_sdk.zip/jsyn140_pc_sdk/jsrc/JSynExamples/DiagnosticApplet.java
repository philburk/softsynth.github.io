package JSynExamples;
import java.util.*;
import java.awt.*;
import java.applet.Applet;
import com.softsynth.jsyn.*;

/**
 * Try to diagnose installation problems for JSyn.
 *
 * @author Phil Burk
 * (C) 1997 Phil Burk
 */

public class DiagnosticApplet extends Applet
{
	InstallationDiagnostic diag;
	
	public static void main(String args[]) {
		DiagnosticApplet applet = new DiagnosticApplet();
		Frame f = new Frame("Applet Frame");
		f.add("Center", applet);
		applet.init();
		applet.start();
		f.setSize(500,300);
		f.show();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{
		System.out.println("Starting DiagnosticApplet");
		add( diag = new InstallationDiagnostic() );
			
		getParent().validate();
		getToolkit().sync();
	
		diag.test();
	}
	
	public void stop()
	{
		removeAll();
	}
}

	
class InstallationDiagnostic extends Panel
{
	TextArea    textArea;
	
	final static int FLAG_NON_REAL_TIME = (1<<2);
	
	void write( String msg )
	{
		if( textArea != null )
		{
			textArea.append(msg);
		}
		else
		{
			System.out.print(msg);
		}
	}
	
	boolean test()
	{
		add( textArea = new TextArea( 10, 60 ) );

		try
		{
			Class cl = Class.forName( "com.softsynth.jsyn.CuePoint" );
			write("SUCCESS #1 - Loaded JSyn CuePoint class.\n");
		} catch (ClassNotFoundException e) {
			write("ERROR #1 - Could not load JSyn Classes!\n");
			return true;
		}
		
/* Start synthesis engine in non-real-time to see if we can load JSyn DLL. */
		try
		{
			int version = Synth.getVersion();
			write("SUCCESS #2 - Loaded DLL version " + version + ".\n");
		} catch (UnsatisfiedLinkError e) {
			write("ERROR #2 - Could not load JSyn DLL or Library!\n");
			return true;
		}
		
/* Start synthesis engine in real-time to see if we can load DirectSound or SoundManager DLL. */
		try
		{
			if( Synth.openCount > 0 ) write("Note: openCount = " + Synth.openCount +
				", indicates Synth already open!\n");
			Synth.startEngine( 0 );
			write("SUCCESS #3 - Started SynthEngine.\n");
		} catch (SynthException e1) {
			if( Synth.openCount > 0 )
			{
				try
				{
					Synth.startEngine( 0, Synth.DEFAULT_FRAME_RATE/2.0 );
					write("SUCCESS #3 - Started SynthEngine at " + (((int)(Synth.DEFAULT_FRAME_RATE))/2) + " Hz.\n");
				} catch (SynthException e2) {
					write("ERROR #3 - Could not start SynthEngine at either frame rate!\n");
					return true;
				}
			}
			else
			{
				write("ERROR #3 - Could not start SynthEngine!\n");
				return true;
			}
		}
		
/* Try to write a table which will verify we don't have a mismatch between V13.5
 * and an older JAR or DLL file.
 */
		try
		{
			double[] data =
			{
				0.05, 1.0,  /* duration,value pair for frame[0] */
				0.30, 0.1,  /* duration,value pair for frame[1] */
				0.50, 0.7,  /* duration,value pair for frame[2] */
				0.50, 0.9,  /* duration,value pair for frame[3] */
				0.80, 0.0   /* duration,value pair for frame[4] */
			};
			int numFrames = data.length/2;
			SynthEnvelope myEnvData = new SynthEnvelope( numFrames );
			myEnvData.write( 0, data, 0, numFrames );
			write("SUCCESS #4 - Wrote SynthEnvelope.\n");
		} catch (SynthException e) {
			write("ERROR #4 - Could not write SynthEnvelope! Version mismatch.\n");
			Synth.stopEngine();
			return true;
		}
		
		Synth.stopEngine();
		return false;
	}
}
