/** 
 * Test STEREO Sample playback using Java Audio Synthesiser
 * Checkbox controls length of sample loop.
 *
 * @author (C) 1997 Phil Burk, All Rights Reserved
 */

package JSynExamples;
import java.util.*;
import java.awt.*;
import java.io.*;
import java.net.URL;
import java.applet.Applet;
import com.softsynth.jsyn.*;
import com.softsynth.jsyn.view102.*;

public class TJ_Sample3 extends Applet
{
	SynthSample        mySamp;
	SampleReader_16F2  mySampler;
	LineOut            myOut;
	Button             hitButton;
	Button             onButton;
	Button             offButton;
	public String      fileName = null;

/* Can be run as either an application or as an applet. */
    public static void main(String args[])
	{
		TJ_Sample3 applet = new TJ_Sample3();
		if( args.length > 0 ) applet.fileName = args[0];
		AppletFrame frame = new AppletFrame("Test SynthSample", applet);
		frame.resize(600,400);
		frame.show();
/* Begin test after frame opened so that DirectSound will use Java window. */
		frame.test();
	}

/*
 * Setup synthesis.
 */
	public void start()
	{
		setLayout( new GridLayout(0,1) );
		
		try
		{
/* Start synthesis engine. */
		Synth.startEngine( 0 );
		Synth.verbosity = Synth.SILENT;

/* Load sample from a file. */
		if( fileName == null ) fileName = "../samples/LeftRight.aiff";
/* Load sample from a file. */
		try
		{
			FileInputStream stream = new FileInputStream(fileName);
			try
			{
				switch( SynthSample.getFileType( fileName ) )
				{
				case SynthSample.AIFF:
					mySamp = new SynthSampleAIFF( stream );
					break;
				case SynthSample.WAV:
					mySamp = new SynthSampleWAV( stream );
					break;
				default:
					SynthAlert.showError(this, "Unrecognized sample file suffix.");
					break;
				}
				System.out.println( mySamp.dump() );
			} catch( IOException e )
			{
				SynthAlert.showError(this,e);
			}
		} catch( FileNotFoundException e )
		{
			SynthAlert.showError(this,e);
		} catch( SecurityException e )
		{
			SynthAlert.showError(this,e);
		}

/* Create SynthUnits whose peers are unit generators. */
		mySampler = new SampleReader_16F2();
		myOut = new LineOut();

/* Connect SynthUnits to output. */
		mySampler.output.connect( 0, myOut.input, 0 );
		mySampler.output.connect( 1, myOut.input, 1 );

/* Build GUI */
		add( hitButton = new Button("Hit") );
		add( onButton = new Button("On") );
		add( offButton = new Button("Off") );

/* Show faders so we can manipulate sound parameters. */
		add( new PortFader( mySampler.amplitude, 0.7, 0.0, 1.0 ) );

/* Start execution of units. */
		myOut.start();
		mySampler.start();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	
/* Synchronize Java display. */
		getParent().validate();
		getToolkit().sync();
	}


	public void stop()
	{
		try
		{
/* Delete unit peers. */
			mySampler.delete();
			mySampler = null;
			myOut.delete();
			myOut = null;
			removeAll(); // remove portFaders
/* Turn off tracing. */
			Synth.verbosity = Synth.SILENT;
/* Stop synthesis engine. */
			Synth.stopEngine();

		} catch (SynthException e) {
			SynthAlert.showError(this,e);
		}
	}
	
	public boolean action(Event evt, Object what)
	{
		try
		{
			if( evt.target == hitButton )
			{
					mySampler.samplePort.queue( mySamp );
					return true;
			}
			else if( evt.target == onButton )
			{
					mySampler.samplePort.queueOn( mySamp );
					return true;
			}
			else if( evt.target == offButton )
			{
					mySampler.samplePort.queueOff( mySamp );
					return true;
			}
		} catch (SynthException e) {
			SynthAlert.showError(this,e);
			return true;
		}
		return false;
    }
}
