README for JSyn
Copyright (C) 1997 Phil Burk
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.

This "patch" release has replacement files for the various JSyn DLLs.

V13.5 has a workaround for a bug in Windows NT that allows JSyn to work.

--------------- Disclaimer ---------------------------

This version of JSyn may only be used for non-commercial purposes, and may NOT 
be redistributed by any means. Please contact "philburk@softsynth.com" regarding 
the availability of commercial licenses.

JSyn is available AS IS with no warranty of fitness or suitability for any purpose.
Use at your own risk.


Please visit the JSyn web site at http://www.softsynth.com/jsyn
for more information or to download the latest version.

Thank you,
Phil Burk
philburk@softsynth.com
