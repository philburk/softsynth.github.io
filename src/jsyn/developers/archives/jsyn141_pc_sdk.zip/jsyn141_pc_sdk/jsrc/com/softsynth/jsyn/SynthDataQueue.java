package com.softsynth.jsyn;
import java.util.*;

/**
 * SynthDataQueue class for Java Audio Synthesis.
 * Root class for SynthEnvelopeQueue and SynthSampleQueue.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */

public class SynthDataQueue extends SynthPort
{
	SynthDataQueue( SynthSound sound, String name ) throws SynthException
	{
		super( sound, name );
	}
	SynthDataQueue( SynthSound sound ) throws SynthException
	{
		super( sound, "Data" );
	}

/**
 * Clear any data on this queue.
 * @exception SynthException	 If queue name is not recognized.
 */
	public void clear()
	throws SynthException
	{
		int nativeError = Synth.ClearDataQueue( peerToken, portHash );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken );
	}
	public void clear( int time )
	throws SynthException
	{
		int nativeError = Synth.ClearDataQueueAt( time, peerToken, portHash );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken );
	}

/* ================================
** Implementation of methods in a way that is non-specific to samples or envelopes.
** The subclasses SynthSampleQueue and SynthEnvelopeQueue will only allow
** the appropriate data class to be passed.
*/

/*
 * Queue all or a portion of this data to be played once by this SynthUnit.
 * Queued data will be played in First-In-First-Out(FIFO) order.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( SynthChannelData channelData, int startFrame, int numFrames, int flags )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueData( peerToken, portHash, channelDataToken, startFrame, numFrames, flags);
		if( nativeError < 0 ) throw new SynthException( nativeError, name, peerToken, startFrame );
	}
	public void queue( SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		queue( channelData, startFrame, numFrames, 0 );
	}

/*
 * Queue all or a portion of this channelData to be played by this SynthUnit in a loop.
 * If there is any channelData data after this in the queue then this portion will not be played.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueData( peerToken, portHash, channelDataToken, startFrame, numFrames, Synth.FLAG_LOOP_IF_LAST );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}
/*
 * Queue all or a portion of this channelData to be played once by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queue( int time, SynthChannelData channelData, int startFrame, int numFrames, int flags)
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueDataAt( time, peerToken, portHash, channelDataToken, startFrame, numFrames, flags );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}
	public void queue( int time, SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		queue( time, channelData, startFrame, numFrames, 0 );
	}
/*
 * Queue all or a portion of this channelData to be played in a loop by this SynthUnit.
 * The request will be <B>placed in the queue</B> at the specified time.
 * The data will then be played when it reaches the front of the queue.
 *
 * @exception SynthException	 If queue name is not recognized, or frames
 *        are out of range.
 */
	public void queueLoop( int time, SynthChannelData channelData, int startFrame, int numFrames )
	throws SynthException
	{
		int channelDataToken = channelData.getPeer();
		int nativeError = Synth.QueueDataAt( time, peerToken, portHash, channelDataToken, startFrame, numFrames, Synth.FLAG_LOOP_IF_LAST );
		if( nativeError < 0 ) throw new SynthException( nativeError, name, startFrame, numFrames );
	}

/**
 *	Convenience method that will queue the attack portion of a channelData and the sustain loop if it exists.
 *	This could be used to implement a NoteOn method.
 *
 * @exception SynthException When placement in the queue fails.
 */
	void queueOn( int time, SynthChannelData channelData )
	throws SynthException
	{
		clear( time );

		if( channelData.getSustainBegin() <= 0 )
		{
			if( channelData.getReleaseBegin() < 0 )
			{
				queue( time, channelData, 0, channelData.getNumFrames() );	 /* No loops. */
			}
			else
			{
				queue( time, channelData, 0, channelData.getReleaseEnd() );		
				queueLoop( time, channelData, channelData.getReleaseBegin(), channelData.getReleaseSize() );
			}
		}
		else if( channelData.getSustainBegin() == 0 )
		{
			queueLoop( time, channelData, 0, channelData.getSustainSize() );
		}
		else
		{
			queue( time, channelData, 0, channelData.getSustainEnd() );
			int size = channelData.getSustainSize();
			if( size > 0 )
			{
				queueLoop( time, channelData, channelData.getSustainBegin() , size );
			}
		}
	}

/**
 *	Convenience method that will queue the decay portion of a channelData, or the gap and
 *	release loop portions if they exist. 
 *	This could be used to implement a NoteOff method.
 * @ifStop Will cause Synth.FLAG_AUTO_STOP to be passed if decay portion queued without
 *    a release loop. This will stop execution of the unit.
 * @exception SynthException  When placement in the queue fails.
 */
	void queueOff( int time, SynthChannelData channelData, boolean ifStop )
	throws SynthException
	{
     	if( channelData.getSustainBegin() >= 0 )	 /* Sustain loop? */
		{
			if( channelData.getReleaseBegin() < 0 )
			{	/* Sustain loop, no release loop. */
				int size = channelData.getNumFrames() - channelData.getSustainEnd();
				if( size > 0 )
				{
					queue( time, channelData, channelData.getSustainEnd(), size,
						   (ifStop ? Synth.FLAG_AUTO_STOP : 0) );
				}
			}
			else  if( channelData.getReleaseBegin() >  channelData.getSustainEnd() )
			{  /* Queue gap between sustain and release loop. */
				queue( time, channelData, channelData.getSustainEnd(),
					channelData.getReleaseEnd() - channelData.getSustainEnd() );		
				queueLoop( time, channelData, channelData.getReleaseBegin(), channelData.getReleaseSize() );
			}
			else
			{  /* No gap between sustain and release. */
				queueLoop( time, channelData, channelData.getReleaseBegin(), channelData.getReleaseSize() );
			}
		}
		/* If no sustain loop, then nothing to do. */
	}
/**
 * Passes false to queueOff for ifStop
 * @exception SynthException  When placement in the queue fails.
 */
	void queueOff( int time, SynthChannelData channelData )
	throws SynthException
	{
		queueOff( time, channelData, false );
	}
	
/**
 * @return number of frames read or written by a port
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public int getNumFramesMoved( int partIndex )
	throws SynthException
	{
		int value = Synth.GetPortFrames( peerToken, portHash, partIndex);
/* Check for error return indicator disguised as -1. */
		if( value < -1)
		{
			throw new SynthException( "Error in getNumFramesMoved()" );
		}
		return value;
	}
	public int getNumFramesMoved()
	throws SynthException
	{
		return getNumFramesMoved(0);
	}


}
