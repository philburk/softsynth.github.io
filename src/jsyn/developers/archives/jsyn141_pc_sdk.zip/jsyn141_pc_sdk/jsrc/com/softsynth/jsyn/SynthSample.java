package com.softsynth.jsyn;
import java.util.*;
import java.io.*;
import java.net.URL;

/**
 *	The SynthSample class is a container for digital audio data. 
 * <br>
 * The actual data may need to reside in memory that is accessible to 
 *	DMA or to a DSP so we cannot assume that it is in main memory.  We also need to maintain cache coherence if the data is 
 *	going to be read or written by hardware other than the CPU.  For this reason, Samples cannot use memory allocated by, or 
 *	accessable to the application.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthTable
 * @see SampleReader_16V1
 * @see SampleReader_16F1
 * @see SampleReader_16F2
 * @see SampleWriter_16F1
 * @see SampleWriter_16F2
 * @see DelayUnit
 */

public class SynthSample extends SynthChannelData
{
	public static final int UNRECOGNIZED = 0;
	public static final int AIFF = 1;
	public static final int WAV = 2;
	
	int    channelsPerFrame;
	double recordedSampleRate = 44100.0;
	double lowestAmplitude = 0.0;
	double highestAmplitude = 1.0;
	double lowestFrequency = 0.0;
	double highestFrequency = 88200.0;
	double baseFrequency = 440.0;
	
	public byte[]  byteData;
	boolean        ifLoadData; /* If true, load sound data into memory. */
	long           dataPosition;  /* Number of bytes from beginning of file where sound data resides. */

/**
 * Create an empty sample. You must call allocate() before using the sample.
 */
	public SynthSample()
	{
		super();
	}
/**
 * Create a digital audio sample with the specified number of frames,
 * and channels per frame. 
 * @param numFrames Number of sample frames to allocate.
 * @param channelsPerFrame Number of channels in a frame, eg. 1 for mono, 2 for stereo.
 * @exception SynthException	 If there is insufficient memory.
 */
	public SynthSample( int numFrames, int channelsPerFrame )
		throws SynthException
	{
		super( numFrames );
		allocate( numFrames, channelsPerFrame );
	}

/** Determine file type based on suffix, case insensitive.
 * Returns SynthSample.AIFF for ".aiff", ".aif", "AIFF", or "AIF".
 * Returns SynthSample.WAV for ".wave", ".wav", ".WAVE" or ".WAV".
 * Returns SynthSample.UNRECOGNIZED for anything else.
 * @return integer indicating file type.
 */
	public static int getFileType( String fileName )
	{
		if( fileName.endsWith(".aiff") ||
			fileName.endsWith(".aif") ||
			fileName.endsWith(".AIFF") ||
			fileName.endsWith(".AIF") )
		{
			return AIFF;
		}
		else if( fileName.endsWith(".wave") ||
			fileName.endsWith(".wav") ||
			fileName.endsWith(".WAVE") ||
			fileName.endsWith(".WAV") )
		{
			return WAV;
		}
		else return UNRECOGNIZED;
	}

/**
 * Allocate low level sample resources and memory to hold sample data.
 * @exception SynthException	 If there is insufficient memory.
 */
	public void allocate( int numFrames, int channelsPerFrame )
		throws SynthException
	{
		delete();
		this.channelsPerFrame = channelsPerFrame;
		this.numFrames = numFrames;
		peerToken = Synth.CreateSample( numFrames, channelsPerFrame );
		if( peerToken < 0 ) throw new SynthException( peerToken, numFrames );
	}
/**
 * Create a monophonic sample with the specified number of frames.
 * Since it is monophonic, the number of frames 
 * equals the number of samples. 
 * @exception SynthException	 If there is insufficient memory.
 */
	public SynthSample( int numFrames ) throws SynthException
	{
		this( numFrames, 1 );
	}

/**
 * Write data from an array of shorts to the Samples internal storage area.
 * The internal storage might be in main memory, or it might be located on a
 * sound card and only accessable by DMA.
 * @param firstSampleFrame = Index of first frame of sample to be written to. A frame in a mono sample is one short. A frame in a stereo sample is two shorts.
 * @param data = array of shorts containing sample data.
 * @param firstDataIndex = index of first element in data array to write from. Note that for stereo samples, the firstDataIndex is twice the equivalent frame index.
 * @param numFrames = number of frames to write.
 * @exception SynthException	 If frames are out of range.
 */
	public void write( int firstSampleFrame, short[] data, int firstDataIndex, int numFrames )
	throws SynthException
	{
		if( Synth.verbosity >= Synth.VERBOSE )
		{
			System.out.println("SynthSample write( " + firstSampleFrame + ", ..., " +
							   firstDataIndex + ", " + numFrames + " )");
		}
		int result = Synth.WriteSample( peerToken, firstSampleFrame, numFrames, data, firstDataIndex, data.length );
		if( result < 0 ) throw new SynthException( result, firstSampleFrame );
	}
	
	public void write( short[] data )
	throws SynthException
	{
		write( 0, data, 0, data.length/channelsPerFrame );
	}
/**
 * Clear part of a SynthSample.
 * @param firstSampleFrame = Index of first frame of sample to clear. A frame in a mono sample is one short. A frame in a stereo sample is two shorts.
 * @param numFrames = number of frames to clear.
 * @exception SynthException	 If frames are out of range.
 */
	public void clear( int firstSampleFrame, int numFrames )
	{
		final int CLEAR_SIZE = 64;
		short zeros[] = new short[CLEAR_SIZE];
		int numClearFrames = CLEAR_SIZE / channelsPerFrame;
		int numFullWrites = numFrames / numClearFrames;
		int frameIndex = firstSampleFrame;
		for( int i=0; i<numFullWrites; i++ )
		{
			write( frameIndex, zeros, 0, numClearFrames );
			frameIndex += numClearFrames;
		}
		int remainingFrames = numFrames - (numClearFrames * numFullWrites);
		if( remainingFrames > 0 )
		{
			write( frameIndex, zeros, 0, remainingFrames );
		}
	}
	public void clear()
	{
		clear( 0, getNumFrames() );
	}
/**
 * Read from the SynthSample into an array of shorts.
 * @param firstSampleFrame = Index of first frame of sample to be read from. A frame in a mono sample is one short. A frame in a stereo sample is two shorts.
 * @param data = array of shorts containing sample data.
 * @param firstDataIndex = index of first element in data array to read into. Note that for stereo samples, the firstDataIndex is twice the equivalent frame index.
 * @param numFrames = number of frames to write.
 * @exception SynthException	 If frames are out of range.
 */
	public void read( int firstSampleFrame, short[] data, int firstDataIndex, int numFrames )
	throws SynthException
	{
		int result = Synth.ReadSample( peerToken, firstSampleFrame, numFrames, data, firstDataIndex, data.length );
		if( result < 0 ) throw new SynthException( result, firstSampleFrame );
	}
	
	public void read( short[] data )
	throws SynthException
	{
		read( 0, data, 0, data.length/channelsPerFrame );
	}

/**
 * Set rate at which sample was recorded.
 */
	public void setSampleRate( double sampleRate )
	{
		this.recordedSampleRate = sampleRate;
	}
	public double getSampleRate()
	{
		return recordedSampleRate;
	}
/**
 *
 */
	public void setBaseFrequency( double baseFrequency )
	{
		this.baseFrequency = baseFrequency;
	}
/**
 *	The best frequency to associate with the perceived pitch of the instrument when played at the recorded SampleRate.
 *	Sounds are often unpitched or enharmonic so this may not always be a meaningful measure.
 */
	public double getBaseFrequency()  { return baseFrequency; }

	public int getChannelsPerFrame()
	{
		return channelsPerFrame;
	}

/**
 *	Set range of Amplitudes for which this sample could be chosen
 *	when doing MultiSample selection.
 */
	public void setLowFrequency( double lowestFrequency )
	{
		this.lowestFrequency = lowestFrequency;
	}

	public void setHighFrequency( double highestFrequency )
	{
		this.highestFrequency = highestFrequency;
	}


/**
 *	Set range of Amplitudes for which this sample could be chosen
 *	when doing MultiSample selection.
 */
	public void setLowAmplitude( double lowestAmplitude )
	{
		this.lowestAmplitude = lowestAmplitude;
	}
	public void setHighAmplitude( double highestAmplitude )
	{
		this.highestAmplitude = highestAmplitude;
	}
	
/* Verbose version of toString. */
	public String dump()
	{
		String str = "Sample";
		str += "\n     numChannels = " + channelsPerFrame;
		str += "\n     sampleRate = " + recordedSampleRate;
		str += "\n     baseFrequency = " + baseFrequency;
		str += "\n     lowestFrequency = " + lowestFrequency;
		str += "\n     highestFrequency = " + highestFrequency;
		if( cuePoints != null )
		{
			str += "\n   Cue Points:";
			for( int k=0; k<cuePoints.size(); k++ )
			{
				CuePoint cue = (CuePoint) cuePoints.elementAt(k);
				str += "\n    " + cue.getID() + ", " + cue.getPosition();
			}
		}
		return str;
	}

/** @return Number of bytes from beginning of stream where sound data resides. */
	public long getOffset()
	{
		return dataPosition;
	}
	
	public void load( InputStream stream  ) throws SynthException, IOException
	{
		load( stream, true );
	}
	
/** Load the sample from the given stream.
 * Calls loadShorts then write the data to the SynthSample.
 * This method does nothing in the SynthSample base class.
 * Use SynthSampleAIFF or other format specific classes to actually load the sample.
 * 
 * @param stream May be any stream from a file, a URL, a byte array, etc.
 * @param ifLoadData If true, sample data will be loaded into memory.
 * @exception SynthException	 If parsing fails, or there is insufficient memory.
 */
	public void load( InputStream stream, boolean ifLoadData ) throws SynthException, IOException
	{
		short[] shortData = loadShorts( stream, ifLoadData );
		if( shortData != null )
		{
			allocate( numFrames, channelsPerFrame );
			write( shortData );
		}
	}
	public short[] loadShorts( InputStream stream, boolean ifLoadData ) throws SynthException, IOException
	{
		return null;
	}

/* Convert little endian bytes to shorts. */
	short[] convertLittleBytesToShorts()
	{
		int numShorts = byteData.length / 2;
		short shortData[] = new short[numShorts];
		for( int i=0; i<numShorts; i++ )
		{
			shortData[i] = (short) ((byteData[i*2] & 0xFF) | (byteData[i*2 + 1] << 8));
		}
		return shortData;
	}
	
/* Convert big endian bytes to shorts. */
	short[] convertBigBytesToShorts()
	{
		int numShorts = byteData.length / 2;
		short shortData[] = new short[numShorts];
		for( int i=0; i<numShorts; i++ )
		{
			shortData[i] = (short) ((byteData[i*2 + 1] & 0xFF) | (byteData[i*2] << 8));
		}
		return shortData;
	}

}
