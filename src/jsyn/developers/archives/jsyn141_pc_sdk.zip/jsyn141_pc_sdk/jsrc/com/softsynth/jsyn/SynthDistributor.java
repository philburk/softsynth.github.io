package com.softsynth.jsyn;
import java.util.*;


/**
 * SynthDistributor class for Java Audio Synthesis
 * 
 * A SynthDistributor acts as a single input port that maps to multiple ports
 * inside a SynthCircuit. When building a circuit, connect the SynthDistributor
 * to all of the internal inputs that you want to drive together. You can then
 * set() a value for the SynthDistributor with a single call
 * and it will be passed to all of the
 * connected ports inside the circuit. You can also connect a SynthOutput to it 
 * and a connection will automatically be made to all of the connected internal
 * ports. If you did not use a SynthDistributor, then you would need to use
 * an AddUnit to provide the fan-out but this would add run-time overhead to the CPU.
 * The SynthDistributor has no run-time overhead during synthesis.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 */


public class SynthDistributor extends SynthInput
{
	SynthOutput  driver;
	
	int          outIndex;
	Vector       connected; /* contains DistributorRecords */
	int          signalType = Synth.SIGNAL_TYPE_FULL_RANGE;
	double       lastValue;
	
/** An example call is:
 * <PRE>frequency = new SynthDistributor( this, "frequency", Synth.SIGNAL_TYPE_OSC_FREQ ); </PRE>
 * @exception SynthException	 If sound or signalType is invalid.
 */
	public SynthDistributor( SynthSound sound, String name, int signalType ) throws SynthException
	{
		super( sound, name );
		connected = new Vector();
		setSignalType( signalType );
	}
/** Use null sound for distributor that is not part of a circuit.
 * @exception SynthException	 If signalType is invalid.
 */

	public SynthDistributor( String name, int signalType ) throws SynthException
	{
		this( null, name, signalType );
	}
/** Use default signal type of Synth.SIGNAL_TYPE_FULL_RANGE
 * @exception SynthException	 If sound is invalid.
 */

	public SynthDistributor( SynthSound sound, String name ) throws SynthException
	{
		this( sound, name, Synth.SIGNAL_TYPE_FULL_RANGE );
	}
/** Use null sound, and default signal type of Synth.SIGNAL_TYPE_FULL_RANGE
 * @exception SynthException	 Unlikely.
 */
	public SynthDistributor( String name ) throws SynthException
	{
		this( null, name, Synth.SIGNAL_TYPE_FULL_RANGE );
	}

/**	
 * Input port will be connected to any port that is driving this SynthDistributor.
 * The SynthDistributor signal type will also be passed to the inPort.
 * The current value will be set() if there is no driver.
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void connect( int outIndex, SynthInput inPort, int inIndex ) throws SynthException
	{
		if( outIndex > 0 ) throw new SynthException( Synth.JS_ERR_OUT_OF_RANGE, "SynthDistributor part = " + inIndex );
/* make sure it's not already connected. */
		SDRec  dr = null;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			if( (dr.port == inPort) && (dr.partNum == inIndex) )
			{
				System.out.println("SynthDistributor already connected!");
				break;
			}
			dr = null;
		}		

/* All connected inputs should have same type. */
		inPort.setSignalType( signalType );
		inPort.set( lastValue ); /* Set in case later disconnected. */
		
		// System.out.println("SynthDistributor connecting to SynthInput: driver = " + driver );
		if( driver != null )
		{
			inPort.connect( inIndex, driver, outIndex );
		}
		
		if( dr == null )
		{
			dr = new SDRec( inPort, inIndex );
			connected.addElement( dr );
		}
	}
	
/**	
 *	Connect output port of another instrument to this distributor.
 *  Output port will internally connect to all of the associated
 *  Input ports.
 *
 * @exception SynthException	If port name is not recognized, or index out of range,
 *            or destPort already connected.
 */
	public void connect( int inIndex, SynthOutput outPort, int outIndex ) throws SynthException
	{
		if( inIndex > 0 ) throw new SynthException( Synth.JS_ERR_OUT_OF_RANGE, "SynthDistributor part = " + inIndex );
		driver = outPort;
		this.outIndex = outIndex;
/* Enumerate through associated SynthInput ports and connect them. */
		SDRec  dr;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			dr.port.connect( dr.partNum, driver, outIndex );
		}		
	}

/**
 *	Disconnects any SynthOutput connected to this distributor.
 *
 * @exception SynthException	If port name is not recognized, or index out of range.
 */
	public void disconnect( int index )
	throws SynthException
	{
		this.driver = null;
		this.outIndex = 0;
	}
		
/** Remove record for connection to this port from internal Vector.
 * @exception SynthException	If port is invalid, or index out of range.
 */
	public void disconnect( SynthInput inPort, int inIndex )
	throws SynthException
	{
		SDRec  dr;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			if( (dr.port == inPort) && (dr.partNum == inIndex) )
			{
				connected.removeElement( dr );
				break;
			}
		}		
	}

	public void disconnect( SynthInput inPort )
	throws SynthException
	{
		disconnect( inPort, 0 );
	}
	
/** Set value of all connected SynthInputs at specified time.
 * @exception SynthException	If port is invalid, or index out of range.
 */
  	public void set( int time, double value, int partIndex )
	throws SynthException
	{
		lastValue = value;
/* Enumerate through associated SynthInput ports and set them. */
		SDRec  dr;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			dr.port.set( time, value, partIndex );
		}		
	}
	
/** Set value of all connected SynthInputs.
 * @exception SynthException	If port is invalid, or index out of range.
 */
	public void set( double value, int partIndex )
	throws SynthException
	{
		lastValue = value;
/* Enumerate through associated SynthInput ports and set them. */
		SDRec  dr;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			dr.port.set( value, partIndex );
		}		
	}
	
/** Set signalType of all connected SynthInputs.
 * @exception SynthException	If port is invalid, or index out of range.
 */
	public void setSignalType( int signalType, int partIndex )
	throws SynthException
	{
		this.signalType = signalType;
		setMinMaxByType( signalType );

/* Enumerate through associated SynthInput ports and set them. */
		SDRec  dr;
		Enumeration e = connected.elements();
		while( e.hasMoreElements() )
		{
			dr = (SDRec) e.nextElement();
			dr.port.setSignalType( signalType, partIndex );
		}		
	}
		
/** @return signalType of all connected SynthInputs.
 * @exception SynthException	If port is invalid, or index out of range.
 */
	public int getSignalType( int partIndex  )
	throws SynthException
	{
		return signalType;
	}

/**
 * @return current instantaneous value of port.
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public double get( int partIndex )
	throws SynthException
	{
		if( driver != null ) return driver.get( partIndex );
		else return lastValue;
	}

/**
 * @return current instantaneous value of port.
 * @exception SynthException If port name is not recognized, or index out of range.
 */
	public double get()
	throws SynthException
	{
		return get( 0 );
	}
	
	/* Make this an inner class because noone else has to see it. */
	class SDRec
	{
		SynthInput  port;
		int         partNum;
		
		SDRec( SynthInput port, int partNum )
		{
			this.port = port;
			this.partNum = partNum;
		}
	}
}


