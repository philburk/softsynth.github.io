package com.softsynth.jsyn;
import java.util.*;
/**
 * <P>SynthCircuits contain SynthUnits connected together to make a complex circuit
 * or patch.  The ports of the internal units can be exported with names and used
 * by set() or connect().
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthChannelData
 */

public class SynthCircuit extends SynthSound
{
/** Output of circuit. May be left null by subclasses. */
	public SynthOutput output = null; 
	Vector             sounds;
	int                flags = 0;

/**
 * Base constructor overridden by subclasses.
 * Creates an empty hashtable for the exported ports.
 *
 * @param numSounds maximum number of sounds allowed in circuit
 * @exception SynthException If memory allocation fails.
*/

 	public SynthCircuit( int numSounds ) throws SynthException
	{
		super();
		sounds = new Vector( numSounds );
	}
/**
 * Base constructor overridden by subclasses.
 * Creates an empty hashtable for the exported ports.
 *
 * Defaults to 8 initial sounds.
 * @exception SynthException If memory allocation fails.
*/

 	public SynthCircuit( ) throws SynthException
	{
		this(8);
	}


/**
 * Add this sound to internal vector of subUnits.
 * this will allow it to be automatically started,
 * stopped, deleted.
 * @exception SynthException	If circuit already compiled by compile() or start() method.
 */
	public synchronized void add( SynthSound sound ) throws SynthException
	{
		if( peerToken == 0 )
		{
			sounds.addElement(sound);
		}
		else
		{
			throw new SynthException( Synth.JS_ERR_CIRCUIT_CLOSED, 0 );
		}
	}

/**
 * @return peer. Compile if needed.
 * @exception SynthException If compilation of circuit fails.
 */
	public int getPeer()
	throws SynthException
	{
		if( peerToken == 0 ) compile();  // in case not compiled yet
		return super.getPeer();
	}

/**
 * Collect together the sounds added using add() into a circuit.
 * @exception SynthException  If any subunits are invalid.
 */
	public synchronized void compile()	throws SynthException
	{
		SynthSound sound;
		if( peerToken != 0 ) return; /* Already compiled! */
		int numUnits = sounds.size();
		int[] peerArray = new int[numUnits];
		for( int i=0; i<numUnits; i++ )
		{
			sound = (SynthSound) sounds.elementAt(i);
			peerArray[i] = sound.getPeer();
		}
		peerToken = Synth.createCircuit( peerArray, flags );
		if( peerToken < 0 )
		{
			throw new SynthException( peerToken, "Circuit", numUnits );
		}

		if( Synth.verbosity >= Synth.TERSE )
		{
			System.out.println("compiled " + this);
		}
	}

/** Delete all subunits and then delete the circuit.
 */
	public synchronized void delete() throws SynthException
	{
		int lastIndex;
		output = null;
		while( (lastIndex = (sounds.size() - 1)) >= 0 )
		{
			SynthSound sobj = (SynthSound) sounds.elementAt( lastIndex );
			sounds.removeElementAt( lastIndex );
			sobj.delete();
		}
		super.delete();
	}

/** Load a SynthCircuit by its name string. The circuit class must be in the
 * CLASSPATH.
 * @return null if the class cannot be found or loaded.
 */
	public static SynthCircuit loadByName( String name )
	{
		Class lbc;
		SynthCircuit  circ = null;
		try
		{
			lbc = Class.forName( name );
			System.out.println("lbc = " + lbc );
		} catch( ClassNotFoundException e ) {
			System.err.println(" Error finding " + name + " = " + e );
			return null;
		}
		try
		{
			circ = (SynthCircuit) lbc.newInstance();
		} catch( InstantiationException e ) {
			System.err.println(" Error instantiating " + name + " = " + e );
			return null;
		} catch( IllegalAccessException e ) {
			System.err.println(" Error loading " + name + " = " + e );
			return null;
		}

		return circ;
	}

}
