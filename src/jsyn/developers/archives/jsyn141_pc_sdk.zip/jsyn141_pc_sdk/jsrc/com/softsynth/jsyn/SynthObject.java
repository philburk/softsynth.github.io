package com.softsynth.jsyn;
import java.util.*;

/**
 * Root class for all JSyn units, samples, envelopes, etc.
 * SynthObject deletes its native peers when deleted.
 * This class will optionally keep a list of all SynthObjects created to prevent
 * unexpected garbage collection.
 *
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @version JSyn Version 005
 * @see Synth
 * @see SynthUnit
 */

public class SynthObject extends Observable
{
	int  peerToken = 0;  /* Token returned by native Create*() */
	int  nativeError = 0;
	private static Vector objects; // Keep list of objects so that garbage collector doesn't kill them.
	private static Vector enabledThreads;
	private static boolean deleteByGarbageCollector = true;
	
	static
	{
		objects = new Vector();
		enabledThreads = new Vector();
	}
	
	public SynthObject()
	{
		if( isTrackingEnabled() ) track();
	}
	
	public static boolean isTrackingEnabled()
	{
		return enabledThreads.contains( Thread.currentThread() );
	}
	
/** Request that all SynthObjects created by <b>the currently executing thread</b>
 * be automatically tracked when created, or not. Calls can be nested.
 * @see track
 */
	public static void enableTracking( boolean ifTrack )
	{
		if( ifTrack )
		{
			enabledThreads.addElement( Thread.currentThread() );
		}
		else
		{
			enabledThreads.removeElement( Thread.currentThread() );
		}
	}
	
/** Keep a reference to this object in a vector in the SynthObject class.
 * This will prevent the garbage collector from accidentally deleting a JSyn object that is
 * active but not referenced by any other Java objects.
 * It also allows the object to be deleted automatically by stopEngine()
 * or by calling SynthObject.deleteAll().
 */
	public synchronized void track()
	{
		objects.addElement( this ); // keep reference
	}
	
	public int getPeer() throws SynthException
	{
		return peerToken;
	}
	
/** Delete all units, SynthSamples, SynthEnvelopes and other Synth objects created since
 * Synth.startEngine() was called. This will be called automatically by
 * Synth.stopEngine().
 */
	static public synchronized void deleteAll() throws SynthException
	{
		while( !objects.isEmpty() )
		{
			SynthObject sobj = (SynthObject) objects.lastElement();
//			System.out.println("deleteAll: deleting " + sobj );
			sobj.delete();
		}
		enabledThreads.removeAllElements();
	}
/**
 * Delete the native structure that is associated with this object.
 * Also removes the object from the list kept by the SynthObject class
 * for the deleteAll() method.
 * 
 * @exception SynthException If token already deleted.
 */
	public synchronized void delete()  throws SynthException
	{
		int result;
		if( peerToken != 0 )
		{
			if( Synth.verbosity >= Synth.TERSE )
			{
				System.out.println("Synth object deleted = " + this );
			}
			int nativeError = Synth.delete( peerToken );
			int saveToken = peerToken;
			peerToken = 0;
			if( nativeError < 0 ) throw new SynthException( nativeError, saveToken );
		}
		objects.removeElement( this );
	}

/**
 * Enable deletion of the native portion ofSynthObjects (eg. units and samples)
 * when the Java portion is deleted by the Garbage Collector.<br>
 * Warning: enabling this can cause unexpected removal of objects that may be
 * making sound but are  no longer referenced by Java.
 * The sudden silence can be embarassing.<br>
 * Warning: disabling this can cause native resources to accumulate unless you explicitly
 * delete them using their delete() method.
 * This can consume memory and cause memory allocation to fail.<br>
 * The safest thing to do is to disable this and delete() your own objects
 * when you are through using them.
 * @see Synth.getObjectCount
 */
	public static void enableDeletionByGarbageCollector( boolean ifEnabled )
	{
		deleteByGarbageCollector = ifEnabled;
	}
	
/**
 * Delete the native structure that is associated with this object
 * after call to super.finalize().
 *
 * @exception Throwable  Propagated from super.finalize() for whatever reason.
 */

	protected void finalize() throws Throwable
	{
		super.finalize();
		if( deleteByGarbageCollector )
		{
			try
			{
				// System.out.println("finalize: call delete " + this );
				delete();
			} catch (SynthException e) {
	//			System.err.println(e);
			}
		}
    }

	public String toString()
	{
		return super.toString() + ", peer = 0x" + Integer.toHexString(peerToken);
	}
}
