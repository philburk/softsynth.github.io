
package com.softsynth.jsyn.util;
import com.softsynth.jsyn.*;
import java.util.*;
import java.io.*;

/** 
 * Adds streaming capabilities to a SynthSampleQueue.
 * This is the base class for SampleQueueInputStream and SampleQueueOutputStream
 * 
 * @author (C) 1997 Phil Burk, SoftSynth.com, All Rights Reserved
 * @see StreamRecorder
 */
public abstract class SampleQueueStream
{
	SynthSampleQueue  queue;
	SynthSample       sample;
	int               framesMoved = 0;
	int               frameIndex = 0;
	int               startTime;
	boolean           running = false;
	boolean           flowError = false;
	int               maxTicksPerSleep;
	
/** 
 */
	public SampleQueueStream( SynthSampleQueue queue, int bufferSizeInFrames, int channelsPerFrame )
	{
		this.queue = queue;
		sample = new SynthSample( bufferSizeInFrames, channelsPerFrame );
		int ticksPerBuffer = bufferSizeInFrames / Synth.getFramesPerTick();
	// determine reasonable maximum number of ticks to sleep
		maxTicksPerSleep = ticksPerBuffer / 8;
		if( maxTicksPerSleep < 1 ) maxTicksPerSleep = 1;
		if( maxTicksPerSleep < 64 ) maxTicksPerSleep = ticksPerBuffer / 4;
		if( maxTicksPerSleep < 64 ) maxTicksPerSleep = ticksPerBuffer / 2;
		// System.out.println("maxTicksPerSleep = " + maxTicksPerSleep );
	}
	
	public SynthSample getSample()
	{
		return sample;
	}
	
	public void start( int time )
	{
		framesMoved = 0;
		startTime = time;
		running = true;
		flowError = false;
	}
	
	public void stop( int time )
	{
		running = false;
	}
		
/** Determine how many frames could be read or written
 * without blocking. This implementation currently uses the tick
 * timer to calculate how many frames have been played. This will
 * be accurate for SampleWriters that always write one sample frame
 * per audio frame, such as SampleWriter_16F1. A future implementation
 * may use the getNumFramesMoved() query when it is fully implemented.
 */
	public synchronized int available()
	{
		int available = getNumWhenSatisfied() - framesMoved;
		if( running )
		{
	// Add on frames already played, minus a smidge to prevent overlap r/w.
			int ticksPlayed = Synth.getTickCount() - startTime - 1;
			available += ticksPlayed * Synth.getFramesPerTick();
		}
		// System.out.println("available = " + available );
	// Check for no data or overflow.
		if( available < 0 ) available = 0;
		else if( available > sample.getNumFrames() )
		{
			flowError = true;
			available = sample.getNumFrames();
		}
		return available;
	}
	
/* Read an array of short data from sample.
* If there is not enough data available, block until all of the data can be read.
* To avoid blocking, call available() first to see how much can be read without blocking.
* @param data Array of shorts containing PCM sample data
* @param offset index in samples to start reading data from array
* @param numFrames number of frames to read from sample
* @return number of frames read
*/
	public int move( short data[], int offset, int numFrames )
	{
		int framesLeft = numFrames; // how many frames we have left to process
		while( framesLeft > 0 ) // still more needed?
		{
			int available = available();
			if( available > 0 )  // can we do some now?
			{
				int numToMove = ( framesLeft > available ) ? available : framesLeft;
				framesMoved += moveNow( data, offset, numToMove );
				offset += numToMove * sample.getChannelsPerFrame();
				framesLeft -= numToMove;
			}
			if( framesLeft > 0 )
			{
				if( !running ) return (numFrames - framesLeft);
				int ticksToSleep = framesLeft / Synth.getFramesPerTick();
				if( ticksToSleep > maxTicksPerSleep ) ticksToSleep = maxTicksPerSleep;
				Synth.sleepForTicks( ticksToSleep + 1 );
			}
		}
		return numFrames;
	}
	
/** Assume that there is room in buffer and just read data.
 */
	synchronized int moveNow( short data[], int offset, int numFrames )
	{ 
	// Can we read entire amount in one contiguous area?
		if( (frameIndex + numFrames) <= sample.getNumFrames() )
		{
			moveDirect( frameIndex, data, offset, numFrames );
			queue.queue( sample, frameIndex, numFrames );
			frameIndex += numFrames;
			if( frameIndex >= sample.getNumFrames() ) frameIndex -= sample.getNumFrames();
		}
		else
	// read in two sections that span end of sample
		{
			int firstNum = sample.getNumFrames() - frameIndex;
			moveDirect( frameIndex, data, offset, firstNum );
			queue.queue( sample, frameIndex, firstNum );
			offset += ( firstNum * sample.getChannelsPerFrame() );
			int secondNum = numFrames - firstNum;
			// System.out.println("num = " + num + ", firstNum = " + firstNum + ", secondNum = " + secondNum );
			moveDirect( 0, data, offset, secondNum );
			queue.queue( sample, 0, secondNum );
			frameIndex = secondNum;
		}
		return numFrames;
	}
	
/** Assume that queue is ready and just move data.
 * @return number of frames moved
 */
	abstract void moveDirect( int frameIndex, short data[], int offset, int numFrames );

/** Return the number of frames when this stream has been fully serviced.
 * For a writer, this would be when full. For a reader, this would be when empty.
 */
	abstract int getNumWhenSatisfied();
}
