README for CSyn Tools
(C) 2000 Phil Burk

These tools are provided to help JSyn and CSyn users test and tune the audio 
system on the PC. Please do not redistribute these files. They may be freely 
downloaded from:

	http://www.softsynth.com/jsyn/developers/csyn_tools_pc.zip

These programs only require that DirectX be installed properly on your PC and 
that audio output is functional. They do not require the JSyn or CSyn DLLs.

Run these programs from the MS-DOS shell.

MAXSINES.EXE

Plays more and more sines until the CPU utilization exceeds 80%. This gives you 
a measure of the performance of your CPU. It is also a good test of whether CSyn 
and DirectSound are working on your machine.

BENCHTIME.EXE

Benchmarks various unit generators.

AUDIODEVICES.EXE

Displays the audio devices that are available to JSyn/CSyn via the PortAudio library.
You can select an alternate output device for use by JSyn by setting a variable
in your AUTOEXEC.BAT file and rebooting. For example:

	set PA_RECOMMENDED_OUTPUT_DEVICE=1
	
PAMINLAT.EXE

You can use this program to determine the minimum latency of your machine. Run 
it then experiment with various numbers of buffers to see how low you can go 
without getting glitches. Youi can then request that PortAudio use a minimum 
latency be setting a variable in your AUTOEXEC.BAT file and rebooting. For 
example, to set the minimum latency to 130 milliseconds:

	set PA_MIN_LATENCY_MSEC=130

If you have questions or comments, write to: support@softsynth.com
