package com.mobileer.android.hellojsyn;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.jsyn.android.PortFader;

public class MainActivity extends AppCompatActivity {

    private SineSynth mSineSynth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSineSynth = new SineSynth();
        LinearLayout faderView = (LinearLayout) findViewById(R.id.layout_faders);
        faderView.addView(new PortFader(this, mSineSynth.getAmplitudePort()));
        faderView.addView(new PortFader(this, mSineSynth.getLeftFrequencyPort()));
        faderView.addView(new PortFader(this, mSineSynth.getRightFrequencyPort()));
    }


    @Override
    public void onResume()
    {
        super.onResume();
        mSineSynth.start();
    }

    @Override
    public void onPause()
    {
        super.onPause();
        mSineSynth.stop();
    }

}
