/*
** CSyn Example
**
** Play Sawtooth oscillator on Left Channel
** Play Modulated Triangle on Right Channel.
**
** (C) 1997-2009  Phil Burk, Mobileer Inc, All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define T_ENGINE_FLAGS   (0)

#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

int main(void)
{
	CSynErr    result;
	// CSyn unit generators and other audio resources are represented by opaque tokens.
	CSynToken  csSaw = 0;
	CSynToken  csTri = 0;
	CSynToken  csTriLFO = 0;
	CSynToken  csOut = 0;
	
	// Create a context for the synthesis engine.
	// You can run multiple engines at different sample rates or in non-real-time.
	CSynContext context = CSyn_CreateContext();
	if( context == NULL ) goto finish;
	
	PRINT(("Test saw+tri+Line_Out\n\n"));
	PRINT(("You should hear a steady sawtooth on the left channel\n"));
	PRINT(("and 2 Hz Freq modulated triangle on the right channel.\n\n"));

	// Start the synthesis engine running as a background thread.
	result = CSyn_StartEngine( context, T_ENGINE_FLAGS, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", finish);
	
	// ================ Create Units ==================================
	// Make the unit generators that will run in the background.
	// Make a band-limited sawtooth oscillator.
	csSaw = CSyn_CreateUnit( context, CSYN_UNIT_Osc_SawtoothBL, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csSaw, "CSyn_CreateUnit( context,sawtooth)", cleanup);

	// Make a triangle oscillator to hear.
	csTri = CSyn_CreateUnit( context, CSYN_UNIT_Osc_Triangle, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csTri, "CSyn_CreateUnit( context,Osc_Triangle)", cleanup);
	// And another oscillator to slowly modulate the other triangle oscillator frequency.
	csTriLFO = CSyn_CreateUnit( context, CSYN_UNIT_Osc_Triangle, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csTriLFO, "CSyn_CreateUnit( context,Osc_Triangle)", cleanup);

	// Create LineOut so we can hear the result.
	csOut = CSyn_CreateUnit( context, CSYN_UNIT_Line_Out, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOut, "CSyn_CreateUnit( context,out)", cleanup);
	
	// ================ Adjust Units ==================================
	// Set frequency and amplitude of the various oscillators.
	// Frequency is in Hz.
	// Amplitude of audible oscillators is typically between 0.0 and 1.0.
	result = CSyn_SetPort( context, csSaw, CSYN_PORT_Frequency, 0, 400.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);
	result = CSyn_SetPort( context, csSaw, CSYN_PORT_Amplitude, 0, 0.7 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);
	
	result = CSyn_SetPort( context, csTri, CSYN_PORT_Amplitude, 0, 0.9 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);
	
	result = CSyn_SetPort( context, csTriLFO, CSYN_PORT_Frequency, 0,  2.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);

	// The LFO amplitude is high because it is the range of frequency modulation.
	result = CSyn_SetPort( context, csTriLFO, CSYN_PORT_Amplitude, 0, 400.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// ================ Connect Units ==================================
	// Connect sawtooth to left channel of stereo player.
	result = CSyn_ConnectUnits( context, csSaw, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	// Connect triangle to right channel of stereo player.
	result = CSyn_ConnectUnits( context, csTri, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 1 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	// Connect triangle LFO to frequency control of audio rate triangle.
	result = CSyn_ConnectUnits( context, csTriLFO, CSYN_PORT_Output, 0,
		csTri, CSYN_PORT_Frequency, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Start running the unit generators.
	result = CSyn_StartUnit( context, csOut );
	TEST_ERROR(result, "CSyn_StartUnit( context,out)", cleanup);
	result = CSyn_StartUnit( context, csSaw );
	TEST_ERROR(result, "CSyn_StartUnit( context,saw)", cleanup);
	result = CSyn_StartUnit( context, csTri );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csTriLFO );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	
	// Let synthesizer run in background while we wait for a keypress.
	printf("Hit enter to continue.\n");
	getchar();

	// Show CPU load.
	{
		double usage = CSyn_GetUsage( context );
		PRINT(("Usage = %g%c\n", usage * 100.0, '%'));
	}

cleanup:
	// Stop execution of units.
	CSyn_StopUnit( context, csOut );
	CSyn_StopUnit( context, csSaw );
	CSyn_StopUnit( context, csTri );
	CSyn_StopUnit( context, csTriLFO );
	
	// Delete the units.
	CSyn_Delete( context, csOut );
	CSyn_Delete( context, csSaw );
	CSyn_Delete( context, csTri );
	CSyn_Delete( context, csTriLFO );

	CSyn_StopEngine( context  );
	// Delete the context and any unitsd we forgot to delete.
	CSyn_DeleteContext( context );
	
finish:
	if( result < 0 )
	{
		PRINT(("Test failed = 0x%x\n", result));
	}
	else
	{
		PRINT(("Test succeeded = 0x%x\n", result));
	}

	// Convert to shell return code.
	return (result < 0) ? 1 : 0;
}
