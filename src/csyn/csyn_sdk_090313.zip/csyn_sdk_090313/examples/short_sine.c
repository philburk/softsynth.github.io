/*
** CSyn Example
**
** Play a sine wave for 4 seconds.
**
** (C) 1997-2009  Phil Burk, Mobileer Inc, All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define T_SECONDS        (4)
#define T_ENGINE_FLAGS   (0)

#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

int main(void)
{
	CSynErr    result;
	// CSyn unit generators and other audio resources are represented by opaque tokens.
	CSynToken  csSine = 0;
	CSynToken  csOut = 0;
	int ticks;
	
	// Create a context for the synthesis engine.
	// You can run multiple engines at different sample rates or in non-real-time.
	CSynContext context = CSyn_CreateContext();
	if( context == NULL ) goto finish;
	
	PRINT(("Test saw+tri+Line_Out\n\n"));
	PRINT(("You should hear a sine wave for %d seconds.\n", T_SECONDS));

	// Start the synthesis engine running as a background thread.
	result = CSyn_StartEngine( context, T_ENGINE_FLAGS, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", finish);
	
	// ================ Create Units ==================================
	// Make the unit generators that will run in the background.
	// Make a sine wave  oscillator.
	csSine = CSyn_CreateUnit( context, CSYN_UNIT_Osc_Sine, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csSine, "CSyn_CreateUnit( context,sawtooth)", cleanup);

	// Create LineOut so we can hear the result.
	csOut = CSyn_CreateUnit( context, CSYN_UNIT_Line_Out, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOut, "CSyn_CreateUnit( context,out)", cleanup);
	
	// Set frequency and amplitude of the various oscillators.
	// Frequency is in Hz.
	// Amplitude of audible oscillators is typically between 0.0 and 1.0.
	result = CSyn_SetPort( context, csSine, CSYN_PORT_Frequency, 0, 660.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);
	result = CSyn_SetPort( context, csSine, CSYN_PORT_Amplitude, 0, 0.5 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);
	
	// ================ Connect Units ==================================
	// Connect sawtooth to both channel of stereo player.
	result = CSyn_ConnectUnits( context, csSine, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	// Use part #1 of LineOut for right channel.
	result = CSyn_ConnectUnits( context, csSine, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 1 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Start running the unit generators.
	result = CSyn_StartUnit( context, csOut );
	TEST_ERROR(result, "CSyn_StartUnit( context,out)", cleanup);
	result = CSyn_StartUnit( context, csSine );
	TEST_ERROR(result, "CSyn_StartUnit( context,saw)", cleanup);
	
	// Calculate time in ticks and sleep for a while.
	ticks = CSyn_GetTickRate( context ) * T_SECONDS;
	PRINT(("Sleeping for %d ticks.\n", ticks ));
	CSyn_SleepForTicks( context, ticks );

cleanup:
	// Stop execution of units.
	CSyn_StopUnit( context, csOut );
	CSyn_StopUnit( context, csSine );
	
	// Delete the units.
	CSyn_Delete( context, csOut );
	CSyn_Delete( context, csSine );

	CSyn_StopEngine( context  );
	// Delete the context and any unitsd we forgot to delete.
	CSyn_DeleteContext( context );
	
finish:
	if( result < 0 )
	{
		PRINT(("Test failed = 0x%x\n", result));
	}
	else
	{
		PRINT(("Test succeeded = 0x%x\n", result));
	}

	// Convert to shell return code.
	return (result < 0) ? 1 : 0;
}
