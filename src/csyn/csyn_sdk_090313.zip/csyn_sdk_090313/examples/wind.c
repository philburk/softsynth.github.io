/*
** CSyn Example
**
** Filter WhiteNoise with a resonant filter.
** Randomly modulate the the filter frequency.
** This sounds a bit like wind.
**
** (C) 1997-2009  Phil Burk, Mobileer Inc, All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define T_ENGINE_FLAGS   (0)

#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

int main(void)
{
	CSynErr    result;
	// CSyn unit generators and other audio resources are represented by opaque tokens.
	CSynToken  csScalar = 0;
	CSynToken  csLFO = 0;
	CSynToken  csFilter = 0;
	CSynToken  csNoise = 0;
	CSynToken  csOut = 0;
	
	// Create a context for the synthesis engine.
	// You can run multiple engines at different sample rates or in non-real-time.
	CSynContext context = CSyn_CreateContext();
	if( context == NULL ) goto finish;
	
	PRINT(("You should hear a modulating whistling noise like wind.\n\n"));

	// Start the synthesis engine running as a background thread.
	result = CSyn_StartEngine( context, T_ENGINE_FLAGS, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", finish);
	
	// ================ Create Units ==================================
	// Make the unit generators that will run in the background.
	// Make a white noise generator that we will feed into the filter.
	csNoise = CSyn_CreateUnit( context, CSYN_UNIT_Noise_White, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csNoise, "CSyn_CreateUnit( context,noise)", cleanup);
	csFilter = CSyn_CreateUnit( context, CSYN_UNIT_Filter_StateVariable, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csFilter, "CSyn_CreateUnit( context,csFilter)", cleanup);
	// A RedNoise generator is a chaotic ramp function.
	csLFO = CSyn_CreateUnit( context, CSYN_UNIT_Noise_Red, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csLFO, "CSyn_CreateUnit( context,csLFO)", cleanup);
	csScalar = CSyn_CreateUnit( context, CSYN_UNIT_Math_MultiplyAdd, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csScalar, "CSyn_CreateUnit( context,csScalar)", cleanup);

	// Create LineOut so we can hear the result.
	csOut = CSyn_CreateUnit( context, CSYN_UNIT_Line_Out, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOut, "CSyn_CreateUnit( context,out)", cleanup);
	
	// ================ Connect Units ==================================
	// RedNoiseLFO -> MultiplyAdd -\
	//               WhiteNoise -> Filter

	// Scale the output of the RedNoise using the MultiplyAdd unit and connect it to the filter frequency.
	result = CSyn_ConnectUnits( context, csLFO, CSYN_PORT_Output, 0, csScalar, CSYN_PORT_InputA, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csScalar, CSYN_PORT_Output, 0, csFilter, CSYN_PORT_Frequency, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Feed the WhiteNoise into the filter.
	result = CSyn_ConnectUnits( context, csNoise, CSYN_PORT_Output, 0, csFilter, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Connect filter output to left and right channel of stereo player.
	result = CSyn_ConnectUnits( context, csFilter, CSYN_PORT_Output, 0, csOut, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csFilter, CSYN_PORT_Output, 0, csOut, CSYN_PORT_Input, 1 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	
	// ================ Adjust Units ==================================
	result = CSyn_SetPort( context, csNoise, CSYN_PORT_Amplitude, 0, 0.3 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);
	// Modulation rate.
	result = CSyn_SetPort( context, csLFO, CSYN_PORT_Frequency, 0, 1.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// Control modulation depth of the filter frequency.
	result = CSyn_SetPort( context, csScalar, CSYN_PORT_InputB, 0, 300.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// Set center frequency for the filter.
	result = CSyn_SetPort( context, csScalar, CSYN_PORT_InputC, 0, 600.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// Lower values cause more resonant feedback and more whistling.
	result = CSyn_SetPort( context, csFilter, CSYN_PORT_Resonance, 0, 0.066 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);
	result = CSyn_SetPort( context, csFilter, CSYN_PORT_Amplitude, 0, 0.9 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// ================ Start Units ==================================
	result = CSyn_StartUnit( context, csLFO );
	TEST_ERROR(result, "CSyn_StartUnit( context,noise)", cleanup);
	result = CSyn_StartUnit( context, csScalar );
	TEST_ERROR(result, "CSyn_StartUnit( context,noise)", cleanup);
	result = CSyn_StartUnit( context, csNoise );
	TEST_ERROR(result, "CSyn_StartUnit( context,noise)", cleanup);
	result = CSyn_StartUnit( context, csFilter );
	TEST_ERROR(result, "CSyn_StartUnit( context,noise)", cleanup);
	result = CSyn_StartUnit( context, csOut );
	TEST_ERROR(result, "CSyn_StartUnit( context,out)", cleanup); 
	
	// Let synthesizer run in background while we wait for a keypress.
	printf("Hit enter to continue.\n");
	getchar();

	// Show CPU load.
	{
		double usage = CSyn_GetUsage( context );
		PRINT(("Usage = %g%c\n", usage * 100.0, '%'));
	}

cleanup:
	// Stop execution of units.
	CSyn_StopUnit( context, csOut );
	CSyn_StopUnit( context, csNoise );
	CSyn_StopUnit( context, csScalar );
	CSyn_StopUnit( context, csLFO );
	CSyn_StopUnit( context, csFilter );
	
	// Delete the units.
	CSyn_Delete( context, csOut );
	CSyn_Delete( context, csNoise );
	CSyn_Delete( context, csScalar );
	CSyn_Delete( context, csLFO );
	CSyn_Delete( context, csFilter );

	CSyn_StopEngine( context  );
	// Delete the context and any unitsd we forgot to delete.
	CSyn_DeleteContext( context );
	
finish:
	if( result < 0 )
	{
		PRINT(("Test failed = 0x%x\n", result));
	}
	else
	{
		PRINT(("Test succeeded = 0x%x\n", result));
	}

	// Convert to shell return code.
	return (result < 0) ? 1 : 0;
}
