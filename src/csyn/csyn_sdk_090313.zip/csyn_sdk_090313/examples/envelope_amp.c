/*
** CSyn Example
**
** Use an amplitude envelope to shape the volume contour of a note.
** You can use envelopes to control any parameter including amplitude, 
** frequency, resonance, etc.
**
** (C) 1997-2009  Phil Burk, Mobileer Inc, All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define T_ENGINE_FLAGS   (0)

#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

// Envelopes can have any shape and any number of duration/value pairs.
static EnvelopeFrame envelopeFrames[] =
{
	// duration, value pairs
	{ 0.1, 0.9 }, // attack - Go to value 0.9 in 0.1 seconds.
	{ 0.2, 0.4 }, // decay
	{ 0.4, 0.2 }, // release
	{ 0.3, 0.0 } // more release
};

#define NUM_SEGMENTS  (sizeof(envelopeFrames)/sizeof(EnvelopeFrame))

int main(void)
{
	CSynErr    result;
	// CSyn unit generators and other audio resources are represented by opaque tokens.
	CSynToken  csOsc = 0;
	CSynToken  csLFO = 0;
	CSynToken  csAdder = 0;
	CSynToken  csOut = 0;
	
	CSynToken  envelopeData = 0;
	CSynToken  csEnvPlayer;

	uint32     tick;
	uint32     tickRate;
	
	// Create a context for the synthesis engine.
	// You can run multiple engines at different sample rates or in non-real-time.
	CSynContext context = CSyn_CreateContext();
	if( context == NULL ) goto finish;
	
	PRINT(("Test envelope.\n\n"));

	// Start the synthesis engine running as a background thread.
	result = CSyn_StartEngine( context, T_ENGINE_FLAGS, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", finish);
	
	
	// ================ Create Envelope ==================================
	// Create Envelope data
	envelopeData = CSyn_CreateEnvelope( context, NUM_SEGMENTS );
	TEST_ERROR(envelopeData, "CSyn_CreateEnvelope()", cleanup);
	// Write pairs into allocated envelope object.
	result = CSyn_WriteEnvelope( context, envelopeData, 0, envelopeFrames, NUM_SEGMENTS );
	TEST_ERROR(result, "CSyn_WriteEnvelope()", cleanup);
	// Create a unit generator to "play" the envelope.
	csEnvPlayer = CSyn_CreateUnit( context, CSYN_UNIT_Envelope_Linear, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csEnvPlayer, "CSyn_CreateUnit( context,Env_Linear)", cleanup);

	// ================ Create Units ==================================
	// Make the unit generators that will run in the background.
	// Make a band-limited sawtooth oscillator to hear.
	csOsc = CSyn_CreateUnit( context, CSYN_UNIT_Osc_SawtoothBL, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOsc, "CSyn_CreateUnit( context,Osc_SAwtooth)", cleanup);
	// And another oscillator to slowly modulate the other triangle oscillator frequency.
	csLFO = CSyn_CreateUnit( context, CSYN_UNIT_Osc_Triangle, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csLFO, "CSyn_CreateUnit( context,Osc_Triangle)", cleanup);
	// Use an adder to add center frequency and offset from LFO.
	csAdder = CSyn_CreateUnit( context, CSYN_UNIT_Math_Add, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csLFO, "CSyn_CreateUnit( context,Math_Add)", cleanup);

	// Create LineOut so we can hear the result.
	csOut = CSyn_CreateUnit( context, CSYN_UNIT_Line_Out, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOut, "CSyn_CreateUnit( context,out)", cleanup);
	
	// ================ Adjust Units ==================================
	// Set frequency and amplitude of the various oscillators.
	// Frequency is in Hz.	
	result = CSyn_SetPort( context, csAdder, CSYN_PORT_InputA, 0,  440.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);

	result = CSyn_SetPort( context, csEnvPlayer, CSYN_PORT_Amplitude, 0, 0.9 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// The LFO amplitude is higher because it is the range of frequency modulation.
	result = CSyn_SetPort( context, csLFO, CSYN_PORT_Frequency, 0, 4.3 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);
	result = CSyn_SetPort( context, csLFO, CSYN_PORT_Amplitude, 0, 10.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// ================ Connect Units ==================================
	// Connect triangle to both channels of stereo player.
	result = CSyn_ConnectUnits( context, csOsc, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csOsc, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 1 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Connect LFO to frequency control of audio rate oscillator through the adder.
	result = CSyn_ConnectUnits( context, csLFO, CSYN_PORT_Output, 0,
		csAdder, CSYN_PORT_InputB, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csAdder, CSYN_PORT_Output, 0,
		csOsc, CSYN_PORT_Frequency, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Connect envelope to audible oscillator's amplitude port.
	result = CSyn_ConnectUnits( context, csEnvPlayer, CSYN_PORT_Output, 0,
		csOsc, CSYN_PORT_Amplitude, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Start running the unit generators.
	result = CSyn_StartUnit( context, csEnvPlayer );
	TEST_ERROR(result, "CSyn_StartUnit( context,env)", cleanup);
	result = CSyn_StartUnit( context, csLFO );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csAdder );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csOsc );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csOut );
	TEST_ERROR(result, "CSyn_StartUnit( context,out)", cleanup);
	
	
	// ================ Queue entire envelope ==================================
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 0, NUM_SEGMENTS, 0 );
	PRINT(("You should hear a complete note.\n"));
	printf("Hit enter to hear next sound effect.\n");
	getchar();

	// ================= Queue just attack and decay then sustain. ================================
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 0, 2, 0 );
	PRINT(("You should hear a note attack and decay then hold a steady sustain.\n"));
	printf("Hit enter to hear the sound release.\n");
	getchar();

	// ================= Queue release. ================================
	// Note different startFrame
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 2, 2, 0 );
	PRINT(("You should hear the note die away.\n"));
	printf("Hit enter to hear more.\n");
	getchar();

	// ================= Queue release. ================================
	// Note different startFrame
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 0, 2, 0 );
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 0, 2, 0 );
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 1, 3, 0 );
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 0, 3, 0 );
	result = CSyn_QueueData( context, csEnvPlayer, CSYN_PORT_Data, envelopeData, 1, 3, 0 );
	PRINT(("You should hear lots of complex modulation caused by queing multiple groups of frames.\n"));
	printf("Hit enter to continue.\n");
	getchar();

cleanup:
	// Stop execution of units.
	CSyn_StopUnit( context, csOut );
	CSyn_StopUnit( context, csOsc );
	CSyn_StopUnit( context, csAdder );
	CSyn_StopUnit( context, csEnvPlayer );
	CSyn_StopUnit( context, csLFO );
	
	// Delete the units.
	CSyn_Delete( context, csOut );
	CSyn_Delete( context, csOsc );
	CSyn_Delete( context, csAdder );
	CSyn_Delete( context, csEnvPlayer );
	CSyn_Delete( context, csLFO );

	CSyn_StopEngine( context  );
	// Delete the context and any units we forgot to delete.
	CSyn_DeleteContext( context );
	
finish:
	if( result < 0 )
	{
		PRINT(("Test failed = 0x%x\n", result));
	}
	else
	{
		PRINT(("Test succeeded = 0x%x\n", result));
	}

	// Convert to shell return code.
	return (result < 0) ? 1 : 0;
}
