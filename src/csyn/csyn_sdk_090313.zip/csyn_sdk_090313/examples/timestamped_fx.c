/*
** CSyn Example
**
** Use timestamps to schedule sound effects that run in the background.
** You can schedule starting and stopping of units, and setting ports at
** some time in the future.
**
** (C) 1997-2009  Phil Burk, Mobileer Inc, All Rights Reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "csyn.h"

#define PRINT(msg)  { printf msg; }
#define DBUG(msg)  /* PRINT(msg) */

#define T_ENGINE_FLAGS   (0)

#define TEST_ERROR(val,msg,iferr) \
	if(val < 0) { \
		PRINT(("ERROR - %s - %s\n", CSyn_ErrorCodeToText(val), msg)); \
		goto iferr; \
	}

int main(void)
{
	CSynErr    result;
	// CSyn unit generators and other audio resources are represented by opaque tokens.
	CSynToken  csOsc = 0;
	CSynToken  csLFO = 0;
	CSynToken  csAdder = 0;
	CSynToken  csOut = 0;
	uint32     tick;
	uint32     tickRate;
	
	// Create a context for the synthesis engine.
	// You can run multiple engines at different sample rates or in non-real-time.
	CSynContext context = CSyn_CreateContext();
	if( context == NULL ) goto finish;
	
	PRINT(("Test timestamps.\n\n"));

	// Start the synthesis engine running as a background thread.
	result = CSyn_StartEngine( context, T_ENGINE_FLAGS, 44100.0 );
	TEST_ERROR(result, "CSyn_StartEngine", finish);
	
	// ================ Create Units ==================================
	// Make the unit generators that will run in the background.
	// Make a band-limited sawtooth oscillator to hear.
	csOsc = CSyn_CreateUnit( context, CSYN_UNIT_Osc_SawtoothBL, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOsc, "CSyn_CreateUnit( context,Osc_SAwtooth)", cleanup);
	// And another oscillator to slowly modulate the other triangle oscillator frequency.
	csLFO = CSyn_CreateUnit( context, CSYN_UNIT_Osc_Triangle, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csLFO, "CSyn_CreateUnit( context,Osc_Triangle)", cleanup);
	// Use an adder to add center frequency and offset from LFO.
	csAdder = CSyn_CreateUnit( context, CSYN_UNIT_Math_Add, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csLFO, "CSyn_CreateUnit( context,Math_Add)", cleanup);

	// Create LineOut so we can hear the result.
	csOut = CSyn_CreateUnit( context, CSYN_UNIT_Line_Out, CSYN_RATE_AUDIO, 0 );
	TEST_ERROR(csOut, "CSyn_CreateUnit( context,out)", cleanup);
	
	// ================ Adjust Units ==================================
	// Set frequency and amplitude of the various oscillators.
	// Frequency is in Hz.	
	result = CSyn_SetPort( context, csAdder, CSYN_PORT_InputA, 0,  440.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);

	result = CSyn_SetPort( context, csOsc, CSYN_PORT_Amplitude, 0, 0.5 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// The LFO amplitude is higher because it is the range of frequency modulation.
	result = CSyn_SetPort( context, csLFO, CSYN_PORT_Frequency, 0, 4.3 );
	TEST_ERROR(result, "CSyn_SetPort( context,frequency)", cleanup);
	result = CSyn_SetPort( context, csLFO, CSYN_PORT_Amplitude, 0, 10.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// ================ Connect Units ==================================
	// Connect triangle to both channels of stereo player.
	result = CSyn_ConnectUnits( context, csOsc, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csOsc, CSYN_PORT_Output, 0,
		csOut, CSYN_PORT_Input, 1 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Connect LFO to frequency control of audio rate oscillator through the adder.
	result = CSyn_ConnectUnits( context, csLFO, CSYN_PORT_Output, 0,
		csAdder, CSYN_PORT_InputB, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);
	result = CSyn_ConnectUnits( context, csAdder, CSYN_PORT_Output, 0,
		csOsc, CSYN_PORT_Frequency, 0 );
	TEST_ERROR(result, "CSyn_ConnectUnits( context,)", cleanup);

	// Start running the unit generators.
	result = CSyn_StartUnit( context, csOut );
	TEST_ERROR(result, "CSyn_StartUnit( context,out)", cleanup);
	result = CSyn_StartUnit( context, csOsc );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csAdder );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	result = CSyn_StartUnit( context, csLFO );
	TEST_ERROR(result, "CSyn_StartUnit( context,tri)", cleanup);
	
	
	// ================ Schedule future events ==================================
	// Get number of ticks per second.
	tickRate = CSyn_GetTickRate(context);
	
	// Get current time.
	tick = CSyn_GetTickCount(context);
	// Schedule setting the amplitude to zero in two seconds.
	// Use "At" function to schedule commands "at" a future time.
	// Advance tick time by 2 seconds.
	tick += tickRate * 2;
	result = CSyn_SetPortAt( context, tick, csOsc, CSYN_PORT_Amplitude, 0, 0.0 );
	TEST_ERROR(result, "CSyn_SetPort( context,amplitude)", cleanup);

	// Let synthesizer run in background while we wait for a keypress.
	PRINT(("You should hear a two second tone.\n"));
	printf("When it stops hit enter to hear next sound effect.\n");
	getchar();

	// ================= Schedule a short melody ================================
	// Get current time.
	tick = CSyn_GetTickCount(context);
	// Turn oscillator up so we can hear it.
	result = CSyn_SetPortAt( context, tick, csOsc, CSYN_PORT_Amplitude, 0, 0.5 );
	// Schedule a series of frequency setting commands.
	result = CSyn_SetPortAt( context, tick, csAdder, CSYN_PORT_InputA, 0, 220.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csAdder, CSYN_PORT_InputA, 0, 330.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csAdder, CSYN_PORT_InputA, 0, 440.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csAdder, CSYN_PORT_InputA, 0, 330.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csOsc, CSYN_PORT_Amplitude, 0, 0.0 );

	PRINT(("You should hear short melody playing in the bacground.\n"));
	printf("When it stops hit enter to hear next sound effect.\n");
	getchar();

	// ================= Schedule an odd sound effect. ================================
	// Get current time.
	tick = CSyn_GetTickCount(context);
	// Turn oscillator up so we can hear it.
	result = CSyn_SetPortAt( context, tick, csOsc, CSYN_PORT_Amplitude, 0, 0.5 );
	// Schedule a series of frequency setting commands.
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Frequency, 0, 0.8 );
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Amplitude, 0, 200.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Frequency, 0, 50.0 );
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Amplitude, 0, 100.0 );
	tick += tickRate/4;
	// Fast enharmonic modulation.
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Frequency, 0, 600.0 );
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Amplitude, 0, 200.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Frequency, 0, 3.2 );
	result = CSyn_SetPortAt( context, tick, csLFO, CSYN_PORT_Amplitude, 0, 30.0 );
	tick += tickRate/4;
	result = CSyn_SetPortAt( context, tick, csOsc, CSYN_PORT_Amplitude, 0, 0.0 );

	PRINT(("You should hear some odd modulated tones.\n"));
	printf("When it stops hit enter to continue.\n");
	getchar();

cleanup:
	// Stop execution of units.
	CSyn_StopUnit( context, csOut );
	CSyn_StopUnit( context, csOsc );
	CSyn_StopUnit( context, csLFO );
	
	// Delete the units.
	CSyn_Delete( context, csOut );
	CSyn_Delete( context, csOsc );
	CSyn_Delete( context, csLFO );

	CSyn_StopEngine( context  );
	// Delete the context and any unitsd we forgot to delete.
	CSyn_DeleteContext( context );
	
finish:
	if( result < 0 )
	{
		PRINT(("Test failed = 0x%x\n", result));
	}
	else
	{
		PRINT(("Test succeeded = 0x%x\n", result));
	}

	// Convert to shell return code.
	return (result < 0) ? 1 : 0;
}
