README for CSyn SDK
Copyright (C) 1997 Phil Burk
All Rights Reserved

CSyn is an Audio Synthesis toolbox for 'C'.

--------------- Legal Info ---------------------------

Please see the csyn_license.txt for full details.

The CSyn SDK may only be used for evaluation purposes.

The CSyn SDK or portions thereof may NOT be redistributed by any means.
The CSyn SDK is only available from SoftSynth.com.
Please contact "phil@softsynth.com" to obtain the SDK

Commercial licenses for use and redistribution are available.
Please contact "phil@softsynth.com" for information.

CSyn is available AS IS with no warranty of fitness or suitability for any purpose.
Use at your own risk.

-------------- Getting Started ------------------------

A Visual Studio project has been provided in the folder:
  build\win32\csyn_test
  
Run the .sln file then run the executable of the first project.
You should hear a sound.  You can then replace the "short_sine.c"
example file with other examples from the "examples/" folder.

Please read the source code for an explanation of each test.

The example are meant to serve as a tutorial in CSyn programming:

  short_sine.c = play a sine tone for a few seconds
  lfo_mod_mix.c = use an LFO to modulate an ascillator
  wind.c = use noise and a resonant filter to make a wind sound
  timestamped_fx.c = use future timestamps to schedule sound modifications
  envelope_amp.c = use an envelope to 

-------------- Compiling ------------------------

To compile a program with CSyn you need to link with:

  lib/csyn.lib
  lib/portaudio_x86_static.lib
  ksuser.lib
  
And add "include/" to your include path.

If you encounter ANY bugs, or have any suggestions please let me
know.

Thank you,
Phil Burk
phil@softsynth.com
