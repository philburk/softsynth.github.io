<?php
// Aardvark Template system for websites.
// (C) 2011 Phil Burk
//
// 5/2012 - mods for Prodicta site, top navigation bar can have a header
require_once( $_SERVER['DOCUMENT_ROOT']."/aardvark_custom/config.php" );


function AVK_StartsWith($haystack, $needle)
{
    $length = strlen($needle);
    return (substr($haystack, 0, $length) === $needle);
}

class AardvarkPage
{

	/**
	 * Generate string of HTML for the left side navigation menu.
	 */
	function generateNavigation()
	{
		global $aardvarkLeftLinks;

		$phpSelf = $_SERVER[ 'PHP_SELF' ];
    	$output = "<ul>\n";
		foreach( $aardvarkLeftLinks as $link => $name )
		{
			$output .= '<li>';
			if( AVK_StartsWith( $phpSelf, $link ) )
			{
				// Highlight this link to show this is the current location.
				$output .=  '<span class="current_link">' . $name . "</span>\n";
			}
			else
			{
				$linkParts = explode(',',$link);
				if( count( $linkParts ) > 1 )
				{
					$output .=  '<a href="' . $linkParts[0] . '" target="' . $linkParts[1] . '">' . $name . "</a>\n";
				}
				else
				{
					$output .=  '<a href="' . $link . '">' . $name . "</a>\n";
				}
			}
			$output .=  '</li>';
		}
    	$output .=  "</ul>\n";
		return $output;
	}

	/**
	 * Generate s tring of HTML for the left side navigation menu.
	 */
	function generateTitle()
	{
		global $pageTitle;
		global $aardvarkDefaultTitle;
		if( isset( $pageTitle ) )
		{
			return $pageTitle;
		}
		else
		{
			return  $aardvarkDefaultTitle;
		}
	}

	/**
	 * Generate s tring of HTML for the left side navigation menu.
	 */
	function generateExtraHead()
	{
		global $pageExtraHead;
		global $aardvarkDefaultExtraHead;
		if( isset( $pageExtraHead ) )
		{
			return $pageExtraHead;
		}
		else
		{
			return  $aardvarkDefaultExtraHead;
		}
	}

	function renderHeader()
	{
		$headerTemplate = file_get_contents($_SERVER['DOCUMENT_ROOT']."/aardvark_custom/header.html");
		$headerTemplate = str_replace("{LEFTSIDE_NAVIGATION}", $this->generateNavigation(), $headerTemplate);
		$headerTemplate = str_replace("{TITLE}", $this->generateTitle(), $headerTemplate);
		$headerTemplate = str_replace("{EXTRA_HEAD}", $this->generateExtraHead(), $headerTemplate);
		echo $headerTemplate;
	}

	function renderFooter()
	{
		$footerTemplate = file_get_contents($_SERVER['DOCUMENT_ROOT']."/aardvark_custom/footer.html");
		echo $footerTemplate;
	}


	/**
	 * Print a navigation header for a folder.
	 */
	function printFolderHeader( $heading, $linkArray )
	{
		$phpSelf = $_SERVER[ 'PHP_SELF' ];
		//echo "<p>PHP_SELF = " . $phpSelf . "</p>\n";
		echo '<p class="navbar">'.$heading.":\n";
		foreach( $linkArray as $link => $name )
		{
			if( AVK_StartsWith( $phpSelf, $link ) )
			{
				// Highlight this link to show this is the current location.
				//echo '| <span class="current_link">' . $name . "</span>\n";
				echo '&nbsp;<a class="current_link" href="' . $link . '">' . $name . " </a>&nbsp;|\n";
			}
			else
			{
				echo '&nbsp;<a href="' . $link . '">' . $name . " </a>&nbsp;|\n";
			}
		}
		echo "</p>\n";
	}


	/**
	 * Print a navigation header for a folder.
	 */
	function printNavigationBar( $linkArray )
	{
		$phpSelf = $_SERVER[ 'PHP_SELF' ];
		//echo "<p>PHP_SELF = " . $phpSelf . "</p>\n";
		echo '<p class="navbar">'."\n";
		$linkIndex = 0;
		foreach( $linkArray as $link => $name )
		{
			if ($linkIndex == 1)
			{
				echo "&nbsp;:&nbsp;";
			}
			else if ($linkIndex > 1)
			{
				echo "&nbsp;|&nbsp;";
			}
			if( AVK_StartsWith( $phpSelf, $link ) )
			{
				// Highlight this link to show this is the current location.
				//echo '| <span class="current_link">' . $name . "</span>\n";
				//echo '&nbsp;<a class="current_link" href="' . $link . '">' . $name . " </a>&nbsp;|\n";
				echo '<span class="current_link">' . $name . "</span>\n";
			}
			else
			{
				echo '<a href="' . $link . '">' . $name . "</a>\n";
			}
			$linkIndex += 1;
		}
		echo "</p>\n";
	}
}


// Classes for Sequence of web pages with Previous/Next
// Array of pages loaded from a file.
class AardvarkSequence
{
	var $currentPageIndex;
	// Arrays of page data. Should be an array of one custom object.
    var $pageLevels;
    var $pageLinks;
    var $pageTitles;
    var $pageTags;

    function AardvarkSequence( $filename )
    {
        $fp = fopen($filename,"r");
        if( $fp )
        {
            $remainder = fread ($fp, filesize ($filename));
            $indx = 0;
            while( strlen( $remainder ) > 0 )
            {
                // Get next line.
                list( $pageLine, $remainder ) = explode( "\n", $remainder, 2 );
				list( $pageLevel, $pageLink, $pageTitle, $pageTag ) = explode( ",", $pageLine, 4 );
				$pageLevel = trim( $pageLevel );
				$pageLink = trim( $pageLink );
				$pageTitle = trim( $pageTitle );
				$pageTag = trim( $pageTag );
                $this->pageLevels[] = $pageLevel;
                $this->pageLinks[] = $pageLink;
                $this->pageTitles[] = $pageTitle;
                $this->pageTags[] = $pageTag;
            }
            fclose($fp);
        }

		$thisPage = basename( $_SERVER['PHP_SELF'] );
		$this->setCurrentPage( $thisPage );
    }

	function printLink( $targetURL, $text )
	{
		if( $targetURL )
		{
			echo "<a href=\"" . $targetURL . "\">" . $text . "</a>";
		}
		else
		{
			echo  $text;
		}
	}

	function setCurrentPage( $pageLink )
	{
		$this->currentPageIndex = array_search( $pageLink, $this->pageLinks );
	}

    function getFirstPage()
    {
        return $this->pageLinks[0];
    }

    function getNumPages()
    {
        return count( $this->pageLinks );
    }

    function getPageTitle()
    {

    	if( is_null( $this->currentPageIndex )  )
    	{
    		return "";
    	}
    	else
		{
			return $this->pageTitles[ $this->currentPageIndex ];
		}
	}

    function getNextPageLink()
    {
    	if( is_null( $this->currentPageIndex )  )
    	{
    		return false;
    	}
    	else
    	{
    		if( $this->currentPageIndex < (count($this->pageLinks) - 1) )
    		{
    			return $this->pageLinks[ $this->currentPageIndex + 1 ];
    		}
    		else
    		{
    			return false;
    		}
    	}
    }

    function getPreviousPageLink()
    {
    	if( is_null( $this->currentPageIndex )  )
    	{
    		return false;
    	}
    	else
    	{
    		if( $this->currentPageIndex > 0 )
    		{
    			return $this->pageLinks[ $this->currentPageIndex - 1 ];
    		}
    		else
    		{
    			return false;
    		}
    	}
    }

	function printTags( $tags )
	{
		if( !(strpos( $tags, "audio" ) === false) )
		{
			echo '&nbsp;&nbsp;<img SRC="hear.JPG" height="16" width="16" align="ABSCENTER">';
		}
	}

	function printTableOfContents()
	{
		$level = 0;
		$numPages = count( $this->pageLinks );
		for( $counter=0; $counter<$numPages; $counter += 1 )
		{
			$pageLevel = $this->pageLevels[$counter];
			while( ($level < $pageLevel) && ($level < 10) )
			{
				echo "<ul>\n";
				$level += 1;
			}
			while( ($level > $pageLevel) && ($level > 0) )
			{
				echo "</ul>\n";
				$level -= 1;
			}
			echo '<li>';
			$this->printLink( $this->pageLinks[$counter], $this->pageTitles[$counter] );
			$this->printTags( $this->pageTags[$counter] );
			echo "</li>\n";
		}
		while( $level > 0 )
		{
			echo "</ul>\n";
			$level -= 1;
		}
	}

	function printNavigation()
	{
		echo '<p class="navbar">';
		echo "|&nbsp;";
		$this->printLink( $this->getFirstPage(), 'Top' );
		echo "&nbsp;|&nbsp;";
		$this->printLink( $this->getPreviousPageLink(), 'Previous' );
		echo "&nbsp;|&nbsp;";
		$this->printLink( $this->getNextPageLink(), 'Next' );
		echo "&nbsp;|&nbsp;";
		echo "#" . ($this->currentPageIndex + 1) . "/" . $this->getNumPages();
		echo '</p>';
	}
}
