# aardvark
Minimal PHP framework for websites with navigation menus
