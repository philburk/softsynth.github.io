<?php
// Default title. Override this by defining $pageTitle in your own page before including Aardvark.
$aardvarkDefaultTitle = "My website title";
// Default extra head information. Override this by defining $pageExtraHead in your own page before including Aardvark.
$aardvarkDefaultExtraHead = "<!-- extra head -->";

// Define left side navigation links.
$aardvarkLeftLinks = array(
	'/index.php' => 'Home',
	'/info/index.php' => 'Info',
	'/news/index.php' => 'News',
	'/contacts.php' => 'Contact&nbsp;Us',
	'/aboutus.php' => 'About&nbsp;Us' );

?>
