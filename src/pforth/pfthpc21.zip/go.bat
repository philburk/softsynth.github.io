bincmp -m10 pforth.dic pforth_mac.dic 
