# Microsoft Developer Studio Project File - Name="pForth" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=pForth - Win32 MakeDic
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "pForth.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "pForth.mak" CFG="pForth - Win32 MakeDic"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "pForth - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "pForth - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE "pForth - Win32 MakeDic" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "pForth - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /D "NDEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "PF_SUPPORT_FP" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386 /out:"../pForth.exe"

!ELSEIF  "$(CFG)" == "pForth - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W4 /Gm /GX /Zi /Od /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "PF_SUPPORT_FP" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /out:"../pForth.exe" /pdbtype:sept

!ELSEIF  "$(CFG)" == "pForth - Win32 MakeDic"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "pForth__"
# PROP BASE Intermediate_Dir "pForth__"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "pForth__"
# PROP Intermediate_Dir "pForth__"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /Gm /GX /Zi /Od /D "_DEBUG" /D "WIN32" /D "_CONSOLE" /D "_MBCS" /D "PF_SUPPORT_FP" /YX /FD /c
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /out:"../pForth.exe" /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /out:"../pForth.exe" /pdbtype:sept

!ENDIF 

# Begin Target

# Name "pForth - Win32 Release"
# Name "pForth - Win32 Debug"
# Name "pForth - Win32 MakeDic"
# Begin Group "Forth"

# PROP Default_Filter ".fth, .j"
# Begin Source File

SOURCE=..\ansilocs.fth
# End Source File
# Begin Source File

SOURCE=..\bench.fth
# End Source File
# Begin Source File

SOURCE=..\c_struct.fth
# End Source File
# Begin Source File

SOURCE=..\case.fth
# End Source File
# Begin Source File

SOURCE=..\catch.fth
# End Source File
# Begin Source File

SOURCE=..\condcomp.fth
# End Source File
# Begin Source File

SOURCE=..\coretest.fth
# End Source File
# Begin Source File

SOURCE=..\filefind.fth
# End Source File
# Begin Source File

SOURCE=..\floats.fth
# End Source File
# Begin Source File

SOURCE=..\forget.fth
# End Source File
# Begin Source File

SOURCE=..\loadp4th.fth
# End Source File
# Begin Source File

SOURCE=..\locals.fth
# End Source File
# Begin Source File

SOURCE=..\math.fth
# End Source File
# Begin Source File

SOURCE=..\member.fth
# End Source File
# Begin Source File

SOURCE=..\misc1.fth
# End Source File
# Begin Source File

SOURCE=..\misc2.fth
# End Source File
# Begin Source File

SOURCE=..\numberio.fth
# End Source File
# Begin Source File

SOURCE=..\private.fth
# End Source File
# Begin Source File

SOURCE=..\quit.fth
# End Source File
# Begin Source File

SOURCE=..\see.fth
# End Source File
# Begin Source File

SOURCE=..\smart_if.fth
# End Source File
# Begin Source File

SOURCE=..\strings.fth
# End Source File
# Begin Source File

SOURCE=..\system.fth
# End Source File
# Begin Source File

SOURCE=..\t_alloc.fth
# End Source File
# Begin Source File

SOURCE=..\t_corex.fth
# End Source File
# Begin Source File

SOURCE=..\t_locals.fth
# End Source File
# Begin Source File

SOURCE=..\t_strings.fth
# End Source File
# Begin Source File

SOURCE=..\t_tools.fth
# End Source File
# Begin Source File

SOURCE=..\tester.fth
# End Source File
# Begin Source File

SOURCE=..\trace.fth
# End Source File
# Begin Source File

SOURCE=..\tut.fth
# End Source File
# Begin Source File

SOURCE=..\wordslik.fth
# End Source File
# End Group
# Begin Group "docs"

# PROP Default_Filter ".txt, .htm"
# Begin Source File

SOURCE=..\docs\pf_ref.htm
# End Source File
# Begin Source File

SOURCE=..\docs\pf_todo.txt
# End Source File
# Begin Source File

SOURCE=..\docs\pf_tut.htm
# End Source File
# Begin Source File

SOURCE=..\docs\pfmanual.txt
# End Source File
# Begin Source File

SOURCE=..\README.txt
# End Source File
# End Group
# Begin Source File

SOURCE=..\csrc\pf_cglue.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_clib.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_core.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_inner.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_io.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_main.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_mem.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_save.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_text.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pf_words.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pfcompil.c
# End Source File
# Begin Source File

SOURCE=..\csrc\pfcustom.c
# End Source File
# End Target
# End Project
